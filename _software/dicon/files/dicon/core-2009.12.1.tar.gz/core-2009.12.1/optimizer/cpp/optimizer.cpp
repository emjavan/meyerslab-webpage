/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "optimizer.hpp"
#include <boost/foreach.hpp>
#include <boost/scoped_ptr.hpp>


namespace detail {

  static const char *c_error = NULL;
  static std::string error_str = "No error.";
  static optimizer::children_t children = NULL;
  static boost::scoped_ptr<Optimizer> optimizer;


  static
  void
  set_error() throw() {
    c_error = "Unknown error.";
  }


  static
  void
  set_error( const std::string &str ) throw() {
    try {
      c_error = (error_str = str).c_str();
    }
    catch( ... ) {
      set_error();
    }
  }

}



OptimizerError::OptimizerError( const std::string &what )
  : std::runtime_error(what)
{
}


optimizer::policy_t
Optimizer::c_to_cpp( const optimizer::node_t *const list ) {
  optimizer::policy_t policy;

  for( size_t i = 0; list[i]; ++i )
    policy.push_back( list[i] );

  return policy;
}


const optimizer::node_t *
Optimizer::cpp_to_c( const optimizer::policy_t &policy, bool keep ) {
  if( !keep )
    temporary_.clear();

  BOOST_FOREACH( optimizer::node_t node, policy ) {
    if( node != 0 )
      temporary_.push_back( node );
    else
      throw OptimizerError( "Optimizer::cpp_to_c(): Invalid node (0)." );
  }

  temporary_.push_back( 0 );
  return temporary_.data();
}


std::vector<optimizer::node_t>
Optimizer::children( const std::vector<optimizer::node_t> &path ) {
  if( !detail::children )
    throw OptimizerError( "Optimizer::children(): No children callback set." );

  const optimizer::node_t *children;

  if( detail::children(cpp_to_c(path), &children) != 0 )
    throw OptimizerError( "Optimizer::children(): Children callback failed." );

  return c_to_cpp( children );
}


void
Optimizer::get_policy_c( const optimizer::node_t **const policy ) {
  const boost::optional<optimizer::policy_t> &policy_cpp = get_policy();

  if( policy_cpp )
    *policy = cpp_to_c( *policy_cpp );
  else
    *policy = NULL;
}


void
Optimizer::update_c( const optimizer::node_t *const policy, double reward ) {
  update( c_to_cpp(policy), reward );
}


void
Optimizer::policies_c( unsigned *const count, const optimizer::node_t **const policies, const double **rewards ) {
  const policies_result_type &list = this->policies( *count );

  *count = list.size();

  temporary_.clear();
  tmp_rewards_.clear();

  BOOST_FOREACH( const policies_result_type::value_type &entry, list ) {
    const optimizer::policy_t &policy = entry.first;
    const double &reward = entry.second;

    cpp_to_c( policy, true );
    tmp_rewards_.push_back( reward );
  }

  *policies = temporary_.data();
  *rewards = tmp_rewards_.data();
}


void
Optimizer::dump_state_c( const char *const filename ) {
  dump_state( std::string(filename) );
}



extern "C" {

  int
  initialize( int argc, const char *const *const argv,
              optimizer::children_t children, const char *const state_file )
  {
    try {
      detail::optimizer.reset();

      std::string name;
      optimizer::arguments_t arguments;

      for( int i = 0; i < argc; ++i ) {
        std::string arg( argv[i] );

        if( i == 0 )
          name = arg;
        else
          arguments.push_back( arg );
      }

      boost::optional<std::string> state_file_s;

      if( state_file )
        state_file_s = std::string( state_file );

      detail::children = children;
      detail::optimizer.reset( create_optimizer(name,
                                                arguments,
                                                state_file_s) );
      return 0;
    }
    catch( std::exception &e ) {
      detail::set_error( e.what() );
      return -1;
    }
    catch( ... ) {
      detail::set_error();
      return -1;
    }
  }


#define CALL_OPTIMIZER_INSTANCE( NAME, ARGUMENTS )                      \
  try {                                                                 \
    if( !detail::optimizer )                                            \
      thro##w OptimizerError( #NAME "(): No optimizer instance." );     \
                                                                        \
    detail::optimizer -> NAME##_c ARGUMENTS;                            \
    return 0;                                                           \
  }                                                                     \
  catch( std::exception &e ) {                                          \
    detail::set_error( e.what() );                                      \
    return -1;                                                          \
  }                                                                     \
  catch( ... ) {                                                        \
    detail::set_error();                                                \
    return -1;                                                          \
  }                                                                     \
  /**/


  int
  get_policy( const optimizer::node_t **policy ) {
#define ARGUMENTS ( policy )
    CALL_OPTIMIZER_INSTANCE( get_policy, ARGUMENTS )
#undef ARGUMENTS
  }


  int
  update( const optimizer::node_t *policy, double reward ) {
#define ARGUMENTS ( policy, reward )
    CALL_OPTIMIZER_INSTANCE( update, ARGUMENTS )
#undef ARGUMENTS
  }


  int
  policies( unsigned *count, const optimizer::node_t **policies, const double **rewards ) {
#define ARGUMENTS ( count, policies, rewards )
    CALL_OPTIMIZER_INSTANCE( policies, ARGUMENTS )
#undef ARGUMENTS
  }


  int
  dump_state( const char *filename ) {
#define ARGUMENTS ( filename )
    CALL_OPTIMIZER_INSTANCE( dump_state, ARGUMENTS )
#undef ARGUMENTS
  }


  const char *
  get_error() {
    if( !detail::c_error )
      detail::set_error( "No error." );

    return detail::c_error;
  }

}

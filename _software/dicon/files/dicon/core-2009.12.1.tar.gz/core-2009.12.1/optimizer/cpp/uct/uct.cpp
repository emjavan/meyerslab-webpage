/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "uct.hpp"
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/foreach.hpp>
#include <boost/format.hpp>
#include <boost/tuple/tuple.hpp>
#include <cmath>
#include <fstream>
#include <limits>


UCT::Node::Node()
  : is_leaf(false), reward(0), count(0)
{
}


UCT::UCT( const std::string &name,
          const optimizer::arguments_t &arguments,
          const boost::optional<std::string> &state_file )
{
  if( state_file ) {
    // Resume: get state from given file.
    std::ifstream in( state_file->c_str() );
    load_state( in );
    if( in.fail() )
      throw OptimizerError( "UCT::UCT(): Failed to read state file." );
  }
}


template< bool weighted >
static
std::pair<optimizer::node_t, UCT::Node *>
select_child( UCT::Node *const parent ) {
  assert( !parent->is_leaf );
  assert( !parent->children.empty() );

  UCT::Node *best_child = NULL;
  optimizer::node_t best_id = optimizer::node_t();
  double best_value = -std::numeric_limits<double>::infinity();

  BOOST_FOREACH( UCT::tree_t::value_type &entry, parent->children ) {
    UCT::Node *const child = &entry.second;

    if( weighted && child->count == 0 ) {
      best_id = entry.first;
      best_child = child;
      break;
    }

    if( child->count == 0 )
      continue;

    assert( child->count != 0 );
    assert( parent->count != 0 );

    double value = weighted
                 ? child->reward + std::sqrt( std::log(parent->count) * 2 / child->count )
                 : child->reward;

    if( !std::isfinite(value) )
      throw OptimizerError( (boost::format("select_child(): Invalid weight (%f).") % value).str() );

    if( value > best_value ) {
      best_id = entry.first;
      best_child = child;
      best_value = value;
    }
  }

  assert( best_child );
  return std::make_pair( best_id, best_child );
}


boost::optional<optimizer::policy_t>
UCT::get_policy() {
  if( !data.current_path.empty() ) {
    // One policy at a time.
    return boost::none;
  }

  optimizer::policy_t policy;

  assert( data.current_path.empty() );

  for( Node *node = &data.root_node;; ) {
    data.current_path.push_back( node );

    if( node->is_leaf )
      break;

    if( node->children.empty() ) {
      BOOST_FOREACH( optimizer::node_t child, children(policy) ) {
        // Create child in tree.
        node->children[child];
      }

      if( node->children.empty() ) {
        node->is_leaf = true;
        break;
      }
    }

    optimizer::node_t id;
    boost::tie( id, node )
      = select_child<true>( node );

    policy.push_back( id );
  }

  return policy;
}


void
UCT::update( const optimizer::policy_t &policy, double reward ) {
  if( data.current_path.empty() )
    throw OptimizerError( "UCT::update(): Unexpected update." );

  BOOST_FOREACH( Node *node, data.current_path )
    node->reward += (reward - node->reward) / ++node->count;

  data.current_path.clear();
}


UCT::policies_result_type
UCT::policies( unsigned count ) {
  if( count == 0 )
    return policies_result_type();

  if( !data.current_path.empty() )
    throw OptimizerError( "UCT::policies(): Update pending." );

  optimizer::policy_t policy;

  Node *node;
  for( node = &data.root_node; !node->is_leaf; ) {
    if( node->children.empty() ) {
      // Update has not been called.
      return policies_result_type();
    }

    optimizer::node_t id;
    boost::tie( id, node )
      = select_child<false>( node );

    policy.push_back( id );
  }

  assert( node->count != 0 );
  return policies_result_type( 1, policies_result_type::value_type(policy, node->reward) );
}


void
UCT::dump_state( const std::string &filename ) {
  std::ofstream out( filename.c_str() );
  save_state( out );
  if( out.fail() )
    throw OptimizerError( "UCT::dump_state(): Failed to write to file." );
}


void
UCT::load_state( std::istream &in ) {
  boost::archive::binary_iarchive( in )
    >> boost::serialization::make_nvp( "data", data );
}


void
UCT::save_state( std::ostream &out ) {
  boost::archive::binary_oarchive( out )
    << boost::serialization::make_nvp( "data", data );
}

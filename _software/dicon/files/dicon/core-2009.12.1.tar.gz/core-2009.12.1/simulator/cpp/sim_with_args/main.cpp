/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "../simulator.hpp"
#include <boost/format.hpp>
#include <boost/lexical_cast.hpp>
#include <getopt.h>


static size_t base = 5;
static size_t depth = 2;
typedef unsigned node_t;


class SimpleSimulator
  : public Simulator<node_t>
{
public:
  virtual
  std::vector<node_t>
  children( const std::vector<node_t> &path ) {
    std::vector<node_t> res;

    if( path.size() < depth ) {
      for( size_t i = 0; i < base; ++i )
        res.push_back( i );
    }

    return res;
  }


  virtual
  double
  simulate( const std::vector<node_t> &policy ) {
    double value = 0;
    double factor = 1;

    BOOST_FOREACH( const node_t &digit, policy ) {
      factor /= base;
      value += digit * factor;
    }

    return value;
  }


  virtual
  std::string
  display( const std::vector<node_t> &policy ) {
    std::string res;

    BOOST_FOREACH( const node_t &digit, policy ) {
      if( !res.empty() ) res += ", ";
      res += boost::lexical_cast<std::string>( digit );
    }

    return '[' + res + ']';
  }
};


int
main( int argc, char *argv[] ) {
  static const struct option long_options[] = {
    { "base" , required_argument, NULL, 'k' },
    { "depth", required_argument, NULL, 'n' },
  };

  while( true ) {
    int opt;
    if( (opt = getopt_long(argc, argv, "k:n:", long_options, NULL)) == -1 )
      break;

    switch( opt ) {
    case 'k':
      base = boost::lexical_cast<unsigned>( optarg );
      break;

    case 'n':
      depth = boost::lexical_cast<unsigned>( optarg );
      break;

    default:
      throw SimulatorError( "main(): unhandled option" );
    }
  }

  std::cerr << (boost::format("Using base = %u, depth = %u.\n") % base % depth);

  SimpleSimulator().main();
}

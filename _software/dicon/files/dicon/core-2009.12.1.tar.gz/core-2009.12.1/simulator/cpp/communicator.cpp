/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "communicator.hpp"
#include <boost/scoped_array.hpp>
#include <cerrno>


CommunicatorError::CommunicatorError( const std::string &what )
  : std::runtime_error(what)
{
}


Communicator::Communicator( int input, int output )
  : input_(input), output_(output)
{
}


Communicator::~Communicator() {
  close( input_ );
  close( output_ );
  // Ignore errors.
}


std::string
Communicator::read_n( size_t n ) {
  boost::scoped_array<char> buffer( new char[n] );

  size_t done = 0;
  while( done < n ) {
    ssize_t res;
    if( (res = ::read(input_, buffer.get()+done, n-done)) <= 0 )
      throw CommunicatorError( "Communicator::read_n(): Failed to read from input." );

    assert( size_t(res) <= n-done );

    done += size_t(res);
  }

  return std::string( buffer.get(), n );
}


void
Communicator::write( const std::string &buffer ) {
  const size_t n = buffer.size();

  size_t done = 0;
  while( done < n ) {
    ssize_t res;
    if( (res = ::write(output_, buffer.c_str()+done, n-done)) <= 0 )
      throw CommunicatorError( "Communicator::write(): Failed to write to output." );

    assert( size_t(res) <= n-done );

    done += size_t(res);
  }
}


void
Communicator::flush() {
  if( ::fsync(output_) != 0 && errno != EINVAL )
    throw CommunicatorError( "Communicator::flush(): Failed to flush output." );
}


std::string
Communicator::encode_uint32( uint32_t value ) {
  std::string msg( 4, char(0) );

  msg[0] = char(static_cast<unsigned char>((value >>  0) & 255));
  msg[1] = char(static_cast<unsigned char>((value >>  8) & 255));
  msg[2] = char(static_cast<unsigned char>((value >> 16) & 255));
  msg[3] = char(static_cast<unsigned char>((value >> 24) & 255));

  return msg;
}


uint32_t
Communicator::decode_uint32( const std::string &str ) {
  if( str.size() != 4 )
    throw CommunicatorError( "Communicator::decode_uint32(): String has unexpected length." );

  return
    (uint32_t(static_cast<unsigned char>(str[0])) <<  0) |
    (uint32_t(static_cast<unsigned char>(str[1])) <<  8) |
    (uint32_t(static_cast<unsigned char>(str[2])) << 16) |
    (uint32_t(static_cast<unsigned char>(str[3])) << 24);
}


std::string
Communicator::read_message() {
  size_t length = decode_uint32( read_n(4) );
  return read_n( length );
}


void
Communicator::write_message( const std::string &msg ) {
  write( encode_uint32(msg.length()) );
  write( msg );
  flush();
}

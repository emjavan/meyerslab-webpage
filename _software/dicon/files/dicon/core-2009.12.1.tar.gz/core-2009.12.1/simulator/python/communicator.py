#!/usr/bin/env python

#--- [Distribution] -----------------------------------------------
# This file is part of the Disease Control System DiCon.
#
# Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
# Designed and developed with the guidance of Nedialko B. Dimitrov
# and Lauren Ancel Meyers at the University of Texas at Austin.
#
# DiCon is free software: you  can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# DiCon  is distributed in  the hope  that it  will be  useful, but
# WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
#------------------------------------------------------------------

class Communicator:
    def __init__( self, input, output ):
        self.input = input
        self.output = output


    def read_n( self, n ):
        buffer = ""

        while len(buffer) < n:
            res = self.input.read( n-len(buffer) )

            if len(res) == 0:
                raise IOError, "Failed to read from stream."

            buffer += res

        return buffer


    def write( self, buffer ):
        self.output.write( buffer )


    def flush( self ):
        self.output.flush()


    def encode_uint32( self, value ):
        return \
            chr((value >>  0) & 255) + \
            chr((value >>  8) & 255) + \
            chr((value >> 16) & 255) + \
            chr((value >> 24) & 255)


    def decode_uint32( self, str ):
        if len(str) != 4:
            raise ValueError, "String has unexpected length."

        return \
            (ord(str[0]) <<  0) | \
            (ord(str[1]) <<  8) | \
            (ord(str[2]) << 16) | \
            (ord(str[3]) << 24)


    def read_message( self ):
        length = self.decode_uint32( self.read_n(4) )
        return self.read_n( length )


    def write_message( self, msg ):
        self.write( self.encode_uint32(len(msg)) )
        self.write( msg )

        self.flush()

#!/usr/bin/ruby

require "tempfile"
require "ftools"

$hpp_prefix = "dicon_"
$directory = [ "src", "simulator", "optimizer" ]
$keywords = [ "catch", "for", "if", "switch", "while", "BOOST_FOREACH" ]

$license = [ "This file is part of the Disease Control System DiCon.",
             "",
             "Copyright (C) 2009  Sebastian Goll, University of Texas at Austin",
             "Designed and developed with the guidance of Nedialko B. Dimitrov",
             "and Lauren Ancel Meyers at the University of Texas at Austin.",
             "",
             "DiCon is free software: you  can redistribute it and/or modify it",
             "under the terms of the GNU General Public License as published by",
             "the Free Software Foundation, either version 3 of the License, or",
             "(at your option) any later version.",
             "",
             "DiCon  is distributed in  the hope  that it  will be  useful, but",
             "WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of",
             "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU",
             "General Public License for more details.",
             "",
             "You should have received a copy of the GNU General Public License",
             "along with DiCon.  If not, see <http://www.gnu.org/licenses/>.",
           ]

def trim_lines( data )
  while data.size > 0 && data[-1] =~ /^$/
    data[-1, 1] = nil
  end

  while data.size > 0 && data[0] =~ /^$/
    data[0, 1] = nil
  end
end


def read_file( filename )
  data = IO.readlines(filename).map { |x| x.rstrip }
  trim_lines( data )
  return data
end


def write_file( filename, data )
  trim_lines( data )

  target = File.new( "#{filename}-tmp", "w" )
  target.write( (data.map { |x| "#{x}#{$/}" }).join("") )
  target.chmod( File.executable?(filename) ? 0755 : 0644 )
  target.flush
  target.close

  File.rename( target.path, filename )
end


def process_hpp( filename )
  data = read_file( filename )

  if data.size >= 3 && data[0] =~ /^#ifndef / && data[1] =~ /^#define / && data[-1] =~ /^#endif / then
    data[-1, 1] = nil
    data[0, 2] = nil
  end

  trim_lines( data )

  name = filename.gsub( /\/|\./, "_" )
  name = "#{$hpp_prefix}#{name}_"
  name.upcase!

  data =
    [ "#ifndef #{name}",
      "#define #{name}",
      "",
    ] +
    data +
    [ "",
      "#endif //#{name}"
    ]

  write_file( filename, data )
end


def process_throw( filename )
  data = read_file( filename )

  lineno = 0
  function = nil
  lprintfun = nil

  data.map! do |line|
    lineno += 1

    if line =~ /^([a-zA-Z0-9_:~\[\]]+(?:<[^>]+>[a-zA-Z0-9_:~\[\]]+)*(?:\(\))?)\(/ || (line =~ /^(?:\s\s)*([a-zA-Z0-9_:~\[\]]+(?:<[^>]+>[a-zA-Z0-9_:~\[\]]+)*(?:\(\))?)\([^)]*\)\s*(?:const\s*)?\{\s*$/ && !$keywords.include?($1))
      function = $1
    end

    if line =~ /^\s*throw\s/
      raise "#{filename}:#{lineno}: Got throw clause outside of function." if function.nil?
      raise "#{filename}:#{lineno}: Got throw clause inside destructor." if function =~ /~/

      if line =~ /throw\s/
        unless line =~ /throw\s+([a-zA-Z0-9_:~\[\]]+)\s*\(/
          raise "#{filename}:#{lineno}: Failed to recognize throw clause (#{line.strip})."
        end

        exception = $1
        unless exception =~ /^(?:[a-zA-Z0-9_]+::)*([A-Z][a-zA-Z0-9_]*)$/
          raise "#{filename}:#{lineno}: Failed to recognize exception (#{exception})."
        end
      end

      status = nil
      if line =~ /^(.*(?:throw\s+(?:[a-zA-Z0-9_:~\[\]]+(?:<[^>]+>[a-zA-Z0-9_:~\[\]]+)*)\s*\(\s*(?:errno\s*,\s*)?)(?:\(\s*boost::format\s*\(\s*)?")([a-zA-Z0-9_:~\[\]]+(?:<[^>]+>[a-zA-Z0-9_:~\[\]]+)*(?:\(\))?)(\(\):.*)$/
        status = "l.#{lineno}: \"#{$2}()\" -> \"#{function}()\"" if $2 != function
        line = "#{$1}#{function}#{$3}"
      elsif line =~ /^(.*(?:throw\s+(?:[a-zA-Z0-9_:~\[\]]+(?:<[^>]+>[a-zA-Z0-9_:~\[\]]+)*)\s*\(\s*(?:errno\s*,\s*)?)(?:\(\s*boost::format\s*\(\s*)?")(.*)$/
        status = "l.#{lineno}: no function (#{line.strip})"
        # Ignore.
      else
        raise "#{filename}:#{lineno}: Failed to recognize clause (#{line.strip})."
      end

      unless status.nil?
        if lprintfun != function
          $stderr.puts( "  #{function}()" )
          lprintfun = function
        end

        $stderr.puts( "    #{status}" )
      end
    end

    line
  end

  write_file( filename, data )
end


def process_license( filename )
  data = read_file( filename )

  if filename =~ /\..pp$/
    start_marker = "/*--- [Distribution] -----------------------------------------------"
    line_prefix  = " * "
    stop_marker  = " *----------------------------------------------------------------*/"
    line_insert  = filename =~ /\.hpp$/ ? 3 : filename =~ /\.ipp$/ ? 2 : 1
  elsif filename =~ /\.py$/
    start_marker = "#--- [Distribution] -----------------------------------------------"
    line_prefix  = "# "
    stop_marker  = "#------------------------------------------------------------------"
    line_insert  = 2
  else
    raise "Unknown file type (#{filename})."
  end

  lineno = 0
  start = nil
  stop = nil

  data.each do |line|
    lineno += 1

    if start.nil?
      if line.match( "^#{Regexp.quote(start_marker)}$" )
        start = lineno
      end
    else
      if line.match( "^#{Regexp.quote(stop_marker)}$" )
        stop = lineno
        break
      end
    end
  end

  if !start.nil? && !stop.nil?
    data[(start-1)..(stop-1)] = nil
  end

  if data.size > 0
    start = line_insert > 1 ? data[0..(line_insert-2)] : []
    stop = data[(line_insert-1)..-1]
  else
    start = []
    stop = []
  end

  trim_lines( start )
  trim_lines( stop )

  license = $license.map do |line| (line_prefix + line).rstrip end
  data = start + [""] + [start_marker] + license + [stop_marker] + [""] + stop
  trim_lines( data )

  write_file( filename, data )
end


def main()
  $directory.each do |bdir|
    Dir.chdir(bdir) do |dir|
      Dir.glob("**/*.hpp").each do |file|
        next if File.symlink?(file)
        $stderr.puts( "process_hpp(\"#{dir}/#{file}\")" )
        process_hpp( file )
      end

      Dir.glob("**/*.[ci]pp").each do |file|
        next if File.symlink?(file)
        $stderr.puts( "process_throw(\"#{dir}/#{file}\")" )
        process_throw( file )
      end

      Dir.glob("**/*.{[chi]pp,py}").each do |file|
        next if File.symlink?(file)
        $stderr.puts( "process_license(\"#{dir}/#{file}\")" )
        process_license( file )
      end
    end
  end
end


main

#ifndef DICON_REQUEST_HPP_
#define DICON_REQUEST_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief RequestQueue class.
 */
#include <boost/noncopyable.hpp>
#include <deque>
#include <map>
#include <vector>


namespace boost {
  namespace mpi {
    class request;
    class status;
  }
}


/**
 * @brief MPI request queue.
 *
 * The  templated  RequestQueue  class  implements  a  queue  for  MPI
 * requests returned by the  Boost MPI library (@c boost::mpi::request
 * class). Each request can be assigned an object of custom type given
 * by the  template argument @e T. The  queue can be used  to wait for
 * any request on it to finish.
 *
 * The  queue  keeps  track  of  which node  each  request  originated
 * from. This way, requests are  finished in the exact order they have
 * been pushed  onto the queue,  i.e., requests pushed onto  the queue
 * later will  be returned  by wait() only  after every  other request
 * originating from  the same node  has been returned.   Requests from
 * different nodes can be returned in arbitrary order.
 */
template< typename T >
class RequestQueue
  : boost::noncopyable
{
public:
  /**
   * @brief Push request onto queue.
   *
   * Push the request  given by @e request, originating  from @e node,
   * to the queue. The user-defined @e data will be returned by wait()
   * when the request finishes.
   *
   * @param node Node the request originates from.
   * @param request MPI request as returned by Boost MPI library.
   * @param data User-defined data to be returned by wait() later.
   */
  void push( int node, const boost::mpi::request &request, const T &data );
  /**
   * @brief Wait for request.
   *
   * Wait for any request on the request queue to finish. This returns
   * the  resulting status  object of  an arbitrary  request  from the
   * request queue  that has already  finished, or block until  such a
   * request  is  available.  The  only  limitation  to  this is  that
   * requests from one  node will finish in the  exact order they have
   * been pushed onto the  queue with push().  Requests from different
   * nodes are allowed to finish in arbitrary order.
   *
   * @returns Pair of status object and user-defined object associated
   *   with the request when push() was called.
   *
   * @throws AssertionError when request queue is empty.
   */
  std::pair<boost::mpi::status, T> wait();
  /**
   * @brief Get size of queue.
   *
   * Get the  size of the request  queue, i.e., the  number of pending
   * requests  that have  not finished  and returned  a  status object
   * through wait().
   *
   * @returns Number of pending requests on queue.
   */
  unsigned size() const;
  /**
   * @brief Check if queue is empty.
   *
   * Check if the request queue is empty. This will return @c false if
   * and only  if there is at  least one more request  to be collected
   * with wait().
   *
   * @returns @c true iff request queue is empty.
   */
  bool empty() const;

private:
  void assert_invariants() const;

private:
  std::vector<boost::mpi::request> front_requests_;
  std::vector<T> front_data_;

private:
  typedef std::map<int, std::deque<std::pair<boost::mpi::request, T> > > back_requests_t;
  back_requests_t back_requests_;
};


#include "request.ipp"

#endif //DICON_REQUEST_HPP_

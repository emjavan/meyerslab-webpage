#ifndef DICON_MANAGER_MAIN_HPP_
#define DICON_MANAGER_MAIN_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief MainNodeManager interface.
 */
#include "manager.hpp"
#include "message.hpp"
#include "request.hpp"
#include <queue>


/**
 * @brief Node state.
 *
 * The NodeState enum describes the state any given processing node is
 * currently   in.     It   can    be   queried   using    the   @link
 * MainNodeManager::state()    state()@endlink     method    of    the
 * MainNodeManager    class.     Except    for    @link    ::NODE_IDLE
 * NODE_IDLE@endlink,  the  node  states  correspond directly  to  the
 * messages  used  for  node  intercommunication, as  defined  in  the
 * documentation of the message.hpp file.
 */
enum NodeState
{ NODE_IDLE                   /// Node is idle.
, NODE_STARTING_LOGGING       /// Node is starting logging.
, NODE_INITIALIZING_OPTIMIZER /// Node is initializing %optimizer.
, NODE_INITIALIZING_SIMULATOR /// Node is initializing simulator.
, NODE_INITIALIZING_COMBINED  /// Node is initializing combined %optimizer/simulator.
, NODE_GETTING_POLICY         /// Node is getting policy (regular %optimizer only).
, NODE_SIMULATING             /// Node is simulating (simulator only).
, NODE_UPDATING               /// Node is updating (regular %optimizer only).
, NODE_STEPPING_COMBINED      /// Node is stepping (combined %optimizer/simulator only).
, NODE_DUMPING_OPTIMIZER      /// Node is dumping %optimizer state (%optimizer only).
, NODE_DUMPING_POLICIES       /// Node is dumping policies (%optimizer only).
, NODE_SHUTTING_DOWN          /// Node is shutting down.
};

/// Output textual representation of node state.
std::ostream &operator<<( std::ostream &out, NodeState state );


namespace detail {
  class AnswerDispatcher;
}

/**
 * @brief Main node manager interface.
 *
 * The  MainNodeManager  class  provides  the interface  to  the  node
 * manager running on the main node in the computing cluster. As such,
 * it provides methods for sending messages to the processing nodes in
 * the cluster, and must be  filled in with implementations of how the
 * main node manager reacts when each such request has finished.
 *
 * Each  of  those methods  and  each of  the  virtual  methods to  be
 * implemented corresponds to the %message with the same name used for
 * node  intercommunication, as  defined in  the documentation  of the
 * message.hpp  class,  and the  matching  structures  defined in  the
 * message::question   and   message::answer   namespaces.   See   the
 * documentation  that is given  there for  details on  each available
 * %message and its parameters.
 *
 * Calling  one  of  the  methods  start_logging(),  init_optimizer(),
 * init_simulator(),    init_combined(),   get_policy(),   simulate(),
 * update(),   step_combined(),   dump_optimizer(),   dump_policies(),
 * shutdown() sends the corresponding %message to the given processing
 * node,  returning immediately to  the caller,  i.e., the  request is
 * sent in a non-blocking way.  Calling process() waits for any one of
 * the   pending  requests   to  finish.    When  this   happens,  the
 * corresponding  <code>finish_</code>  method   is  called.   If  the
 * request failed, e.g., because an uncaught exception was thrown, the
 * handle_failure() method  is called  instead; in this  case, state()
 * can be used to figure out which request failed.
 *
 * More  than   one  request  can   be  sent  to  a   processing  node
 * simultaneously.  This way, a primitive backlog can be realized; the
 * processing node is guaranteed to  receive the requests in the order
 * they  are sent.  After  a number  of requests  have been  sent, the
 * corresponding <code>finish_</code>  methods are called  in the same
 * order,   with   handle_failure()    taking   the   place   of   any
 * <code>finish_</code> method whenever a request failed.
 *
 * A  request can  be  sent to  a  processing node  at  any time.   In
 * particular, new  requests can be initiated during  the execution of
 * any of the <code>finish_</code> methods and handle_failure().
 */
class MainNodeManager
  : public NodeManager
{
  friend class detail::AnswerDispatcher;

protected:
  /**
   * @brief Create main node manager.
   *
   * Constructor that creates a  new node manager. This constructor is
   * protected as the MainNodeManager  class is an abstract base class
   * that does not allow direct instantiation.
   *
   * @param world MPI communicator.
   */
  MainNodeManager( boost::mpi::communicator &world );

public:
  virtual ~MainNodeManager();

protected:
  /**
   * @brief Get minimum child ID.
   *
   * Get the node ID within the MPI communicator given on construction
   * that corresponds to the first processing node. This is guaranteed
   * to be 1.
   *
   * The  behavior of this  method is  not defined  when child_count()
   * returns 0.
   *
   * @returns Minimum child ID.
   */
  int min_child() const;
  /**
   * @brief Get maximum child ID.
   *
   * Get the node ID within the MPI communicator given on construction
   * that corresponds to the last processing node.
   *
   * The  behavior of this  method is  not defined  when child_count()
   * returns 0.
   *
   * @returns Maximum child ID.
   */
  int max_child() const;

  /**
   * @brief Get number of children.
   *
   * Get the  number of processing  nodes within the  MPI communicator
   * given  on construction.   When  this  is 0,  only  the main  node
   * exists.  In  this case, the  behavior of calling  min_child() and
   * max_child() is not defined.
   *
   * @returns Number of children.
   */
  unsigned child_count() const;

protected:
  /// Start logging on processing node given by @e node.
  void start_logging ( int node, const boost::filesystem::path &logfile, LogLevel min_level         );
  /// Initialize %optimizer on processing node given by @e node.
  void init_optimizer( int node
                     , const boost::filesystem::path &optimizer_logfile
                     , const boost::filesystem::path &simulator_logfile
                     , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                     , const std::string &simulator_command, const arguments_t &simulator_arguments
                     , const boost::optional<boost::filesystem::path> &optimizer_map_file
                     , const boost::optional<boost::filesystem::path> &optimizer_lib_file           );
  /// Initialize simulator on processing node given by @e node.
  void init_simulator( int node
                     , const boost::filesystem::path &simulator_logfile
                     , const std::string &simulator_command, const arguments_t &simulator_arguments );
  /// Initialize  combined  %optimizer/simulator  on  processing  node
  /// given by @e node.
  void init_combined ( int node
                     , const boost::filesystem::path &optimizer_logfile
                     , const boost::filesystem::path &simulator_logfile
                     , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                     , const std::string &simulator_command, const arguments_t &simulator_arguments
                     , const boost::optional<boost::filesystem::path> &optimizer_map_file
                     , const boost::optional<boost::filesystem::path> &optimizer_lib_file           );
  /// Get next policy on processing node given by @e node.
  void get_policy    ( int node                                                                     );
  /// Simulate policy on processing node given by @e node.
  void simulate      ( int node, const policy_t &policy                                             );
  /// Update reward on processing node given by @e node.
  void update        ( int node, const policy_t &policy, double reward                              );
  /// Take step on processing node given by @e node.
  void step_combined ( int node                                                                     );
  /// Dump %optimizer state on processing node given by @e node.
  void dump_optimizer( int node, const boost::filesystem::path &file, DumpOptimizerMode mode        );
  /// Dump list of best policies on processing node given by @e node.
  void dump_policies ( int node, const boost::filesystem::path &file, unsigned count, bool display  );
  /// Shutdown on processing node given by @e node.
  void shutdown      ( int node                                                                     );

protected:
  /**
   * @brief Get node state.
   *
   * Get the  current state  of the  node given by  @e node.   If this
   * method is called during <code>handle_failure</code> or one of the
   * <code>finish_</code>  methods,  the  return value  describes  the
   * request  that is  currently  being processed.   Otherwise, it  is
   * equivalent to  the first request  this node will return  from, as
   * defined in the description of the MainNodeManager class, or @link
   * ::NODE_IDLE  NODE_IDLE@endlink  when  this  node has  no  pending
   * requests.
   *
   * @param node Node.
   * @returns Node state.
   *
   * @throws  AssertionError when  @e  node is  not  within the  range
   *   defined by min_child() and max_child().
   */
  NodeState state( int node ) const;

protected:
  /// Finish starting logging on processing node given by @e node.
  virtual void finish_start_logging ( int node                                          ) = 0;
  /// Finish initializing  %optimizer on  processing node given  by @e
  /// node.
  virtual void finish_init_optimizer( int node                                          ) = 0;
  /// Finish  initializing simulator  on processing  node given  by @e
  /// node.
  virtual void finish_init_simulator( int node                                          ) = 0;
  /// Finish initializing  combined %optimizer/simulator on processing
  /// node given by @e node.
  virtual void finish_init_combined ( int node                                          ) = 0;
  /// Finish getting next policy on processing node given by @e node.
  virtual void finish_get_policy    ( int node, const boost::optional<policy_t> &policy ) = 0;
  /// Finish simulating policy on processing node given by @e node.
  virtual void finish_simulate      ( int node, double reward                           ) = 0;
  /// Finish updating reward on processing node given by @e node.
  virtual void finish_update        ( int node                                          ) = 0;
  /// Finish taking step on processing node given by @e node.
  virtual void finish_step_combined ( int node, bool got_policy                         ) = 0;
  /// Finish dumping  %optimizer state on processing node  given by @e
  /// node.
  virtual void finish_dump_optimizer( int node                                          ) = 0;
  /// Finish dumping policies on processing node given by @e node.
  virtual void finish_dump_policies ( int node                                          ) = 0;
  /// Finish shutting down on processing node given by @e node.
  virtual void finish_shutdown      ( int node, bool done                               ) = 0;

  /**
   * @brief Handle failure while processing request.
   *
   * Handle the  failure that occured while processing  the request on
   * the processing  node given by @e  node. This method  is called in
   * place of the corresponding <code>finish_</code> method whenever a
   * request failed  to complete on  a processing node, as  defined in
   * the description  of the  MainNodeManager class. The  parameter @e
   * what  contains a detailed  description of  the error  (though not
   * necessarily in a user friendly format).
   *
   * @param node Node that failed.
   * @param what Description of error.
   */
  virtual void handle_failure       ( int node, const std::string &what                 ) = 0;

  /**
   * @brief Wait for and finish one request.
   *
   * Wait for  any one  of the pending  requests sent to  a processing
   * node and  finish it. This call  blocks until at least  one of the
   * requests asynchronously  sent to any processing  node returns. It
   * then  calls  the  corresponding  <code>finish_</code>  method  or
   * handle_failure(). Requests for any  single node are guaranteed to
   * both be  processed by  the processing node  and finished  by this
   * method in the exact order  they were sent.  Requests to different
   * nodes are allowed to be finished in any order.
   *
   * @returns @c false iff no request is pending.
   */
  bool process();

private:
  typedef std::queue<NodeState> state_queue_t;

  int &current_tag( int node );
  state_queue_t &state_queue( int node );
  const state_queue_t &state_queue( int node ) const;

  template< typename Q >
  void async_enqueue( int node, const Q &question, NodeState state );

private:
  struct RequestData {
    boost::shared_ptr<message::Answer> answer;
    int which_message;
  };

  struct NodeRecord {
    int current_tag;
    state_queue_t state_queue;

    NodeRecord( int min_tag );
  };

private:
  std::deque<boost::mpi::request> isend_queue_;
  RequestQueue<RequestData> request_queue_;
  std::vector<NodeRecord> nodes_;
};

#endif //DICON_MANAGER_MAIN_HPP_

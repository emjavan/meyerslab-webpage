/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "stats.hpp"
#include "error.hpp"
#include <boost/foreach.hpp>
#include <boost/format.hpp>
#include <cerrno>
#include <cmath>


namespace detail {

  static
  timeval
  time() {
    struct timeval tv;

    if( gettimeofday(&tv, NULL) != 0 )
      BOOST_THROW_EXCEPTION( TimeError() << errinfo_api_function("gettimeofday") << errinfo_errno(errno) );

    return tv;
  }


  static
  double
  time_difference( const timeval &a, const timeval &b ) {
    return double(a.tv_sec) - double(b.tv_sec + 1) +
      double(a.tv_usec + 1000000 - b.tv_usec) / 1000000;
  }


  static
  std::string
  time_to_str( double time ) {
    double days = floor(time/60/60/24);
    time -= days * 60*60*24;
    double hours = floor(time/60/60);
    time -= hours * 60*60;
    double minutes = floor(time/60);
    time -= minutes * 60;
    double seconds = round(time);
    time -= seconds;

    return (boost::format("%3.0f days %02.0f:%02.0f:%02.0f") % days % hours % minutes % seconds).str();
  }

}



Statistics::TimeRecord::TimeRecord()
  : running_(false), ticks_(0), total_time_(0)
{
}


void
Statistics::TimeRecord::start( bool tick ) {
  if( running_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  last_start_ = detail::time();
  if( tick ) ++ticks_;
  running_ = true;
}


void
Statistics::TimeRecord::stop() {
  if( !running_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  total_time_ += std::max<double>( 0, detail::time_difference(detail::time(), last_start_) );
  running_ = false;
}


double
Statistics::TimeRecord::time() const {
  if( running_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  return total_time_;
}


uint64_t
Statistics::TimeRecord::ticks() const {
  if( running_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  return ticks_;
}


Statistics::Statistics() {
  records_[current_].start();
}


void
Statistics::print( std::ostream &output ) {
  static const std::string root = "(total)";
  static const size_t indent_per_level = 3;

  path_t current = current_;

  // Stop all records.

  while( true ) {
    records_[current].stop();
    if( current.empty() )
      break;
    current.pop_back();
  }

  // Print out stats.

  assert( current.empty() );
  double total = records_.at(current).time();

  size_t max_length = 0;
  BOOST_FOREACH( const records_t::value_type &entry, records_ ) {
    const path_t &path = entry.first;

    max_length = std::max<size_t>( max_length,
                                   path.size() * indent_per_level +
                                   (path.empty() ? root : path.back().second).length() );
  }

  output << ( boost::format("name%s        ticks    %%/rel    %%/tot    %stotal time\n")
            % std::string(max_length - std::string("name").length(), ' ')
            % std::string(detail::time_to_str(0).length() - std::string("total time").length(), ' ')
            );

  BOOST_FOREACH( const records_t::value_type &entry, records_ ) {
    const path_t &path = entry.first;
    const TimeRecord &record = entry.second;

    size_t indent = path.size() * indent_per_level;
    const std::string &node = path.empty() ? root : path.back().second;
    double parent = path.empty() ? total
                  : records_.at(path_t(path.begin(), --path.end())).time();

    output << ( boost::format("%s%s%s    %9u    %5.1f    %5.1f    %s\n")
              % std::string(indent, ' ')
              % node
              % std::string(max_length - node.length() - indent, ' ')
              % record.ticks()
              % (record.time() / parent * 100)
              % (record.time() / total * 100)
              % detail::time_to_str(record.time())
              );
  }

  // Restart records.

  assert( current.empty() );
  records_[current].start();
  BOOST_FOREACH( const path_t::value_type &entry, current_ ) {
    current.push_back( entry );
    records_[current].start();
  }
}


void
Statistics::push_( const std::pair<int, std::string> &entry, bool tick ) {
  current_.push_back( entry );
  records_[current_].start( tick );
}


void
Statistics::pop_() {
  if( current_.empty() )
    BOOST_THROW_EXCEPTION( AssertionError() );

  records_[current_].stop();
  current_.pop_back();
}


void
Statistics::push( const std::string &what, int priority, const std::string &idle, int idle_priority ) {
  if( !idlers_.empty() && !idlers_.back().second.empty() )
    pop_();

  push_( std::make_pair(priority, what), true );

  idlers_.push_back( std::make_pair(idle_priority, idle) );

  if( !idlers_.back().second.empty() )
    push_( idlers_.back(), false );
}


void
Statistics::pop() {
  if( idlers_.empty() )
    BOOST_THROW_EXCEPTION( AssertionError() );

  if( !idlers_.back().second.empty() )
    pop_();

  pop_();

  idlers_.pop_back();

  if( !idlers_.empty() && !idlers_.back().second.empty() )
    push_( idlers_.back(), false );
}


StatsEntry::StatsEntry( Statistics &stats,
                        const std::string &what, int priority, const std::string &idle, int idle_priority )
  : stopped_(false), stats_(stats)
{
  stats_.push( what, priority, idle, idle_priority );
}


StatsEntry::~StatsEntry() {
  try {
    if( !stopped_ )
      stats_.pop();
  }
  catch( ... ) {
    // Ignore.
  }
}


void
StatsEntry::stop() {
  if( stopped_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  stats_.pop();

  stopped_ = true;
}

#ifndef DICON_JOB_QUEUE_HPP_
#define DICON_JOB_QUEUE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief JobQueue class.
 */
#include "error.hpp"
#include "job.hpp"
#include "lazy/set.hpp"
#include <boost/noncopyable.hpp>
#include <queue>


/// %Job queue related error.
struct JobQueueError : virtual Error
{ virtual const char *what() const throw() { return "Job queue related error."; } };

/// %Job queue has too many job.
struct JobQueueTooManyJobsError : virtual JobQueueError
{ virtual const char *what() const throw() { return "Job queue has too many jobs."; } };

/// %Job queue has not enough jobs.
struct JobQueueNotEnoughJobsError : virtual JobQueueError
{ virtual const char *what() const throw() { return "Job queue has not enough jobs."; } };


class Configuration;

/**
 * @brief Lazy queue for jobs.
 *
 * The JobQueue  class implements a lazy  queue for jobs.  This is the
 * main class where new jobs  (Job structure) are created. In order to
 * do this in  a memory-efficient way, new jobs  are only created when
 * requested.
 *
 * The job queue reads in  a configuration and stores all the relevant
 * information needed to create  the jobs defined in the configuration
 * at a later time.
 *
 * The methods  empty(), front(), and  pop() are used to  iterate over
 * the elements in the job queue. This can be accomplished as follows.
 *
 * @code
Configuration config;
// Read in configuration.

for( JobQueue queue(config); !queue.empty(); queue.pop() ) {
  // Access job with queue.front().
}
@endcode
 */
class JobQueue
  : boost::noncopyable
{
public:
  /**
   * @brief Read in configuration.
   *
   * Constructor  that   reads  in  the  configuration   given  by  @e
   * configuration and  stores all the relevant  information needed to
   * create the jobs defined in that configuration at a later time.
   *
   * @param configuration %Configuration.
   * @throws ConfigError or a derived class when necessary information
   *   is missing from the configuration,  or a config value could not
   *   be interpreted correctly.
   * @throws  JobQueueTooManyJobsError when  too many  jobs  have been
   *   defined.
   * @throws JobQueueNotEnoughJobsError when not enough jobs have been
   *   defined.
   */
  JobQueue( const Configuration &configuration );

public:
  /**
   * @brief Remove front job from queue.
   *
   * Remove  the  front job  from  the job  queue.   This  is used  in
   * combination with empty() and front() to iterate over all jobs.
   *
   * @throws AssertionError when job queue is empty.
   */
  void pop();

public:
  /**
   * @brief Check if job queue is empty.
   *
   * Check if  the job queue  is empty. This  returns @c false  if and
   * only if there is at least one more job in the queue.
   *
   * @returns @c true iff job queue is empty.
   */
  bool empty() const;
  /**
   * @brief Get front job from queue.
   *
   * Get the  front job from the  job queue.  This  method creates the
   * job (Job structure) as  necessary on-demand.  Subsequent calls to
   * this method return the same job object until pop() is called.
   *
   * @returns Front job.
   * @throws AssertionError when job queue is empty.
   */
  Job::ptr_t front() const;

public:
  /**
   * @brief Get total number of jobs.
   *
   * Get the total number of jobs in the queue. This includes all jobs
   * already removed from the queue by pop().
   *
   * @returns Total number of jobs in queue.
   */
  size_t total_jobs() const;
  /**
   * @brief Get number of jobs done.
   *
   * Get the  number of jobs that  have already been  removed from the
   * queue by pop().
   *
   * @returns Number of jobs removed from queue.
   */
  size_t total_done() const;

private:
  boost::filesystem::path job_dir( size_t job_set_id ) const;
  boost::filesystem::path arg_dir( size_t job_set_id ) const;

private:
  typedef LazySet<std::pair<arguments_t, arguments_t> > argument_set_t;

  struct JobTemplate {
    Job::ptr_t base_job;
    boost::shared_ptr<argument_set_t> argument_set;
  };

  std::queue<JobTemplate> jobs_;
  mutable Job::ptr_t front_job_;

  std::string job_dir_mask_;
  std::string arg_dir_mask_;

  std::string job_logfile_;
  LogLevel    job_log_level_;
  std::string checkpoint_file_;
  std::string opt_logfile_mask_;
  std::string sim_logfile_mask_;

  std::string optimizer_map_file_mask_;
  std::string optimizer_lib_file_mask_;
  std::string policy_bin_dumpfile_mask_;
  std::string policy_txt_dumpfile_mask_;

  unsigned    policy_count_;
  std::string policy_bin_result_;
  std::string policy_txt_result_;

  size_t job_count_;
  size_t jobs_done_;
};

#endif //DICON_JOB_QUEUE_HPP_

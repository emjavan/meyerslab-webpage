/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "specifier.hpp"
#include "config.hpp"
#include "lazy/set/combine.hpp"
#include "lazy/set/compose.hpp"
#include "lazy/set/concat.hpp"
#include "lazy/set/container.hpp"
#include "lazy/set/range.hpp"
#include "lazy/set/singleton.hpp"
#include "lazy/set/transform.hpp"
#include "lazy/set/union.hpp"
#include "lazy/value/binary.hpp"
#include "lazy/value/constant.hpp"
#include "lazy/value/unary.hpp"
#include "lazy/value/variable.hpp"
#include <boost/assign/list_of.hpp>
#include <boost/foreach.hpp>
#include <boost/function.hpp>
#include <boost/lambda/lambda.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/regex.hpp>
#include <boost/spirit/include/classic.hpp>
#include <boost/spirit/include/classic_grammar_def.hpp>
#include <boost/spirit/include/classic_parse_tree.hpp>
#include <boost/version.hpp>
#include <cmath>
#include <gmpxx.h>


#define DICON_ASSERT_PARSER_ID_(WHAT, ID)                               \
  do { if( (WHAT) != SpecifierGrammar::ID )                             \
      BOOST_THROW_EXCEPTION( AssertionError()                           \
                             << errinfo_value<parser_id>((WHAT))        \
                             << errinfo_expected_value<parser_id>       \
                             (SpecifierGrammar::ID) );                  \
  } while( false )                                                      \
    /**/

#define DICON_ASSERT_SIZE_(WHAT, VALUE)                                 \
  do { if( !((WHAT) == (VALUE)) )                                       \
      BOOST_THROW_EXCEPTION( AssertionError()                           \
                             << errinfo_value<size_t>((WHAT))           \
                             << errinfo_expected_value<size_t>          \
                             ((VALUE)) );                               \
  } while( false )                                                      \
    /**/

#define DICON_ASSERT_SIZE_MIN_(WHAT, VALUE)                             \
  do { if( !((WHAT) >= (VALUE)) )                                       \
      BOOST_THROW_EXCEPTION( AssertionError()                           \
                             << errinfo_value<size_t>((WHAT))           \
                             << errinfo_min_value<size_t>               \
                             ((VALUE)) );                               \
  } while( false )                                                      \
    /**/


namespace detail {

  typedef double real_t;
  typedef mpq_class rational_t;


  // We choose `real_to_rational_prec' deliberately slightly larger
  // than `real_to_string_prec' for the following reason. When using
  // expression ranges with additional expressions in the (sub)range
  // specifiers themselves, we want intuitive behavior, e.g., in the
  // following situation:
  //
  //   [x*10+y*3:x=1..10:y=(x)|(x+1/3)|(x+2/3)]
  //
  // The range should return only integer values. If both precisions
  // were the same, this would not necessarily happen: range bounds
  // are first rounded with `real_to_rational_prec', and then the
  // result of the calculating (which thus only has an effective
  // precision of 14), is rounded again.
  //
  // In order to conceal this lowered precision, we again round the
  // result, but with even slightly lower precision. Obviously, this
  // is a compromise between having "strange" artifacts (range bounds
  // missing in range) and precision of calculations. For the purpose
  // of floating-point arithmetic operations, 12 significant digits
  // are probably acceptable.

  static const std::streamsize real_to_string_prec = 12;
  static const std::streamsize real_to_rational_prec = 14;


  static const std::map<std::string, double(*)(double)> exp_range_functions
  = boost::assign::map_list_of<std::string, double(*)(double)>
#define DICON_NAME_FUNCTION_( x ) (#x, static_cast<double(*)(double)>(::x))
    DICON_NAME_FUNCTION_( sqrt   )
    DICON_NAME_FUNCTION_( round  )
    DICON_NAME_FUNCTION_( trunc  )
    DICON_NAME_FUNCTION_( floor  )
    DICON_NAME_FUNCTION_( ceil   )
    (            "abs", ::fabs   )

    DICON_NAME_FUNCTION_( log    )
    DICON_NAME_FUNCTION_( log2   )
    DICON_NAME_FUNCTION_( log10  )

    DICON_NAME_FUNCTION_( exp    )
    DICON_NAME_FUNCTION_( exp2   )
    DICON_NAME_FUNCTION_( exp10  )

    DICON_NAME_FUNCTION_( cos    )
    DICON_NAME_FUNCTION_( sin    )
    DICON_NAME_FUNCTION_( tan    )

    DICON_NAME_FUNCTION_( acos   )
    DICON_NAME_FUNCTION_( asin   )
    DICON_NAME_FUNCTION_( atan   )

    DICON_NAME_FUNCTION_( cosh   )
    DICON_NAME_FUNCTION_( sinh   )
    DICON_NAME_FUNCTION_( tanh   )

    DICON_NAME_FUNCTION_( acosh  )
    DICON_NAME_FUNCTION_( asinh  )
    DICON_NAME_FUNCTION_( atanh  )

    (          "gamma", ::tgamma )
    (         "lgamma", ::lgamma )

    DICON_NAME_FUNCTION_( log1p  )
    DICON_NAME_FUNCTION_( expm1  )

    DICON_NAME_FUNCTION_( erf    )
    DICON_NAME_FUNCTION_( erfc   )

    DICON_NAME_FUNCTION_( j0     )
    DICON_NAME_FUNCTION_( j1     )

    DICON_NAME_FUNCTION_( y0     )
    DICON_NAME_FUNCTION_( y1     )
#undef DICON_NAME_FUNCTION_
    ;


  using namespace boost::spirit::classic;

  struct SpecifierGrammar
    : public grammar<SpecifierGrammar>
  {
    enum
    { specifier_id = 1

    , set_id
    , range_id
    , exp_range_id
    , exp_subrange_id

    , lazy_range_id
    , lazy_singleton_id
    , lazy_simple_range_id
    , lazy_extended_range_id
    , exp_or_real_id

    , expression_id
    , term_id
    , factor_id
    , group_id

    , identifier_id
    , literal_id
    , real_id

    , argument_id
    , schedule_id
    };

    enum
    { argument = 0
    , schedule = 1
    };

    template< typename scanner_t >
    struct definition
      : grammar_def< rule<scanner_t, parser_tag<argument_id> >
                   , rule<scanner_t, parser_tag<schedule_id> >
                   >
    {
      definition( const SpecifierGrammar &self ) {
        specifier           = +( (no_node_d[ch_p('{')] >> (set              ) >> no_node_d[ch_p('}')])
                               | (no_node_d[ch_p('[')] >> (exp_range | range) >> no_node_d[ch_p(']')])
                               | (                        (literal          )                        ) );

        set                 =  specifier % no_node_d[ch_p('|')];
        range               =  lazy_range;
        exp_range           =  expression
                            >> no_node_d[ch_p(':')]
                            >> (exp_subrange % no_node_d[ch_p(':')]);
        exp_subrange        =  !(identifier >> no_node_d[ch_p('=')])
                            >> lazy_range;

        lazy_range          =  (lazy_extended_range | lazy_simple_range | lazy_singleton) % no_node_d[ch_p('|')];
        lazy_singleton      =  exp_or_real;
        lazy_simple_range   =  exp_or_real
                            >> no_node_d[str_p("..")] >> !exp_or_real;
        lazy_extended_range =  exp_or_real
                            >> no_node_d[ch_p (',' )] >>  exp_or_real
                            >> no_node_d[str_p("..")] >> !exp_or_real;
        exp_or_real         =  (expression - real) | real;

        expression          =  term % chset_p("+-");
        term                =  factor % chset_p("*/");
        factor              =  ( (group >> ch_p('^') >> factor)
                               | (chset_p("+-") >> group)
                               | group
                               );
        group               =  ( (identifier >> no_node_d[ch_p('(')] >> expression >> no_node_d[ch_p(')')])
                               | (              no_node_d[ch_p('(')] >> expression >> no_node_d[ch_p(')')])
                               | identifier
                               | real
                               );

        identifier          =  leaf_node_d[   (alpha_p | ch_p('_')          )
                                          >> *(alpha_p | ch_p('_') | digit_p)
                                          ];
        literal             =  leaf_node_d[  +( (ch_p('"' ) >> *(~ch_p('"' )) >> ch_p('"' ))
                                              | (ch_p('\'') >> *(~ch_p('\'')) >> ch_p('\''))
                                              | +(~chset_p("|[]{}'\""))
                                              ) ];
        real                =  leaf_node_d[  !chset_p("+-")
                                          >> +digit_p
                                          >> !(ch_p   ('.')  >>                   +digit_p)
                                          >> !(chset_p("eE") >> !chset_p("+-") >> +digit_p)
                                          ];

        argument            =  set;
        schedule            =  ( (no_node_d[ch_p('[')] >> (exp_range | range) >> no_node_d[ch_p(']')])
                               | (exp_or_real % no_node_d[ch_p(',')])
                               );

        start_parsers( argument, schedule );
      }

      rule<scanner_t, parser_tag<specifier_id          > > specifier;

      rule<scanner_t, parser_tag<set_id                > > set;
      rule<scanner_t, parser_tag<range_id              > > range;
      rule<scanner_t, parser_tag<exp_range_id          > > exp_range;
      rule<scanner_t, parser_tag<exp_subrange_id       > > exp_subrange;

      rule<scanner_t, parser_tag<lazy_range_id         > > lazy_range;
      rule<scanner_t, parser_tag<lazy_singleton_id     > > lazy_singleton;
      rule<scanner_t, parser_tag<lazy_simple_range_id  > > lazy_simple_range;
      rule<scanner_t, parser_tag<lazy_extended_range_id> > lazy_extended_range;
      rule<scanner_t, parser_tag<exp_or_real_id        > > exp_or_real;

      rule<scanner_t, parser_tag<expression_id         > > expression;
      rule<scanner_t, parser_tag<term_id               > > term;
      rule<scanner_t, parser_tag<factor_id             > > factor;
      rule<scanner_t, parser_tag<group_id              > > group;

      rule<scanner_t, parser_tag<identifier_id         > > identifier;
      rule<scanner_t, parser_tag<literal_id            > > literal;
      rule<scanner_t, parser_tag<real_id               > > real;

      rule<scanner_t, parser_tag<argument_id           > > argument;
      rule<scanner_t, parser_tag<schedule_id           > > schedule;
    };
  };


  class ExpressionOrReal {
  public:
    ExpressionOrReal( LazyValue<real_t>::ptr_t &expression )
      : expression_(expression)
    {
    }

    ExpressionOrReal( const rational_t &real )
      : real_(real)
    {
    }

    bool is_expression() const { return expression_; }
    bool is_real() const { return !is_expression(); }

    const LazyValue<real_t> &expression() const {
      assert( is_expression() );
      return *expression_;
    }

    const rational_t &real() const {
      assert( is_real() );
      return real_;
    }

  private:
    boost::shared_ptr<LazyValue<real_t> > expression_;
    rational_t real_;
  };


  class LazyRange
    : boost::noncopyable
  {
  public:
    typedef rational_t value_t;
    typedef std::auto_ptr<LazyRange> ptr_t;
    typedef std::set<std::string> references_t;
    typedef std::map<std::string, real_t> variables_t;

  public:
    virtual ~LazyRange() {}
    virtual references_t references() const = 0;
    virtual LazySet<rational_t>::ptr_t operator()( const variables_t &variables ) const = 0;
  };


  static
  rational_t
  string_to_rational( const std::string &x ) {
#if BOOST_VERSION >= 104000
    boost::regex regex("(?<sgn>[+-])?(?<int>\\d+)(?:\\.(?<dec>\\d+))?(?:[eE](?<exp>[+-]?\\d+))?");
#else
    boost::regex regex("("    "[+-])?("    "\\d+)(?:\\.("    "\\d+))?(?:[eE]("    "[+-]?\\d+))?");
#endif

    boost::smatch match;
    if( !boost::regex_match(x, match, regex) )
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<std::string>(x) );

    assert( match.size() == 5 );
#if BOOST_VERSION >= 104000
    const std::string &sgn_part = match.str("sgn");
    const std::string &int_part = match.str("int");
    const std::string &dec_part = match.str("dec");
    const std::string &exp_part = match.str("exp");
#else
    const std::string &sgn_part = match.str(1);
    const std::string &int_part = match.str(2);
    const std::string &dec_part = match.str(3);
    const std::string &exp_part = match.str(4);
#endif

    rational_t res;
    res += rational_t(int_part, 10);

    if( !dec_part.empty() )
      res += rational_t(dec_part, 10) / rational_t("1" + std::string(dec_part.length(), '0'), 10);

    if( !exp_part.empty() ) {
      ssize_t exp = boost::lexical_cast<ssize_t>( exp_part );

      if( exp > 0 )
        res *= rational_t("1" + std::string( exp, '0'), 10);
      else if( exp < 0 )
        res /= rational_t("1" + std::string(-exp, '0'), 10);
    }

    if( sgn_part == "-" )
      res *= -1;

    return res;
  }


  struct RealToString {
    typedef std::string result_type;
    typedef real_t argument_type;

    RealToString( std::streamsize prec = real_to_string_prec )
      : prec(prec)
    {
    }

    result_type
    operator()( const argument_type &x ) const {
      if( !std::isfinite(x) )
        BOOST_THROW_EXCEPTION( CalculationNotFiniteError() << errinfo_value<argument_type>(x) );

      std::stringstream str;
      str.precision( prec );
      str << mpf_class(x);
      return str.str();
    }

    std::streamsize prec;
  };


  struct RationalToString {
    typedef std::string result_type;
    typedef rational_t argument_type;

    result_type
    operator()( const argument_type &x ) const {
      std::stringstream str;
      str.precision( 12 );
      str << mpf_class(x);
      return str.str();
    }
  };


  struct RealToRational {
    typedef rational_t result_type;
    typedef real_t argument_type;

    result_type
    operator()( const argument_type &x ) const {
      // This adds a slight rounding (14 significant digits where real_t
      // can provide roughly 16 digits). This makes for more predictable
      // behavior, as on some system, e.g., the expression "7/10*7*10/7"
      // evaluates to something slightly less than 7. If this was used
      // as an upper bound in an interval this upper bound would not
      // be included in this interval, quite counterintuitively.

      return string_to_rational( RealToString(real_to_rational_prec)(x) );
    }
  };


  class RangeFactory
    : public LazyRange
  {
  public:
    RangeFactory( const ExpressionOrReal &value )
      : lower_(value), sort_(false), open_(false)
    {
    }

    RangeFactory( const ExpressionOrReal &lower, const boost::optional<ExpressionOrReal> &upper, bool sort )
      : lower_(lower), upper_(upper), sort_(sort), open_(!upper)
    {
    }

    RangeFactory( const ExpressionOrReal &lower, const ExpressionOrReal &first, const boost::optional<ExpressionOrReal> &upper, bool sort )
      : lower_(lower), first_(first), upper_(upper), sort_(sort), open_(!upper)
    {
    }

  private:
    static
    void
    add_to_set( references_t &references, const boost::optional<ExpressionOrReal> &x ) {
      if( x && x->is_expression() ) {
        const references_t &refs = x->expression().references();
        references.insert( refs.begin(), refs.end() );
      }
    }

    static
    rational_t
    evaluate( const boost::optional<ExpressionOrReal> &x, const variables_t &variables, const rational_t &fallback ) {
      if( x )
        return x->is_expression() ? RealToRational()(x->expression()(variables)) : x->real();
      else
        return fallback;
    }

    static
    rational_t
    trunc_rational( const rational_t &x ) {
      return rational_t( x.get_num() / x.get_den() );
    }

    static
    LazySet<rational_t>::ptr_t
    create_range( const rational_t &lower, const rational_t &step, bool sort ) {
      if( step == 0 ) {
        BOOST_THROW_EXCEPTION( SpecifierRangeZeroStepError()
                               << errinfo_value<std::string>((boost::format("[%s,%s..]")
                                                              % RationalToString()(lower)
                                                              % RationalToString()(lower+step)).str()) );
      }

      if( !sort || step >= 0 )
        return lazy_range( lower, step );
      else {
        BOOST_THROW_EXCEPTION( SpecifierRangeUnboundedError()
                               << errinfo_value<std::string>((boost::format("[%s,%s..]")
                                                              % RationalToString()(lower)
                                                              % RationalToString()(lower+step)).str()) );
      }
    }

    static
    LazySet<rational_t>::ptr_t
    create_range( const rational_t &lower, const rational_t &upper, const rational_t &step, bool sort ) {
      if( step == 0 ) {
        BOOST_THROW_EXCEPTION( SpecifierRangeZeroStepError()
                               << errinfo_value<std::string>((boost::format("[%s,%s..%s]")
                                                              % RationalToString()(lower)
                                                              % RationalToString()(lower+step)
                                                              % RationalToString()(upper)).str()) );
      }

      if( !sort || step >= 0 || upper > lower )
        return lazy_range( lower, upper, step );
      else {
        // In order for merging (with lazy_union) to work, range must
        // be ordered. The following code exactly reverses the range.

        return lazy_range( rational_t(lower + trunc_rational((upper - lower) / step) * step), lower, rational_t(-step) );
      }
    }

  public:
    references_t
    references() const {
      references_t references;

      add_to_set( references, lower_ );
      add_to_set( references, first_ );
      add_to_set( references, upper_ );

      return references;
    }

    LazySet<rational_t>::ptr_t
    operator()( const variables_t &variables ) const {
      rational_t lower = evaluate( lower_, variables, 0       );
      rational_t upper = evaluate( upper_, variables, lower   );
      rational_t first = evaluate( first_, variables, lower+1 );

      if( open_ )
        return create_range( lower,        rational_t(first-lower), sort_ );
      else
        return create_range( lower, upper, rational_t(first-lower), sort_ );
    }

  private:
    boost::optional<ExpressionOrReal> lower_;
    boost::optional<ExpressionOrReal> first_;
    boost::optional<ExpressionOrReal> upper_;
    bool sort_;
    bool open_;
  };

  static
  LazyRange::ptr_t
  range_factory( const ExpressionOrReal &value ) {
    return LazyRange::ptr_t( new RangeFactory(value) );
  }

  static
  LazyRange::ptr_t
  range_factory( const ExpressionOrReal &lower,
                 const boost::optional<ExpressionOrReal> &upper, bool sort )
  {
    return LazyRange::ptr_t( new RangeFactory(lower, upper, sort) );
  }

  static
  LazyRange::ptr_t
  range_factory( const ExpressionOrReal &lower,
                 const ExpressionOrReal &first,
                 const boost::optional<ExpressionOrReal> &upper, bool sort )
  {
    return LazyRange::ptr_t( new RangeFactory(lower, first, upper, sort) );
  }


  class RangeUnion
    : public LazyRange
  {
  public:
    RangeUnion( LazyRange::ptr_t &a, LazyRange::ptr_t &b )
      : a_(a), b_(b)
    {
    }

  private:
    static
    void
    add_to_set( references_t &references, const LazyRange::ptr_t &x ) {
      const references_t &refs = x->references();
      references.insert( refs.begin(), refs.end() );
    }

  public:
    virtual
    references_t
    references() const {
      references_t references;

      add_to_set( references, a_ );
      add_to_set( references, b_ );

      return references;
    }

    virtual
    LazySet<rational_t>::ptr_t
    operator()( const variables_t &variables ) const {
      return lazy_union( (*a_)(variables), (*b_)(variables) );
    }

  private:
    const LazyRange::ptr_t a_;
    const LazyRange::ptr_t b_;
  };

  static
  LazyRange::ptr_t
  range_union( LazyRange::ptr_t &a, LazyRange::ptr_t &b ) {
    return LazyRange::ptr_t( new RangeUnion(a, b) );
  }


  static LazySet<std::string>::ptr_t parse_specifier          ( const tree_node<node_val_data<> > &node                    );

  static LazySet<std::string>::ptr_t parse_set                ( const tree_node<node_val_data<> > &node                    );
  static LazySet<rational_t>::ptr_t  parse_range              ( const tree_node<node_val_data<> > &node, bool sort = false );
  static LazySet<real_t>::ptr_t      parse_exp_range          ( const tree_node<node_val_data<> > &node                    );
  static LazyRange::ptr_t            parse_exp_subrange       ( const tree_node<node_val_data<> > &node, std::string &name );

  static LazyRange::ptr_t            parse_lazy_range         ( const tree_node<node_val_data<> > &node, bool sort = false );
  static LazyRange::ptr_t            parse_lazy_singleton     ( const tree_node<node_val_data<> > &node                    );
  static LazyRange::ptr_t            parse_lazy_simple_range  ( const tree_node<node_val_data<> > &node, bool sort         );
  static LazyRange::ptr_t            parse_lazy_extended_range( const tree_node<node_val_data<> > &node, bool sort         );
  static ExpressionOrReal            parse_exp_or_real        ( const tree_node<node_val_data<> > &node                    );

  static LazyValue<real_t>::ptr_t    parse_expression         ( const tree_node<node_val_data<> > &node                    );
  static LazyValue<real_t>::ptr_t    parse_term               ( const tree_node<node_val_data<> > &node                    );
  static LazyValue<real_t>::ptr_t    parse_factor             ( const tree_node<node_val_data<> > &node                    );
  static LazyValue<real_t>::ptr_t    parse_group              ( const tree_node<node_val_data<> > &node                    );

  static std::string                 parse_identifier         ( const tree_node<node_val_data<> > &node                    );
  static std::string                 parse_literal            ( const tree_node<node_val_data<> > &node                    );
  static rational_t                  parse_real               ( const tree_node<node_val_data<> > &node                    );

  static LazySet<std::string>::ptr_t parse_argument           ( const tree_node<node_val_data<> > &node                    );
  static LazySet<simcount_t>::ptr_t  parse_schedule           ( const tree_node<node_val_data<> > &node                    );


  static
  LazySet<std::string>::ptr_t
  parse_specifier( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), specifier_id );
    DICON_ASSERT_SIZE_MIN_( node.children.size(), 1 );

    LazySet<std::string>::ptr_t combined;

    BOOST_FOREACH( const tree_node<node_val_data<> > &child, node.children ) {
      LazySet<std::string>::ptr_t current;

      if( child.value.id() == SpecifierGrammar::set_id )
        current = parse_set( child );
      else if( child.value.id() == SpecifierGrammar::exp_range_id )
        current = lazy_transform( parse_exp_range(child), RealToString() );
      else if( child.value.id() == SpecifierGrammar::range_id )
        current = lazy_transform( parse_range(child), RationalToString() );
      else if( child.value.id() == SpecifierGrammar::literal_id )
        current = lazy_singleton( parse_literal(child) );
      else
        BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<parser_id>(child.value.id()) );

      assert( current.get() );
      if( combined.get() ) {
        combined = lazy_combine( combined, current,
                                 std::plus<std::string>() );
      }
      else
        combined = current;
    }

    assert( combined.get() );
    return combined;
  }


  static
  LazySet<std::string>::ptr_t
  parse_set( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), set_id );
    DICON_ASSERT_SIZE_MIN_( node.children.size(), 1 );

    LazySet<std::string>::ptr_t combined;

    BOOST_FOREACH( const tree_node<node_val_data<> > &child, node.children ) {
      LazySet<std::string>::ptr_t current;

      if( child.value.id() == SpecifierGrammar::specifier_id )
        current = parse_specifier( child );
      else
        BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<parser_id>(child.value.id()) );

      assert( current.get() );
      if( combined.get() )
        combined = lazy_concat( combined, current );
      else
        combined = current;
    }

    assert( combined.get() );
    return combined;
  }


  static
  LazySet<rational_t>::ptr_t
  parse_range( const tree_node<node_val_data<> > &node, bool sort ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), range_id );
    DICON_ASSERT_SIZE_( node.children.size(), 1 );

    LazyRange::ptr_t range = parse_lazy_range( node.children.front(), sort );
    const LazyRange::references_t &references = range->references();

    if( !references.empty() )
      BOOST_THROW_EXCEPTION( SpecifierUndefinedVariableError() << errinfo_specifier_variable_name(*references.begin()) );

    return (*range)( LazyRange::variables_t() );
  }


  template< typename C, typename T = typename C::value_type >
  struct Insert {
    typedef C result_type;
    typedef C first_argument_type;
    typedef T second_argument_type;

    result_type
    operator()( first_argument_type x, const second_argument_type &y ) const {
      x.insert( y );
      return x;
    }
  };


  struct RationalToReal {
    typedef real_t result_type;
    typedef rational_t argument_type;

    result_type
    operator()( const argument_type &x ) const {
      return x.get_d();
    }
  };


  template< typename T1, typename T2 >
  struct MakePair2nd {
    typedef typename std::pair<T1, T2> result_type;
    typedef T2 argument_type;

    MakePair2nd( const T1 &first )
      : first(first)
    {
    }

    result_type
    operator()( const argument_type &second ) const {
      return std::make_pair<T1, T2>( first, second );
    }

    const T1 first;
  };


  struct PushRange {
    typedef LazySet<std::map<std::string, real_t> >::ptr_t result_type;
    typedef std::map<std::string, real_t> argument_type;

    PushRange( const std::string &name, LazyRange::ptr_t &range )
      : name(name), range(range)
    {
    }

    result_type
    operator()( const argument_type &variables ) const {
      LazySet<rational_t>::ptr_t range = (*this->range)( variables );

      return lazy_combine( lazy_singleton(variables)
                         , lazy_transform( lazy_transform(range, RationalToReal()),
                                           MakePair2nd<std::string, real_t>(name) )
                         , Insert<std::map<std::string, real_t> >()
                         );
    }

    const std::string name;
    const boost::shared_ptr<LazyRange> range;
  };


  static
  std::string
  first_range_name() {
    return "x";
  }


  static
  void
  next_range_name( std::string &name ) {
    assert( name.length() == 1 );

    if( 'x' <= name[0] && name[0] < 'z' )
      ++name[0];
    else if( name[0] == 'z' )
      name[0] = 'a';
    else if( 'a' <= name[0] && name[0] < 'x'-1 )
      ++name[0];
    else
      BOOST_THROW_EXCEPTION( SpecifierTooManyVariablesError() );
  }


  template< typename T >
  struct ApplyExpression {
    typedef T result_type;
    typedef typename LazyValue<T>::variables_t argument_type;

    ApplyExpression( typename LazyValue<T>::ptr_t &expression )
      : expression(expression)
    {
    }

    result_type
    operator()( const argument_type &variables ) const {
      return (*expression)( variables );
    }

    const boost::shared_ptr<LazyValue<T> > expression;
  };


  static
  LazySet<real_t>::ptr_t
  parse_exp_range( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), exp_range_id );
    DICON_ASSERT_SIZE_MIN_( node.children.size(), 2 );

    std::set<std::string> vars_defined, vars_used;
    LazySet<std::map<std::string, real_t> >::ptr_t combined = lazy_singleton( std::map<std::string, real_t>() );

    boost::optional<std::string> fallback_name;
    for( size_t i = 1; i < node.children.size(); ++i ) {
      std::string name;
      LazyRange::ptr_t range = parse_exp_subrange( node.children[i], name );

      if( name.empty() ) {
        if( fallback_name )
          next_range_name( *fallback_name );
        else
          fallback_name = first_range_name();

        name = *fallback_name;
      }

      if( (vars_defined.find(name)) != vars_defined.end() )
        BOOST_THROW_EXCEPTION( SpecifierVariableRedefinedError() << errinfo_specifier_variable_name(name) );

      BOOST_FOREACH( const std::string &ref_name, range->references() ) {
        if( vars_defined.find(ref_name) == vars_defined.end() )
          BOOST_THROW_EXCEPTION( SpecifierUndefinedVariableError() << errinfo_specifier_variable_name(ref_name) );

        vars_used.insert( ref_name );
      }

      assert( combined.get() );
      combined = lazy_compose( combined, PushRange(name, range) );

      vars_defined.insert( name );
    }

    LazyValue<real_t>::ptr_t expression = parse_expression( node.children[0] );

    BOOST_FOREACH( const std::string &ref_name, expression->references() ) {
      if( vars_defined.find(ref_name) == vars_defined.end() )
        BOOST_THROW_EXCEPTION( SpecifierUndefinedVariableError() << errinfo_specifier_variable_name(ref_name) );

      vars_used.insert( ref_name );
    }

    BOOST_FOREACH( const std::string &name, vars_defined ) {
      if( vars_used.find(name) == vars_used.end() )
        BOOST_THROW_EXCEPTION( SpecifierUnusedVariableError() << errinfo_specifier_variable_name(name) );
    }

    assert( combined.get() );
    return lazy_transform( combined, ApplyExpression<real_t>(expression) );
  }


  static
  LazyRange::ptr_t
  parse_exp_subrange( const tree_node<node_val_data<> > &node, std::string &name ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), exp_subrange_id );

    if( node.children.size() == 2 )
      name = parse_identifier( node.children[0] );
    else if( node.children.size() == 1 )
      name.clear();
    else
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<size_t>(node.children.size()) );

    return parse_lazy_range( node.children[node.children.size()-1] );
  }


  static
  LazyRange::ptr_t
  parse_lazy_range( const tree_node<node_val_data<> > &node, bool sort_ ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), lazy_range_id );
    DICON_ASSERT_SIZE_MIN_( node.children.size(), 1 );

    LazyRange::ptr_t combined;

    const bool sort = sort_ || (node.children.size() > 1);
    BOOST_FOREACH( const tree_node<node_val_data<> > &child, node.children ) {
      LazyRange::ptr_t current;

      if( child.value.id() == SpecifierGrammar::lazy_extended_range_id )
        current = parse_lazy_extended_range( child, sort );
      else if( child.value.id() == SpecifierGrammar::lazy_simple_range_id )
        current = parse_lazy_simple_range( child, sort );
      else if( child.value.id() == SpecifierGrammar::lazy_singleton_id )
        current = parse_lazy_singleton( child );
      else
        BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<parser_id>(child.value.id()) );

      assert( current.get() );
      if( combined.get() )
        combined = range_union( combined, current );
      else
        combined = current;
    }

    assert( combined.get() );
    return combined;
  }


  static
  LazyRange::ptr_t
  parse_lazy_singleton( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), lazy_singleton_id );
    DICON_ASSERT_SIZE_( node.children.size(), 1 );

    return range_factory( parse_exp_or_real(node.children[0]) );
  }


  static
  LazyRange::ptr_t
  parse_lazy_simple_range( const tree_node<node_val_data<> > &node, bool sort ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), lazy_simple_range_id );

    if( node.children.size() == 2 ) {
      return range_factory( parse_exp_or_real(node.children[0]),
                            parse_exp_or_real(node.children[1]), sort );
    }
    else if( node.children.size() == 1 ) {
      return range_factory( parse_exp_or_real(node.children[0]),
                            boost::none                        , sort );
    }
    else
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<size_t>(node.children.size()) );
  }


  static
  LazyRange::ptr_t
  parse_lazy_extended_range( const tree_node<node_val_data<> > &node, bool sort ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), lazy_extended_range_id );

    if( node.children.size() == 3 ) {
      return range_factory( parse_exp_or_real(node.children[0]),
                            parse_exp_or_real(node.children[1]),
                            parse_exp_or_real(node.children[2]), sort );
    }
    else if( node.children.size() == 2 ) {
      return range_factory( parse_exp_or_real(node.children[0]),
                            parse_exp_or_real(node.children[1]),
                            boost::none                        , sort );
    }
    else
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<size_t>(node.children.size()) );
  }


  static
  ExpressionOrReal
  parse_exp_or_real( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), exp_or_real_id );
    DICON_ASSERT_SIZE_( node.children.size(), 1 );

    const tree_node<node_val_data<> > &child = node.children.front();

    if( child.value.id() == SpecifierGrammar::expression_id ) {
      LazyValue<real_t>::ptr_t expression = parse_expression( child );
      return expression;
    }
    else if( child.value.id() == SpecifierGrammar::real_id )
      return parse_real( child );
    else
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<parser_id>(child.value.id()) );
  }


  static
  LazyValue<real_t>::ptr_t
  parse_expression( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), expression_id );

    if( !(node.children.size() >= 1 && node.children.size() % 2 == 1) )
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<size_t>(node.children.size()) );

    LazyValue<real_t>::ptr_t combined;

    for( size_t i = 0; i < node.children.size(); i += 2 ) {
      LazyValue<real_t>::ptr_t current = parse_term( node.children[i] );

      if( i != 0 ) {
        std::string op( node.children[i-1].value.begin(),
                        node.children[i-1].value.end() );

        boost::function<real_t(real_t, real_t)> function;

        if( op == "+" )
          function = boost::lambda::_1 + boost::lambda::_2;
        else if( op == "-" )
          function = boost::lambda::_1 - boost::lambda::_2;
        else
          BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<std::string>(op) );

        assert( combined.get() );
        combined = lazy_binary_op( combined, current, function );
      }
      else
        combined = current;
    }

    assert( combined.get() );
    return combined;
  }


  static
  LazyValue<real_t>::ptr_t
  parse_term( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), term_id );

    if( !(node.children.size() >= 1 && node.children.size() % 2 == 1) )
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<size_t>(node.children.size()) );

    LazyValue<real_t>::ptr_t combined;

    for( size_t i = 0; i < node.children.size(); i += 2 ) {
      LazyValue<real_t>::ptr_t current = parse_factor( node.children[i] );

      if( i != 0 ) {
        std::string op( node.children[i-1].value.begin(),
                        node.children[i-1].value.end() );

        boost::function<real_t(real_t, real_t)> function;

        if( op == "*" )
          function = boost::lambda::_1 * boost::lambda::_2;
        else if( op == "/" )
          function = boost::lambda::_1 / boost::lambda::_2;
        else
          BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<std::string>(op) );

        assert( combined.get() );
        combined = lazy_binary_op( combined, current, function );
      }
      else
        combined = current;
    }

    assert( combined.get() );
    return combined;
  }


  static
  LazyValue<real_t>::ptr_t
  parse_factor( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), factor_id );

    if( node.children.size() == 3 ) {
      DICON_ASSERT_PARSER_ID_( node.children[0].value.id(), group_id );
      DICON_ASSERT_PARSER_ID_( node.children[1].value.id(), factor_id );
      DICON_ASSERT_PARSER_ID_( node.children[2].value.id(), factor_id );

      std::string op( node.children[1].value.begin(),
                      node.children[1].value.end() );

      boost::function<real_t(real_t, real_t)> function;

      if( op == "^" )
        function = ::pow;
      else
        BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<std::string>(op) );

      return lazy_binary_op( parse_group(node.children[0]),
                             parse_factor(node.children[2]), function );
    }
    else if( node.children.size() == 2 ) {
      DICON_ASSERT_PARSER_ID_( node.children[0].value.id(), factor_id );
      DICON_ASSERT_PARSER_ID_( node.children[1].value.id(), group_id );

      std::string op( node.children[0].value.begin(),
                      node.children[0].value.end() );

      boost::function<real_t(real_t)> function;

      if( op == "+" )
        function = +boost::lambda::_1;
      else if( op == "-" )
        function = -boost::lambda::_1;
      else
        BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<std::string>(op) );

      return lazy_unary_op( parse_group(node.children[1]), function );
    }
    else if( node.children.size() == 1 )
      return parse_group( node.children.front() );
    else
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<size_t>(node.children.size()) );
  }


  static
  LazyValue<real_t>::ptr_t
  parse_group( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), group_id );

    if( node.children.size() == 2 ) {
      DICON_ASSERT_PARSER_ID_( node.children[0].value.id(), identifier_id );
      DICON_ASSERT_PARSER_ID_( node.children[1].value.id(), expression_id );

      const std::string &name = parse_identifier( node.children[0] );
      boost::function<real_t(real_t)> function;

      try {
        function = exp_range_functions.at( name );
      }
      catch( std::out_of_range & ) {
        BOOST_THROW_EXCEPTION( SpecifierUndefinedFunctionError() << errinfo_specifier_function_name(name) );
      }

      assert( function );
      return lazy_unary_op( parse_expression(node.children[1]), function );
    }
    else if( node.children.size() == 1 ) {
      const tree_node<node_val_data<> > &child = node.children.front();

      if( child.value.id() == SpecifierGrammar::expression_id )
        return parse_expression( child );
      else if( child.value.id() == SpecifierGrammar::identifier_id )
        return lazy_variable<real_t>( parse_identifier(child) );
      else if( child.value.id() == SpecifierGrammar::real_id )
        return lazy_constant( RationalToReal()(parse_real(child)) );
      else
        BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<parser_id>(child.value.id()) );
    }
    else
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<size_t>(node.children.size()) );
  }


  static
  std::string
  parse_identifier( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), identifier_id );
    DICON_ASSERT_SIZE_( node.children.size(), 1 );
    DICON_ASSERT_PARSER_ID_( node.children.front().value.id(), identifier_id );

    return std::string( node.children.front().value.begin(),
                        node.children.front().value.end() );
  }


  static
  std::string
  parse_literal( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), literal_id );
    DICON_ASSERT_SIZE_( node.children.size(), 1 );
    DICON_ASSERT_PARSER_ID_( node.children.front().value.id(), literal_id );

    enum
    { NORMAL
    , IN_SINGLE_QUOTE
    , IN_DOUBLE_QUOTE
    } state = NORMAL;

    std::string literal;

    BOOST_FOREACH( char x, std::string(node.children.front().value.begin(),
                                       node.children.front().value.end()) )
    {
      switch( state ) {
      case NORMAL:
        switch( x ) {
        case '\'': state = IN_SINGLE_QUOTE; break;
        case '"': state = IN_DOUBLE_QUOTE; break;
        default: literal.push_back( x );
        }
        break;

      case IN_SINGLE_QUOTE:
        switch( x ) {
        case '\'': state = NORMAL; break;
        default: literal.push_back( x );
        }
        break;

      case IN_DOUBLE_QUOTE:
        switch( x ) {
        case '"': state = NORMAL; break;
        default: literal.push_back( x );
        }
        break;
      }
    }

    if( state != NORMAL )
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<int>(state) );

    return literal;
  }


  static
  rational_t
  parse_real( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), real_id );
    DICON_ASSERT_SIZE_( node.children.size(), 1 );
    DICON_ASSERT_PARSER_ID_( node.children.front().value.id(), real_id );

    return string_to_rational( std::string(node.children.front().value.begin(),
                                           node.children.front().value.end()) );
  }


  static
  LazySet<std::string>::ptr_t
  parse_argument( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), argument_id );
    DICON_ASSERT_SIZE_( node.children.size(), 1 );
    DICON_ASSERT_PARSER_ID_( node.children.front().value.id(), set_id );

    return parse_set( node.children.front() );
  }


  struct RationalToSimcount {
    typedef simcount_t result_type;
    typedef rational_t argument_type;

    result_type
    operator()( argument_type x ) const {
      // Round x to nearest int.
      x += rational_t(sgn(x)) / 2;
      x = x.get_num() / x.get_den();

      mpz_class min_value = boost::lexical_cast<mpz_class>( std::numeric_limits<simcount_t>::min() );
      mpz_class max_value = boost::lexical_cast<mpz_class>( std::numeric_limits<simcount_t>::max() );

      assert( x.get_den() == 1 );
      if( min_value <= x.get_num()
          && x.get_num() <= max_value )
      {
        return boost::lexical_cast<result_type>( x.get_num() );
      }
      else {
        BOOST_THROW_EXCEPTION( SpecifierInvalidSimcountError()
                               << errinfo_value<mpz_class>(x.get_num())
                               << errinfo_min_value<mpz_class>(min_value)
                               << errinfo_max_value<mpz_class>(max_value) );
      }
    }
  };


  static
  LazySet<simcount_t>::ptr_t
  parse_schedule( const tree_node<node_val_data<> > &node ) {
    DICON_ASSERT_PARSER_ID_( node.value.id(), schedule_id );
    DICON_ASSERT_SIZE_MIN_( node.children.size(), 1 );

    {
      const tree_node<node_val_data<> > &child = node.children.front();

      if( child.value.id() == SpecifierGrammar::exp_range_id ) {
        return lazy_transform( lazy_transform(parse_exp_range(child),
                                              RealToRational())
                             , RationalToSimcount()
                             );
      }
      else if( child.value.id() == SpecifierGrammar::range_id ) {
        return lazy_transform( parse_range(child, true)
                             , RationalToSimcount()
                             );
      }
    }

    std::set<rational_t> values;

    BOOST_FOREACH( const tree_node<node_val_data<> > &child, node.children ) {
      if( child.value.id() == SpecifierGrammar::exp_or_real_id ) {
        const ExpressionOrReal &exp_or_real = parse_exp_or_real( child );

        if( exp_or_real.is_real() )
          values.insert( exp_or_real.real() );
        else {
          if( !exp_or_real.expression().references().empty() ) {
            BOOST_THROW_EXCEPTION( SpecifierUndefinedVariableError()
                                   << errinfo_specifier_variable_name(*exp_or_real.expression().references().begin()) );
          }

          values.insert( RealToRational()(exp_or_real.expression()(LazyValue<real_t>::variables_t())) );
        }
      }
      else
        BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<parser_id>(child.value.id()) );
    }

    return lazy_transform( lazy_container<std::vector<rational_t> >(values.begin(),
                                                                    values.end())
                         , RationalToSimcount()
                         );
  }


  template< typename T, int which >
  static
  typename LazySet<T>::ptr_t
  parse_specifier( const std::string &specifier, typename LazySet<T>::ptr_t (*parse)(const tree_node<node_val_data<> > &) ) {
    using namespace boost::spirit::classic;
    using namespace ::detail;

    const tree_parse_info<> &info = pt_parse( specifier.c_str(), SpecifierGrammar().use_parser<which>() );

    if( !info.full ) {
      BOOST_THROW_EXCEPTION( SpecifierParseError()
                             << errinfo_value<std::string>(specifier.substr(info.match ? info.length : 0)) );
    }

    DICON_ASSERT_SIZE_( info.trees.size(), 1 );

    return parse( info.trees.front() );
  }

}


#undef DICON_ASSERT_PARSER_ID_
#undef DICON_ASSERT_SIZE_
#undef DICON_ASSERT_SIZE_MIN_


LazySet<std::string>::ptr_t
parse_argument_specifier( const std::string &specifier ) {
  return detail::parse_specifier<std::string, detail::SpecifierGrammar::argument>( specifier, detail::parse_argument );
}


LazySet<simcount_t>::ptr_t
parse_schedule_specifier( const std::string &specifier ) {
  return detail::parse_specifier<simcount_t, detail::SpecifierGrammar::schedule>( specifier, detail::parse_schedule );
}

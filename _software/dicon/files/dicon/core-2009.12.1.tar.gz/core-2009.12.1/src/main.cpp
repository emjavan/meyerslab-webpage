/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "main.hpp"
#include "error.hpp"
#include "file.hpp"
#include "log.hpp"
#include "manager.hpp"
#include "specifier.hpp"
#include "version.hpp"
#include <boost/format.hpp>
#include <boost/function.hpp>
#include <boost/mpi/communicator.hpp>
#include <boost/mpi/environment.hpp>
#include <boost/version.hpp>
#include <csignal>
#include <cerrno>


namespace detail {

  static
  const char
  usage_text[] =
    "Disease Control System DiCon (%2$s)"        "\n"
    ""                                           "\n"
    "Copyright (C) 2009  Sebastian Goll, University of Texas at Austin" "\n"
    "Designed and developed with the guidance of Nedialko B. Dimitrov" "\n"
    "and Lauren Ancel Meyers at the University of Texas at Austin." "\n"
    ""                                           "\n"
    "Usage: %1$s [job directory]"                "\n"
    "       %1$s -a [argument specifier]"        "\n"
    "       %1$s -s [schedule specifier]"        "\n"
    ""                                           "\n"
    "This program comes with ABSOLUTELY NO WARRANTY."
    ;


  static
  void
  deactivate_sigpipe() {
    struct sigaction act;
    memset( &act, 0, sizeof(act) );

    act.sa_handler = SIG_IGN;
    sigemptyset( &act.sa_mask );
    act.sa_flags = 0;

    if( sigaction(SIGPIPE, &act, NULL) != 0 )
      BOOST_THROW_EXCEPTION( SignalError() << errinfo_api_function("sigaction") << errinfo_errno(errno) );
  }


  template< typename T >
  static
  void
  list_specifier( const std::string &specifier, T (*parser)(const std::string &) ) {
    T set;

    try {
      set = parser( specifier );
    }
    catch( Error &e ) {
      std::cerr << (boost::format("Failed to parse specifier \"%s\". %s\n\n%s")
                    % specifier % e.what() % boost::diagnostic_information(e));
      std::cerr << std::flush;
      return;
    }

    std::cout << (boost::format("Listing specifier \"%s\".\n") % specifier) << std::endl;

    size_t i = 0;
    for( set->reset(); set->has(); set->inc() ) {
      typename detail::LazySetPtr<T>::value_t value;

      try {
        ++i;
        value = set->get();
      }
      catch( Error &e ) {
        std::cout << std::flush;
        std::cerr << (boost::format("Failed to get element #%u. %s\n\n%s")
                      % i % e.what() % boost::diagnostic_information(e));
        std::cerr << std::flush;
        return;
      }

      std::cout << '#' << i << ": " << value << '\n';
    }

    if( i != 0 )
      std::cout << '\n';

    std::cout << (boost::format("Specifier has %u elements.") % i) << std::endl;
  }

}


int
main( int argc, char *argv[] ) {
  // First do some general things without MPI.

  if( argc == 3 && std::string(argv[1]) == "-a" ) {
    detail::list_specifier( argv[2], &parse_argument_specifier );
    return 0;
  }
  else if( argc == 3 && std::string(argv[1]) == "-s" ) {
    detail::list_specifier( argv[2], &parse_schedule_specifier );
    return 0;
  }

  if( argc != 2 ) {
#ifdef DICON_PROGRAM_NAME
    const char program_name[] = DICON_PROGRAM_NAME;
#else
    const char *program_name = argv[0];
#endif
    std::cerr << (boost::format(detail::usage_text)
                  % program_name % program_version) << std::endl;
    return -1;
  }

  // Here begins the MPI part of the program.

  boost::mpi::environment environment( argc, argv );

  try {
    File::chdir( std::string(argv[1]) );
    detail::deactivate_sigpipe();

    boost::mpi::communicator world;
    NodeManager::create(world)->run();
  }
  catch( NodeManagerShutdownError & ) {
    // Don't show error message again.
    environment.abort( -1 );
    return -1;
  }
#if BOOST_VERSION >= 103900
  catch( ... ) {
    log_failure( "Caught unhandled exception in main().\n" +
                 boost::current_exception_diagnostic_information() );
    environment.abort( -1 );
    return -1;
  }
#else
  catch( boost::exception &e ) {
    log_failure( "Caught unhandled exception in main().\n" +
                 boost::diagnostic_information(e) );
    environment.abort( -1 );
    return -1;
  }
  catch( ... ) {
    log_failure( "Caught unhandled exception in main().\n" +
                 std::string("<unknown exception>\n") );
    environment.abort( -1 );
    return -1;
  }
#endif

  return 0;
}

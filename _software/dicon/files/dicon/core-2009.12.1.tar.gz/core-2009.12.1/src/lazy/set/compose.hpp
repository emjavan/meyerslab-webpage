#ifndef DICON_LAZY_SET_COMPOSE_HPP_
#define DICON_LAZY_SET_COMPOSE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyCompose class.
 */
#include "../set.hpp"
#include <boost/noncopyable.hpp>
#include <functional>


/**
 * @brief Compose lazy sets.
 *
 * The LazyCompose class implements the composition of lazy sets. This
 * means  that the given  functor is  called for  each element  in the
 * given lazy  set, returning a  lazy set each time.   The composition
 * lazy  set  implemented  by   the  LazyCompose  class  then  is  the
 * concatenation of these resulting sets.
 *
 * The functor  of type  @e Op must  be compatible with  the following
 * function type signature: <code>LazySet<T>::ptr_t(const S &)</code>.
 *
 * @tparam Op Functor to apply.
 * @tparam T Value type of this set.
 * @tparam S Value type of original set.
 */
template< typename Op
        , typename T = typename detail::LazySetPtr<typename Op::result_type>::value_t
        , typename S = typename Op::argument_type
        >
class LazyCompose
  : boost::noncopyable, public LazySet<T>
{
public:
  /**
   * @brief Create lazy composition set.
   *
   * Constructor that creates the lazy  set that is the composition of
   * the functor  given by  @e op  with the elements  of the  lazy set
   * given by @e x.
   *
   * The resulting lazy  set will be infinite if and  only if at least
   * one of the  lazy sets returned by @e op,  called for each element
   * in the original set @e x, is infinite.
   *
   * In order  to fulfill  the lazy set  interface, the functor  @e op
   * must return a lazy set containing  the same value each time it is
   * called with the same argument.
   *
   * @param x Original lazy set.
   * @param op Functor to apply.
   */
  LazyCompose( typename LazySet<S>::ptr_t &x, const Op &op = Op() );

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();

private:
  void fetch() const;

private:
  const typename LazySet<S>::ptr_t x_;
  mutable typename LazySet<T>::ptr_t y_;
  const Op op_;
};


/**
 * @brief Create lazy composition set.
 *
 * Create lazy  composition set as  described in the  documentation of
 * the LazyCompose  class.  This  templated helper function  returns a
 * smart pointer to the newly created set.
 *
 * @param x Original lazy set.
 * @param op Functor to apply.
 * @returns Pointer to new lazy set.
 */
template< typename Op, typename S >
typename detail::LazySetPtr<typename Op::result_type>::ptr_t lazy_compose( S x, const Op &op );


#include "compose.ipp"

#endif //DICON_LAZY_SET_COMPOSE_HPP_

#ifndef DICON_LAZY_SET_HPP_
#define DICON_LAZY_SET_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazySet interface.
 */
#include <memory>


/**
 * @brief Lazy set.
 *
 * The templated  LazySet class provides the interface  to an abstract
 * lazy set. Such a set creates its elements when requested and has no
 * predetermined  length,  i.e., it  might  be  infinite. Methods  are
 * provided to check if another  element in the set exists (has()), to
 * create and  return that  element (get()), and  to step to  the next
 * element in the set (inc()).
 *
 * The lazy  set interface requires  lazy sets to be  immutable, i.e.,
 * when reset to  its original position (reset()) the  lazy set has to
 * return the same  elements again. The set can be  reset at any time;
 * in  fact, it  has  to  be reset  explicitly  after construction  as
 * implementations of this interface are not required to start the set
 * at its first  element. Lazy sets must return  their elements always
 * in the same order.
 *
 * Due  to  the  nature of  an  abstract  base  class, lazy  sets  are
 * typically  referenced to by  pointer.  The  pointer class  used and
 * defined by @link  LazySet::ptr_t ptr_t@endlink is the std::auto_ptr
 * pointer.  This allows for the  efficient use of lazy sets, e.g., as
 * constructor  arguments as  used in  several of  the implementations
 * (such as  LazyCombine, LazyCompose, LazyConcat,  LazyTransform, and
 * LazyUnion) while at the same time avoiding memory leaks.
 *
 * The following  code shows  how all  elements in a  lazy set  can be
 * printed.
 *
 * @code
LazySet<some_type>::ptr_t set = some_lazy_set;

for( set->reset(); set->has(); set->inc() ) {
  std::cout << set->get() << std::endl;
}
@endcode
 *
 * For  each   lazy  set  implementation   (LazyCombine,  LazyCompose,
 * LazyConcat,  LazyContainer,  LazyEmpty,  LazyRange,  LazySingleton,
 * LazyTransform,  or LazyUnion), there  is a  corresponding templated
 * global    helper    function    (lazy_combine(),    lazy_compose(),
 * lazy_concat(),    lazy_container(),   lazy_empty(),   lazy_range(),
 * lazy_singleton(),  lazy_transform(), or  lazy_union()) to  create a
 * new lazy  set of that  type and return  a smart pointer to  it.  In
 * most cases, these helper function can be automatically instantiated
 * by the compiler as to  avoid the necessity of explicitly specifying
 * the template arguments. The following code demonstrates this.
 *
 * @code
LazySet<int>::ptr_t set = lazy_combine( lazy_range(10, 90, 10)
                                      , lazy_range(9, 1, -1)
                                      , std::plus<int>()
                                      );
@endcode
 *
 * Notice  how  neither  lazy_combine()  nor lazy_range()  required  a
 * template argument:  the sets' value type  was automatically deduced
 * from the functions' arguments.   Also, the helper functions allowed
 * for  the exception-safe  immediate  use of  the  resulting sets  as
 * arguments to other lazy set constructors and helper functions.
 *
 * @note Although this class is named lazy @e set, it is rather a lazy
 * @e list. In  particular, a lazy set is allowed  to contain the same
 * element more than once.
 */
template< typename T >
class LazySet {
public:
  /// Set value type.
  typedef T value_t;
  /// Pointer to lazy set.
  typedef std::auto_ptr<LazySet> ptr_t;

public:
  virtual ~LazySet() {}

public:
  /**
   * @brief Clone lazy set.
   *
   * Clone the lazy  set. The new set object  must represent the exact
   * same set  with the same elements  as the original  set.  Also, it
   * must  be  independent from  the  original  set,  so that  calling
   * reset() or inc() on either one set does not influence the other.
   *
   * @returns Copy of this set.
   */
  virtual ptr_t clone() const = 0;

public:
  /**
   * @brief Reset lazy set.
   *
   * Reset the  lazy set  to its first  element.  This method  must be
   * called  before   first  calling   has(),  get(),  or   inc(),  as
   * implementations  of the  LazySet  interface are  not required  to
   * start at the first element after construction.
   */
  virtual void reset() = 0;

public:
  /**
   * @brief Check if set has element.
   *
   * Check if the lazy set  has another element.  This function return
   * @c false if and only if the lazy set has reached its end. At this
   * point, calling get() or inc() is undefined.
   *
   * @returns @c true iff set has another element.
   */
  virtual bool has() const = 0;
  /**
   * @brief Get current element in set.
   *
   * Get the current element in  the set. This creates and returns the
   * element at the current position  within the set.  The behavior of
   * calling this  function when  has() has returned  @c false  is not
   * defined.
   *
   * @returns Current element in set.
   */
  virtual T get() const = 0;
  /**
   * @brief Skip current element in set.
   *
   * Skip the  current element  in the  set and go  to the  next. This
   * function increments the lazy  set's internal iterator to the next
   * element in the set, skipping the current element. The behavior of
   * calling  this function  when has()  has retured  @c false  is not
   * defined.
   */
  virtual void inc() = 0;
};


namespace detail {

  template< typename T >
  struct LazySetPtr {
    typedef typename T::element_type::value_t value_t;
    typedef typename LazySet<value_t>::ptr_t ptr_t;
  };

}

#endif //DICON_LAZY_SET_HPP_

#ifndef DICON_LAZY_SET_COMBINE_HPP_
#define DICON_LAZY_SET_COMBINE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyCombine class.
 */
#include "../set.hpp"
#include <boost/noncopyable.hpp>
#include <functional>


/**
 * @brief Combine lazy sets.
 *
 * The LazyCombine class implements  the combination, or the Cartesian
 * product,  of two  lazy  sets.   Thus, it  represents  the lazy  set
 * resulting  from the application  of a  user-defined functor  to all
 * pairs of elements from the two original sets.
 *
 * The functor  of type  @e Op must  be compatible with  the following
 * function type signature: <code>T(const S1 &, const S2 &)</code>.
 *
 * @tparam Op Functor to apply.
 * @tparam T Value type of this set.
 * @tparam S1 Value type of first original set.
 * @tparam S2 Value type of second original set.
 */
template< typename Op
        , typename T = typename Op::result_type
        , typename S1 = typename Op::first_argument_type
        , typename S2 = typename Op::second_argument_type
        >
class LazyCombine
  : boost::noncopyable, public LazySet<T>
{
public:
  /**
   * @brief Create lazy combination set.
   *
   * Constructor that creates the lazy set that is the combination, or
   * the Cartesian product, of the two  lazy sets given by @e a and @e
   * b.  The  resulting set contains the results  from the application
   * of the functor given by @e op to the pairs of values from sets @e
   * a and @e b.
   *
   * The  order of values  in the  resulting set  is lexicographically
   * given by the order of elements in sets @e a and @e b, e.g., if @e
   * a had elements @c  a1 and @c a2, and @e b  had elements @c b1 and
   * @c b2, the  resulting set would contain the  elements given by @e
   * op(@c a1, @c  b1), @e op(@c a1,  @c b2), @e op(@c a2,  @c b1), @e
   * op(@c a2, @c b2), in that order.
   *
   * In case  both @e a  and @e b  are finite sets, the  resulting set
   * contains  exactly @e  size(@e a)  times @e  size(@e  b) elements,
   * where @e size denotes the number of elements in the corresponding
   * set.  If  either of the  orignal sets is infinite,  the resulting
   * set will be infinite as well.
   *
   * In order  to fulfill  the lazy set  interface, the functor  @e op
   * must return the  same value each time it is  called with the same
   * arguments.
   *
   * @param a First set.
   * @param b Second set.
   * @param op Functor to apply.
   */
  LazyCombine( typename LazySet<S1>::ptr_t &a, typename LazySet<S2>::ptr_t &b, const Op &op = Op() );

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();

private:
  const typename LazySet<S1>::ptr_t a_;
  const typename LazySet<S2>::ptr_t b_;
  const Op op_;
};


/**
 * @brief Create lazy combination set.
 *
 * Create lazy  combination set as  described in the  documentation of
 * the LazyCombine  class.  This  templated helper function  returns a
 * smart pointer to the newly created set.
 *
 * @param a First set.
 * @param b Second set.
 * @param op Functor to apply.
 * @returns Pointer to new lazy set.
 */
template< typename Op, typename S1, typename S2 >
typename LazySet<typename Op::result_type>::ptr_t lazy_combine( S1 a, S2 b, const Op &op );


#include "combine.ipp"

#endif //DICON_LAZY_SET_COMBINE_HPP_

#ifndef DICON_LAZY_SET_UNION_HPP_
#define DICON_LAZY_SET_UNION_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyUnion class.
 */
#include "../set.hpp"
#include <boost/noncopyable.hpp>


/**
 * @brief Unite lazy sets.
 *
 * The LazyUnion class  implements the set union of  two lazy sets. It
 * requires that  both of  the original sets  are sorted  according to
 * some strict order defined by  the comparison operators (@c =, @c <,
 * @c <=) on @e T. The elements in the resulting set are also sorted.
 *
 * The implementation works as follows.  If the current element in the
 * first original set were @c a  and the current element in the second
 * original set were  @c b, then the current  element in the resulting
 * set   would   be  @c   a   if   <code>a<=b</code>   or  @c   b   if
 * <code>a>b</code>. When taking a step with inc(), the first original
 * set  would be  stepped to  its next  element  if <code>a<=b</code>,
 * while the second original set  would be stepped to its next element
 * if <code>a>=b</code>,  i.e., if <code>a=b</code>  the element would
 * end up only once in the resulting set.
 *
 * Neither  the first  nor the  second  original set  is filtered  for
 * duplicate elements.   If either set  contains an element  more than
 * once, it will also show up multiple times in the resulting set.
 *
 * @tparam T Value type of this set.
 */
template< typename T >
class LazyUnion
  : boost::noncopyable, public LazySet<T>
{
public:
  /**
   * @brief Create lazy union set.
   *
   * Constructor that  creates the lazy set  that is the  set union of
   * the two lazy sets given by @e a and @e b. Both original sets must
   * be  sorted as  described in  the documentation  of  the LazyUnion
   * class.
   *
   * @param a First set.
   * @param b Second set.
   */
  LazyUnion( typename LazySet<T>::ptr_t &a, typename LazySet<T>::ptr_t &b );

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();

private:
  const typename LazySet<T>::ptr_t a_;
  const typename LazySet<T>::ptr_t b_;
};


/**
 * @brief Create lazy union set.
 *
 * Create  lazy union  set as  described in  the documentation  of the
 * LazyUnion  class. This  templated helper  function returns  a smart
 * pointer to the newly created set.
 *
 * @param a First set.
 * @param b Second set.
 * @returns Pointer to new lazy set.
 */
template< typename T >
typename detail::LazySetPtr<T>::ptr_t lazy_union( T a, T b );


#include "union.ipp"

#endif //DICON_LAZY_SET_UNION_HPP_

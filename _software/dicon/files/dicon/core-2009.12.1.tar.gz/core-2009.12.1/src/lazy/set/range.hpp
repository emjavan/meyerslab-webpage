#ifndef DICON_LAZY_SET_RANGE_HPP_
#define DICON_LAZY_SET_RANGE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyRange class.
 */
#include "../set.hpp"


/**
 * @brief Lazy range set.
 *
 * The LazyRange  class implements the infinite  (unbounded) or finite
 * (bounded) range given by a first  value and a step size, or a first
 * value, a step size, and a last value.
 *
 * The value type of the  set should represent a numerical value (such
 * as @c int, @c double, or some custom class). It must implement both
 * comparison operators  (@c =, @c <,  and @c <=) that  define a total
 * order on the value type, and  the addition of values as well as the
 * multiplication with  an integer of type  @c size_t, i.e.,  for @c t
 * and @c s of  type @e T and @c i of  type @c size_t, the expressions
 * <code>t+s</code>   and  <code>t*i</code>   must   be  defined   and
 * convertible to type @e T.
 *
 * @note In order to avoid precision errors with floating point types,
 *   the actual  calculation performed by the  lazy set implementation
 *   when  getting one  of its  elements  is <code>lower+step*i</code>
 *   where  @c i  is of  type @c  size_t.  This  should be  taken into
 *   account when considering performance.
 *
 * @tparam T Value type of this set.
 */
template< typename T >
class LazyRange
  : public LazySet<T>
{
public:
  /**
   * @brief Create unbounded lazy range set.
   *
   * Constructor  that  creates  the  lazy  set  that  represents  the
   * infinite (unbounded) range with elements  @e lower, @e lower + @e
   * step, @e lower + @e step + @e step, ...
   *
   * @param lower First element in lazy set.
   * @param step Step between elements.
   * @throws   AssertionError   when    @e   step   is   zero   (i.e.,
   *   <code>=T()</code>).
   */
  LazyRange( const T &lower, const T &step );
  /**
   * @brief Create bounded lazy range set.
   *
   * Constructor that creates the  lazy set that represents the finite
   * (bounded) range  with elements @e lower,  @e lower +  @e step, @e
   * lower + @e step + @e step,  ..., @e upper. If @e step is positive
   * (i.e., <code>>T()</code>), the last element in the set is the one
   * that  is still  less  than or  equal  to @e  upper,  and the  set
   * contains no value greater than  @e upper.  If @e step is negative
   * (i.e., <code><T()</code>), the last element in the set is the one
   * that is  still greater  than or  equal to @e  upper, and  the set
   * contains no value less than @e upper.
   *
   * @note Despite the names it is  not an error when @e upper is less
   *   than @e lower.  In fact this  might be useful when @e step is a
   *   negative value.
   *
   * @param lower First element in lazy set.
   * @param upper Final element in lazy set.
   * @param step Step between elements.
   * @throws   AssertionError   when    @e   step   is   zero   (i.e.,
   *   <code>=T()</code>).
   */
  LazyRange( const T &lower, const T &upper, const T &step );

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();

private:
  const bool open_;
  const T lower_;
  const T upper_;
  const T step_;
  size_t pos_;
};


/**
 * @brief Create lazy range set.
 *
 * Create  lazy range  set as  described in  the documentation  of the
 * LazyRange  class. This  templated helper  function returns  a smart
 * pointer to the newly created set.
 *
 * @param lower First element in lazy set.
 * @param step Step between elements.
 * @returns Pointer to new lazy set.
 * @throws    AssertionError   when   @e    step   is    zero   (i.e.,
 *   <code>=T()</code>).
 */
template< typename T >
typename LazySet<T>::ptr_t lazy_range( const T &lower, const T &step );

/**
 * @brief Create lazy range set.
 *
 * Create  lazy range  set as  described in  the documentation  of the
 * LazyRange  class. This  templated helper  function returns  a smart
 * pointer to the newly created set.
 *
 * @param lower First element in lazy set.
 * @param upper Final element in lazy set.
 * @param step Step between elements.
 * @returns Pointer to new lazy set.
 * @throws    AssertionError   when   @e    step   is    zero   (i.e.,
 *   <code>=T()</code>).
 */
template< typename T >
typename LazySet<T>::ptr_t lazy_range( const T &lower, const T &upper, const T &step );


#include "range.ipp"

#endif //DICON_LAZY_SET_RANGE_HPP_

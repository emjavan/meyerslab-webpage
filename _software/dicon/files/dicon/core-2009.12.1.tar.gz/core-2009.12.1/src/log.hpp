#ifndef DICON_LOG_HPP_
#define DICON_LOG_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Log related classes and functions.
 *
 * The log.hpp file provides the  global log system.  Log sinks can be
 * created  by deriving  from  LogSink, or  instantiating the  LogFile
 * class.   Sinks are  registered  with the  global  log system  using
 * log_register_sink(), and are removed  from the global log system by
 * log_remove_sink().   Log sinks  are  being held  by weak  pointers:
 * therefore,  they  can  be  removed  at arbitrary  times  by  simply
 * destroying  all  remaining  smart  pointers to  the  sink;  calling
 * log_remove_sink() is not necessary.
 *
 * Log messages  are created  in various log  levels using  the global
 * functions log_debug(),  log_info(), log_warning(), log_error(), and
 * log_failure().  Each of these  functions is guaranteed not to throw
 * an  exception.  The  %message is  automatically distributed  to all
 * registered log sinks. Messages of  the error and failure log levels
 * are  also written  to  standard  error output.   If  writing a  log
 * %message to a sink fails, that sink will be removed from the global
 * log system and an error  %message will be written to standard error
 * output.
 */
#include "error.hpp"
#include "types.hpp"
#include <boost/filesystem/path.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <fstream>
#include <string>


/// Log related error.
struct LogError : virtual Error
{ virtual const char *what() const throw() { return "Log related error."; } };

/// Writing to log failed.
struct LogWriteError : public virtual IOWriteError, public virtual LogError
{ virtual const char *what() const throw() { return "Writing to log failed."; } };


/**
 * @brief Sink used for logging.
 *
 * The LogSink class  is the base class for sinks  used for logging. A
 * log sink  can be an  arbitrary target for  log messages, such  as a
 * logfile (LogFile class).
 */
class LogSink {
public:
  virtual ~LogSink() {}

public:
  /**
   * @brief Write log %message to sink.
   *
   * Write the log %message given  by @e %message with log level given
   * by @e level to the log sink.
   *
   * @param message Log %message.
   * @param level Log level.
   */
  virtual void log( const std::string &message, LogLevel level ) = 0;
};


/**
 * @brief Logfile sink used for logging.
 *
 * The  LogFile  class is  a  log sink  that  writes  log messages  to
 * file. The messages are prefixed with the current date and time, and
 * a textual  representation of the  log level of the  %message. Also,
 * messages containing line breaks are spread over multiple lines with
 * the  second and  following  lines indented.   The  following is  an
 * example how the resulting logfile will look like.
 *
 * @verbatim
Nov 05 04:45:44 info: Starting job (#5; job-1, argument-5) in directory `job-1/argument-00005'.
Nov 05 04:45:44 info|   Optimizer command line: `../optimizer/exhaustive.so'
Nov 05 04:45:44 info|   Simulator command line: `../simulator/python/simple_simulator.py 5 5'
Nov 05 04:45:44 info: Checkpoint file `job-1/argument-00005/checkpoint.xml' does not exist.
Nov 05 04:45:44 info: Job has no checkpoints; beginning job from scratch.
Nov 05 04:45:44 info: Initializing optimizer on node #135.
@endverbatim
 */
class LogFile
  : boost::noncopyable, public LogSink
{
public:
  /**
   * @brief Create new logfile.
   *
   * Constructor that creates the logfile  given by @e file. If a file
   * with  that name  already exists,  it  is not  overwritten but  an
   * alternative filename  that does  not yet exist  is chosen  by the
   * means of File::unique().
   */
  LogFile( const boost::filesystem::path &file );
  /**
   * @brief Close logfile.
   *
   * Destructor that  close the  logfile. Before closing  and flushing
   * the file to disk, this writes the log %message "Closing logfile."
   * to  the end of  the logfile.   By the  absence of  this %message,
   * logfiles that  have not been  closed properly can  be identified,
   * e.g., in the event of a system crash.
   */
  virtual ~LogFile();

public:
  /**
   * @brief Write log %message to logfile.
   *
   * Write the log %message given  by @e %message with log level given
   * by @e level  to the logfile.  See the  description of the LogFile
   * class for how the output format looks like.
   *
   * @param message Log %message.
   * @param level Log level.
   *
   * @throws LogWriteError when log %message cannot be written.
   */
  virtual void log( const std::string &message, LogLevel level );

private:
  std::string log_filename_;
  std::ofstream output_;
};


/**
 * @brief Register log sink with global log system.
 *
 * Register  the  log  sink given  by  @e  sink  with the  global  log
 * system. Only log  messages with log level of  at least @e min_level
 * are  sent to  this  sink. If  @e job_id  is  not equal  to 0,  only
 * messages  regarding the job  given by  @e job_id  are sent  to this
 * sink. If  @e job_id is  equal to 0,  all messages are sent  to this
 * sink, with a  prefix of <code>[%Job \#X]</code>, where  @c X is the
 * job number, in  case the %message is connected to  a job (no prefix
 * is added for log messages that are not connected to a job).
 *
 * @note It is not an error to  register a log sink more than once. In
 * this  case, log messages  are sent  to the  same log  sink multiple
 * times,  once for  each  registration (given  that  they match  each
 * registration's  filter conditions  defined by  @e min_level  and @e
 * job_id).   In case of  an error  only one  of the  registrations is
 * removed automatically per log  %message (see the description of the
 * log.hpp header for more information).
 *
 * @param sink Log sink to register.
 * @param min_level Minimum log level for this sink.
 * @param job_id %Job ID to log (or 0 for all job IDs).
 */
void log_register_sink( const boost::shared_ptr<LogSink> &sink, LogLevel min_level, job_id_t job_id = 0 );
/**
 * @brief Remove log sink from global log system.
 *
 * Remove the log sink given by @e sink from the global log system. If
 * the sink has been registered  more than once, all registrations are
 * removed.
 *
 * @param sink Log sink to remove.
 */
void log_remove_sink( const boost::shared_ptr<LogSink> &sink );

/**
 * @brief Send debug log %message.
 *
 * Send the log %message given by @e %message with the debug log level
 * to the global log system. If  @e job_id is equal to 0, the %message
 * is sent to all  log sinks that had @e job_id set  to 0 when calling
 * log_register_sink().  If @e job_id is  not equal to 0, the %message
 * is sent only to sinks registered  with the same @e job_id, or sinks
 * registered  with @e  job_id set  to 0  (in this  case, a  prefix of
 * <code>[%Job \#X]</code> is added to the %message, where @c X is the
 * job number given by @e job_id).
 *
 * This function is guaranteed not to throw an exception.
 *
 * @param message Log %message.
 * @param job_id Optional job ID.
 */
void log_debug  ( const std::string &message, job_id_t job_id = 0 ) throw();
/**
 * @brief Send info log %message.
 *
 * Send the log %message given by  @e %message with the info log level
 * to the global log system.
 *
 * @see log_debug().
 */
void log_info   ( const std::string &message, job_id_t job_id = 0 ) throw();
/**
 * @brief Send warning log %message.
 *
 * Send the  log %message  given by @e  %message with the  warning log
 * level to the global log system.
 *
 * @see log_debug().
 */
void log_warning( const std::string &message, job_id_t job_id = 0 ) throw();
/**
 * @brief Send error log %message.
 *
 * Send the log %message given by @e %message with the error log level
 * to the global log system.
 *
 * @see log_debug().
 */
void log_error  ( const std::string &message, job_id_t job_id = 0 ) throw();
/**
 * @brief Send failure log %message.
 *
 * Send the  log %message  given by @e  %message with the  failure log
 * level to the global log system.
 *
 * @see log_debug().
 */
void log_failure( const std::string &message, job_id_t job_id = 0 ) throw();

/// Send debug log %message.
void log_debug  ( job_id_t job_id, const std::string &message ) throw();
/// Send info log %message.
void log_info   ( job_id_t job_id, const std::string &message ) throw();
/// Send warning log %message.
void log_warning( job_id_t job_id, const std::string &message ) throw();
/// Send error log %message.
void log_error  ( job_id_t job_id, const std::string &message ) throw();
/// Send failure log %message.
void log_failure( job_id_t job_id, const std::string &message ) throw();

#endif //DICON_LOG_HPP_

#ifndef DICON_LIBRARY_HPP_
#define DICON_LIBRARY_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "error.hpp"
#include <boost/noncopyable.hpp>


/// Errinfo storing the dlerror() %message.
DICON_ERRINFO( library_dlerror, std::string );
/// Errinfo storing the library symbol name.
DICON_ERRINFO( library_symbol , std::string );


/// Dynamic-link library related error.
struct LibraryError : virtual SystemError
{ virtual const char *what() const throw() { return "Dynamic-link library related error."; } };

/// Failed to open dynamic-link library.
struct LibraryOpenError : virtual LibraryError
{ virtual const char *what() const throw() { return "Failed to open dynamic-link library."; } };

/// Symbol not found in dynamic-link library.
struct LibrarySymbolError : virtual LibraryError
{ virtual const char *what() const throw() { return "Symbol not found in dynamic-link library."; } };


/**
 * @brief Dynamic-link library access.
 *
 * The DynamicLibrary class provides access to the symbols exported by
 * a  dynamic-link  library (DLL).   Exceptions  are  thrown when  the
 * library cannot be opened or a specific symbol cannot be found.
 *
 * As the  symbols returned by  operator[]() are @c void  pointers, an
 * explicit @c reinterpret_cast to the specific type is needed to make
 * use of them. The following  code demonstrates this for functions by
 * opening a dynamic library, getting a symbol representing a function
 * with a single @c int parameter and returning an @c int, and calling
 * this function.   Non-function symbols can be accessed  in a similar
 * way.
 *
 * @code
// Open the dynamic library "some_library.so".
DynamicLibrary library( "some_library.so" );

// In order to load exported functions, an explicit cast to the
// function pointer type is required. Define this type here.
typedef int (*some_function_t)( int some_parameter );

// Now get the symbol and cast it to the expected function type.
some_function_t some_function =
  reinterpret_cast<some_function_t>( library["some_function"] );

// Finally, call the function defined in the dynamic library.
std::cout << some_function(42) << std::endl;
@endcode
 */
class DynamicLibrary
  : boost::noncopyable
{
public:
  /**
   * @brief Open dynamic-link library.
   *
   * Constructor that opens the dynamic-link library given by @c file.
   *
   * @param file Filename of the dynamic library.
   * @throws LibraryOpenError when the library cannot be opened.
   */
  DynamicLibrary( const std::string &file );
  /**
   * @brief Close library and relase resources.
   *
   * Destructor that  closes the  library and releases  all associated
   * resources.
   */
  ~DynamicLibrary();

public:
  /**
   * @brief Get exported symbol from library.
   *
   * Get a  symbol that  is exported by  the dynamic-link  library. An
   * exception is thrown  when the symbol cannot be  found, i.e., when
   * the library  does not export the  given symbol. As  the symbol is
   * returned   through   a   @c   void  pointer,   an   explicit   @c
   * reinterpret_cast to  the specific type  is needed to make  use of
   * it.   See the  description  of the  DynamicLibrary  class for  an
   * example on how to do this.
   *
   * @param symbol Name of the symbol.
   * @returns @c void pointer to the symbol given by @c symbol.
   * @throws LibrarySymbolError when the symbol cannot be found.
   */
  void *operator[]( const std::string &symbol );

private:
  void *handle_;
};

#endif //DICON_LIBRARY_HPP_

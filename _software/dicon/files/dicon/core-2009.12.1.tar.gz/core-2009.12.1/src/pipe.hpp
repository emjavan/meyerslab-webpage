#ifndef DICON_PIPE_HPP_
#define DICON_PIPE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Pipe class.
 */
#include <boost/noncopyable.hpp>


/**
 * @brief Unix pipeline.
 *
 * The Pipe class implements a Unix pipeline. This pipeline is created
 * on construction of  a Pipe object and can  be accessed through Unix
 * file descriptors. Unless explicitly  released, the object owns each
 * end of  the pipeline and closes the  corresponding file descriptors
 * when destroyed.
 */
class Pipe
  : boost::noncopyable
{
public:
  /**
   * @brief Create Unix pipeline.
   *
   * Constructor that creates a new Unix pipeline.
   *
   * @throws PipeError when the pipeline could not be created.
   */
  Pipe();
  /**
   * @brief Free Unix pipeline.
   *
   * Destructor that  releases the  Unix pipeline. Either  endpoint of
   * the pipeline that has not been released through read_end(bool) or
   * write_end(bool) is closed.
   */
  ~Pipe();

public:
  /**
   * @brief Get read endpoint.
   *
   * Get   the  file  descriptor   for  the   read  endpoint   of  the
   * pipeline. This does not release ownership of this endpoint.
   *
   * @returns %File descriptor for read endpoint of pipeline.
   * @throws FileNotOwnedError when object  does not own read endpoint
   *   anymore.
   */
  int read_end() const;
  /**
   * @brief Get write endpoint.
   *
   * Get  the   file  descriptor  for   the  write  endpoint   of  the
   * pipeline. This does not release ownership of this endpoint.
   *
   * @returns %File descriptor for write endpoint of pipeline.
   * @throws FileNotOwnedError when object does not own write endpoint
   *   anymore.
   */
  int write_end() const;

  /**
   * @brief Get read endpoint, possibly taking ownership.
   *
   * Get the  file descriptor for  the read endpoint of  the pipeline.
   * When @e take_ownership is @c  true, the object loses ownership of
   * the read  endpoint.  It  is up  to the caller  to close  the file
   * descriptor when it is not needed anymore.
   *
   * @return %File descriptor for read endpoint of pipeline.
   * @throws FileNotOwnedError when object  does not own read endpoint
   *   anymore.
   */
  int read_end( bool take_ownership = false );
  /**
   * @brief Get write endpoint, possibly taking ownership.
   *
   * Get the file  descriptor for the write endpoint  of the pipeline.
   * When @e take_ownership is @c  true, the object loses ownership of
   * the write  endpoint.  It is  up to the  caller to close  the file
   * descriptor when it is not needed anymore.
   *
   * @return %File descriptor for write endpoint of pipeline.
   * @throws FileNotOwnedError when object does not own write endpoint
   *   anymore.
   */
  int write_end( bool take_ownership = false );

private:
  int pipefd_[2];
  bool owned_[2];
};

#endif //DICON_PIPE_HPP_

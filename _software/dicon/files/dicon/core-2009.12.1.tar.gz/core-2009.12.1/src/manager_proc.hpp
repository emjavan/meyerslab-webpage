#ifndef DICON_MANAGER_PROC_HPP_
#define DICON_MANAGER_PROC_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief ProcNodeManager interface.
 */
#include "manager.hpp"
#include "message.hpp"
#include <boost/mpi/request.hpp>
#include <deque>


namespace detail {
  class QuestionDispatcher;
}

/**
 * @brief Processing node manager interface.
 *
 * The  ProcNodeManager class  implements  the interface  to the  node
 * manager running on any processing node in the computing cluster. As
 * such,  it  must  be  filled  in with  implementations  of  how  the
 * processing node  manager processes each  request sent to it  by the
 * main node.
 *
 * Each of those virtual methods  to be implemented corresponds to the
 * %message with  the same name  used for node  intercommunication, as
 * defined  in the  documentation of  the message.hpp  class,  and the
 * matching   structures   defined   in  the   message::question   and
 * message::answer  namespaces.  See the  documentation that  is given
 * there for details on each available %message and its parameters.
 *
 * Any of the processing functions (start_logging(), init_optimizer(),
 * init_simulator(),    init_combined(),   get_policy(),   simulate(),
 * update(),   step_combined(),   dump_optimizer(),   dump_policies(),
 * shutdown()) is allowed to throw arbitrary exceptions. These will be
 * caught  inside the  run()  method which,  instead  of the  expected
 * answer %message  holding the return  value of the  function called,
 * will send an error %message back to the main node manager. In turn,
 * the   main  node   manager  will   deal  with   the   situation  as
 * appropriate. See the documentation of the MainNodeManager class for
 * details.
 */
class ProcNodeManager
  : public NodeManager
{
  friend class detail::QuestionDispatcher;

protected:
  /**
   * @brief Create processing node manager.
   *
   * Constructor that creates a  new node manager. This constructor is
   * protected as the ProcNodeManager  class is an abstract base class
   * that does not allow direct instantiation.
   *
   * @param world MPI communicator.
   */
  ProcNodeManager( boost::mpi::communicator &world );

public:
  virtual ~ProcNodeManager();

protected:
  /// Process starting logging.
  virtual void                      start_logging ( const boost::filesystem::path &logfile, LogLevel min_level                   ) = 0;
  /// Process initializing %optimizer.
  virtual void                      init_optimizer( const boost::filesystem::path &optimizer_logfile
                                                  , const boost::filesystem::path &simulator_logfile
                                                  , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                                                  , const std::string &simulator_command, const arguments_t &simulator_arguments
                                                  , const boost::optional<boost::filesystem::path> &optimizer_map_file
                                                  , const boost::optional<boost::filesystem::path> &optimizer_lib_file           ) = 0;
  /// Process initializing simulator.
  virtual void                      init_simulator( const boost::filesystem::path &simulator_logfile
                                                  , const std::string &simulator_command, const arguments_t &simulator_arguments ) = 0;
  /// Process initializing combined %optimizer/simulator.
  virtual void                      init_combined ( const boost::filesystem::path &optimizer_logfile
                                                  , const boost::filesystem::path &simulator_logfile
                                                  , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                                                  , const std::string &simulator_command, const arguments_t &simulator_arguments
                                                  , const boost::optional<boost::filesystem::path> &optimizer_map_file
                                                  , const boost::optional<boost::filesystem::path> &optimizer_lib_file           ) = 0;
  /// Process getting next policy.
  virtual boost::optional<policy_t> get_policy    (                                                                              ) = 0;
  /// Process simulating policy.
  virtual double                    simulate      ( const policy_t &policy                                                       ) = 0;
  /// Process updating reward.
  virtual void                      update        ( const policy_t &policy, double reward                                        ) = 0;
  /// Process taking step.
  virtual bool                      step_combined (                                                                              ) = 0;
  /// Process dumping %optimizer state.
  virtual void                      dump_optimizer( const boost::filesystem::path &file, DumpOptimizerMode mode                  ) = 0;
  /// Process dumping policies.
  virtual void                      dump_policies ( const boost::filesystem::path &file, unsigned count, bool display            ) = 0;
  /// Process shutting down.
  virtual bool                      shutdown      (                                                                              ) = 0;

public:
  /**
   * @brief Run processing node manager.
   *
   * Run the  processing node manager. This method  waits for incoming
   * requests from  the main node manager and  calls the corresponding
   * processing function to each request. It stops doing so as soon as
   * the  shutdown message  has  been received  and  confirmed by  the
   * implementation.
   *
   * This method should only be called once during the lifetime of the
   * ProcNodeManager object.
   */
  virtual void run();

private:
  void process();

private:
  bool shutdown_;
  int current_tag_;
  std::deque<boost::mpi::request> isend_queue_;
};

#endif //DICON_MANAGER_PROC_HPP_

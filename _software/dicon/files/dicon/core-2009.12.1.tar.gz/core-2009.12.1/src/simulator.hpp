#ifndef DICON_SIMULATOR_HPP_
#define DICON_SIMULATOR_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Simulator class.
 */
#include "error.hpp"
#include "message.hpp"
#include "../protobuf/cpp/simulator.pb.h"
#include "slavedriver.hpp"


/// %Simulator related error.
struct SimulatorError : virtual Error
{ virtual const char *what() const throw() { return "Simulator related error."; } };


/// Calling simulator function failed.
struct SimulatorSlaveError : virtual SimulatorError
{ virtual const char *what() const throw() { return "Calling simulator function failed."; } };

/// Calling simulator's children() failed.
struct SimulatorChildrenError : virtual SimulatorSlaveError
{ virtual const char *what() const throw() { return "Calling simulator's children() failed."; } };

/// Calling simulator's simulate() failed.
struct SimulatorSimulateError : virtual SimulatorSlaveError
{ virtual const char *what() const throw() { return "Calling simulator's simulate() failed."; } };

/// Calling simulator's display() failed.
struct SimulatorDisplayError : virtual SimulatorSlaveError
{ virtual const char *what() const throw() { return "Calling simulator's display() failed."; } };


/// %Simulator returned invalid reward value.
struct SimulatorInvalidRewardError : virtual SimulatorSimulateError
{ virtual const char *what() const throw() { return "Simulator returned invalid reward value."; } };


/**
 * @brief %Simulator wrapper.
 *
 * The  Simulator class wraps  a simulator  program.  It  provides the
 * necessary   mechanisms  for  using   the  Google   Protocol  Buffer
 * communication layer  between the system and  the simulator program;
 * and also provides recovery mechanisms in case the simulator program
 * unexpectedly dies.   In this case, two additional  attempts will be
 * made  per  request to  restart  the  simulator  program, before  an
 * exception  is  signaled by  either  of  children(), simulate(),  or
 * display().
 *
 * The logfile that  is given when constructing a  Simulator object is
 * never overwritten.   In fact, a new filename  is generated whenever
 * the simulator program has to  be restarted (in case it unexpectedly
 * died).   A new filename  that does  not exist  is generated  by the
 * means of File::unique() each  time this happens, using the original
 * filename given on construction as a template.
 *
 * A simulator to be used by the system should implement the following
 * functions  and  export  them  through the  Google  Protocol  Buffer
 * communication layer  as defined by  <code>simulator.proto</code> in
 * the @c  protobuf directory  distributed with the  system.  Wrappers
 * for some  programming languages are predefined in  the @c simulator
 * directory.
 *
 * - <code>%children()</code>: see children().
 * - <code>%simulate()</code>: see simulate().
 * - <code>%display()</code>: see display().
 */
class Simulator
  : public Slavedriver
{
public:
  /**
   * @brief Start simulator.
   *
   * Constructor that runs and initializes the simulator program given
   * by  @e command  with command-line  arguments @e  arguments.  This
   * also sets  up redirection of  the simulator's output  to standard
   * error, to the  logfile given by @e logfile,  unless @e logfile is
   * an  empty path.   Standard output  (not error)  of  the simulator
   * program is not  redirected as this is used  for the communication
   * with the system using the Google Protocol Buffers.
   *
   * If the  file given by  @e logfile already exists,  an alternative
   * filename  that does  not exist  will be  chosen by  the  means of
   * File::unique(),  so  that  the   original  logfile  will  not  be
   * overwritten.
   */
  Simulator( const boost::filesystem::path &logfile
           , const std::string &command, const std::vector<std::string> &arguments
           );

public:
  /**
   * @brief Get children of policy node.
   *
   * Get the  children of  the given policy  node. The policy  node in
   * question is  defined by the path  leading to it from  the root of
   * the  policy  tree. Each  element  in  this  path must  have  been
   * returned  by the  children() method  on a  prior  invocation. The
   * empty path is used to get  the children at the root of the policy
   * tree.
   *
   * The  following  code demonstrates  how  the  entire policy  space
   * defined  by a  simulator  can  be traversed  and  displayed in  a
   * reverse depth-first order.
   *
   * @code
Simulator simulator( ... );

typedef std::vector<std::string> path_t;

// Paths still left to do.
std::stack<path_t> paths;
paths.push( path_t() );

while( !paths.empty() ) {
  path_t path = paths.top();
  paths.pop();

  const std::vector<std::string> &children = simulator.children( path );

  if( children.empty() )
    std::cout << "Leaf: " << simulator.display( path ) << std::endl;
  else {
    // Add new paths (path plus child) to path list to do.
    BOOST_FOREACH( const std::string &child, children ) {
      path_t new_path = path;
      new_path.push_back( child );
      paths.push( new_path );
    }
  }
}
@endcode
   *
   * @param path Path to node in question.
   * @returns List of children at that node.
   *
   * @throws SimulatorChildrenError when getting list of children from
   *   simulator (<code>%children()</code>) failed.
   */
  std::vector<std::string> children( const std::vector<std::string> &path );
  /**
   * @brief Simulate the given policy.
   *
   * Simulate the given policy and return the reward value. The policy
   * must  be  a  path in  the  policy  tree  where  a prior  call  to
   * children() returned  an empty list. If the  reward value returned
   * from the simulator program is less than 0 or greater than 1, this
   * call fails.
   *
   * @param policy Policy to simulate.
   * @returns Reward value for policy.
   *
   * @throws  SimulatorSimulateError  when  simulating the  policy  in
   *   simulator (<code>%simulate()</code>) failed.
   * @throws  SimulatorInvalidRewardError when  the  reward value  was
   *   less than 0 or greater than 1.
   */
  double simulate( const policy_t &policy );
  /**
   * @brief Display the given policy.
   *
   * Display the policy given by @e policy. This is expected to return
   * a human-readable interpretation of the  given policy. It is up to
   * the  simulator   program  to   decide  what  is   an  appropriate
   * interpretation of the given policy.
   *
   * @param policy Policy to display.
   * @returns Human-readable interpretation.
   *
   * @throws SimulatorDisplayError  when displaying the  policy in the
   *   simulator (<code>%display()</code>) failed.
   */
  std::string display( const policy_t &policy );

private:
  void process( const proto::simulator::Question &question, proto::simulator::Answer &answer );
};

#endif //DICON_SIMULATOR_HPP_

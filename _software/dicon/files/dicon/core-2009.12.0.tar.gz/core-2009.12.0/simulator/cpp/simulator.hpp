#ifndef DICON_CPP_SIMULATOR_HPP_
#define DICON_CPP_SIMULATOR_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "communicator.hpp"
#include "simulator.pb.h"
#include <vector>


template< typename T >
class Simulator
  : public Communicator
{
public:
  Simulator();

public:
  void main();

public:
  virtual std::vector<T> children( const std::vector<T> &path ) = 0;
  virtual double simulate( const std::vector<T> &policy ) = 0;
  virtual std::string display( const std::vector<T> &policy ) = 0;

private:
  proto::simulator::Question read_question();
  proto::simulator::Answer new_answer();
  void write_answer( const proto::simulator::Answer &answer );

private:
  std::string pickle( const T &obj );
  T unpickle( const std::string &str );

private:
  void process();
};


#include "simulator.ipp"

#endif //DICON_CPP_SIMULATOR_HPP_

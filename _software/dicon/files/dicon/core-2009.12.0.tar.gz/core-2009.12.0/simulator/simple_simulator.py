#!/usr/bin/env python

#--- [Distribution] -----------------------------------------------
# This file is part of the Disease Control System DiCon.
#
# Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
# Designed and developed with the guidance of Nedialko B. Dimitrov
# and Lauren Ancel Meyers at the University of Texas at Austin.
#
# DiCon is free software: you  can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# DiCon  is distributed in  the hope  that it  will be  useful, but
# WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
#------------------------------------------------------------------

from python.simulator import Simulator


base = 5
depth = 2


class SimpleSimulator( Simulator ):
    def children( self, path ):
        if len(path) < depth:
            return range( 0, base )
        else:
            return []

    def simulate( self, policy ):
        value = 0.0
        factor = 1.0

        for digit in policy:
            factor /= base
            value += digit * factor

        return value

    def display( self, policy ):
        return str( policy )


if __name__ == "__main__":
    SimpleSimulator().main()

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "simulator.hpp"
#include "optimizer.hpp"
#include <boost/foreach.hpp>


Simulator::Simulator( const boost::filesystem::path &logfile
                    , const std::string &command, const std::vector<std::string> &arguments
                    )
  : Slavedriver(logfile, command, arguments)
{
}


void
Simulator::process( const proto::simulator::Question &question, proto::simulator::Answer &answer ) {
  execute( question, answer );

  if( answer.failed() )
    BOOST_THROW_EXCEPTION( SimulatorSlaveError() << errinfo_slave_error(answer.a_failure().what()) );
}


std::vector<std::string>
Simulator::children( const std::vector<std::string> &path ) {
  try {
    proto::simulator::Question question;

    // Formulate question.

    question.mutable_q_children();
    BOOST_FOREACH( const std::string &node, path )
      question.mutable_q_children()->add_node( node );

    question.set_type( proto::simulator::CHILDREN );

    // Parse answer.

    proto::simulator::Answer answer;
    process( question, answer );

    std::vector<std::string> children;
    BOOST_FOREACH( const std::string &node, answer.a_children().node() )
      children.push_back( node );

    return children;
  }
  catch( ... ) {
    BOOST_THROW_EXCEPTION( SimulatorChildrenError()
                           << errinfo_nested_exception(boost::current_exception()) );
  }
}


double
Simulator::simulate( const policy_t &policy ) {
  try {
    proto::simulator::Question question;

    // Formulate question.

    question.mutable_q_simulate();
    BOOST_FOREACH( const std::string &node, policy )
      question.mutable_q_simulate()->add_node( node );

    question.set_type( proto::simulator::SIMULATE );

    // Parse answer.

    proto::simulator::Answer answer;
    process( question, answer );

    // Clip result.

    double reward = answer.a_simulate().reward();

    if( !std::isfinite(reward) )
      BOOST_THROW_EXCEPTION( SimulatorInvalidRewardError() << errinfo_value<double>(reward) );

    double clipped = reward < 0 ? 0 : (reward > 1 ? 1 : reward);

    if( fabs(reward - clipped) > 1e-6 ) {
      BOOST_THROW_EXCEPTION( SimulatorInvalidRewardError() << errinfo_max_value<double>(1)
                             << errinfo_value<double>(reward) << errinfo_min_value<double>(0) );
    }

    return clipped;
  }
  catch( SimulatorInvalidRewardError & ) {
    // Do not catch with "..." below.
    throw;
  }
  catch( ... ) {
    BOOST_THROW_EXCEPTION( SimulatorSimulateError()
                           << errinfo_nested_exception(boost::current_exception()) );
  }
}


std::string
Simulator::display( const policy_t &policy ) {
  try {
    proto::simulator::Question question;

    // Formulate question.

    question.mutable_q_display();
    BOOST_FOREACH( const std::string &node, policy )
      question.mutable_q_display()->add_node( node );

    question.set_type( proto::simulator::DISPLAY );

    // Parse answer.

    proto::simulator::Answer answer;
    process( question, answer );

    return answer.a_display().display();
  }
  catch( ... ) {
    BOOST_THROW_EXCEPTION( SimulatorDisplayError()
                           << errinfo_nested_exception(boost::current_exception()) );
  }
}

#ifndef DICON_MANAGER_HPP_
#define DICON_MANAGER_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief NodeManager interface.
 */
#include "error.hpp"
#include "stats.hpp"
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>


/// Node manager related error.
struct NodeManagerError : virtual Error
{ virtual const char *what() const throw() { return "Node manager related error."; } };

/// Shutting down node manager failed.
struct NodeManagerShutdownError : virtual NodeManagerError
{ virtual const char *what() const throw() { return "Shutting down node manager failed."; } };


namespace boost {
  namespace mpi {
    class communicator;
  }
}

/**
 * @brief Node manager interface.
 *
 * The NodeManager  class represents the node manager  running on each
 * MPI node in the computing cluster. It is the abstract base class to
 * either  the  manager  running  on the  main  node  (MainNodeManager
 * interface, MainNodeManagerImpl  class) or  the ones running  on the
 * processing  nodes  (ProcNodeManager interface,  ProcNodeManagerImpl
 * class).
 */
class NodeManager
  : boost::noncopyable
{
public:
  /**
   * @brief Run node manager.
   *
   * Run the node manager.   This method implements the node manager's
   * specific function  (either main  node manager or  processing node
   * manager) and  can be though of  as the main function  of the node
   * manager. It should only be called once during the lifetime of the
   * NodeManager object.
   */
  virtual void run() = 0;

  virtual ~NodeManager() {}

  /**
   * @brief Create node manager.
   *
   * Create  a new  node manager  object. This  static  method creates
   * either an object of the implementing MainNodeManagerImpl class or
   * ProcNodeManagerImpl class,  depending on the  current node's rank
   * within the MPI  communicator context given by @e  world: when the
   * node with rank  0 calls this method, a main  node manager will be
   * created, otherwise a processing node manager will be created.
   *
   * @param world MPI communicator.
   * @returns Concrete node manager.
   */
  static boost::shared_ptr<NodeManager>
  create( boost::mpi::communicator &world );

protected:
  /**
   * @brief %Statistics helper.
   *
   * The StatsEntry class within the NodeManager class is used exactly
   * like  the  global  @link ::StatsEntry  StatsEntry@endlink  class,
   * except that  its first argument on construction  is a NodeManager
   * object.   This NodeManager provides  and encapsulates  the actual
   * Statistics   object   necessary   for  the   @link   ::StatsEntry
   * StatsEntry@endlink object  to work on.   The statistics collected
   * by  using  the  StatsEntry  class  are output  when  calling  the
   * log_statistics() method.
   */
  class StatsEntry
    : public ::StatsEntry
  {
  public:
    /**
     * @brief Push node onto tree.
     *
     * Constructor that  pushes another node onto  the statistics tree
     * defined   by  the   Statistics  object   encapsulated   in  the
     * NodeManager  object  given  as  @e  manager.   Apart  from  the
     * difference in the first argument, this constructor behaves like
     * the  one of  the global  @link  ::StatsEntry StatsEntry@endlink
     * class.
     *
     * @param manager NodeManager object.
     * @param what Node name.
     * @param priority Node priority.
     * @param idle Idle node name.
     * @param idle_priority Idle node priority.
     *
     * @throws TimeError when getting current time failed.
     */
    StatsEntry( NodeManager &manager, const std::string &what, int priority = 0,
                const std::string &idle = std::string(), int idle_priority = 0 );
  };

protected:
  /**
   * @brief Create node manager.
   *
   * Constructor that creates a  new node manager. This constructor is
   * protected as the NodeManager class is an abstract base class that
   * does not allow direct instantiation.
   *
   * @param world MPI communicator.
   */
  NodeManager( boost::mpi::communicator &world );

  /**
   * @brief Get MPI communicator.
   *
   * Get the MPI communicator used on construction.
   *
   * @returns MPI communicator.
   */
  const boost::mpi::communicator &world() const;
  /**
   * @brief Get MPI communicator.
   *
   * Get the MPI communicator used on construction.
   *
   * @returns MPI communicator.
   */
  boost::mpi::communicator &world();

  /**
   * @brief Print statistics.
   *
   * Print some statistics concerning  this node manager to the global
   * log system. The %message will  be logged using the info log level
   * (@link ::LOG_INFO LOG_INFO@endlink).
   */
  void log_statistics();

  /**
   * @brief Get minimum tag value.
   *
   * Get the minimum tag value that can be used in MPI communication.
   *
   * @returns Minimum tag value.
   */
  static int min_tag();
  /**
   * @brief Get maximum tag value.
   *
   * Get the maximum tag value that can be used in MPI communication.
   *
   * @returns Maximum tag value.
   */
  static int max_tag();
  /**
   * @brief Get number of tag values.
   *
   * Get the total number of different tag values available to be used
   * in MPI communication.  The actual  values are the ones within the
   * range  defined by  min_tag() and  max_tag().  The  range includes
   * both endpoints.
   *
   * @returns Number of tag values.
   */
  static unsigned tag_count();
  /**
   * @brief Get next tag value.
   *
   * Get the next  tag available to be used  in MPI communication. The
   * current tag  value given by @e  tag must be  within the available
   * range  defined by  min_tag() and  max_tag(), otherwise  this call
   * fails. The range includes both endpoints.
   *
   * @param tag Current tag value.
   * @returns Next available tag value.
   */
  static int &next_tag( int &tag );

private:
  boost::mpi::communicator &world_;
  Statistics stats_;
};


#include "manager.ipp"

#endif //DICON_MANAGER_HPP_

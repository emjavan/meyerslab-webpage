#ifndef DICON_UTIL_HPP_
#define DICON_UTIL_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Utility functions.
 */
#include "error.hpp"
#include <string>


/// Quoted-printable related error.
struct QPFormatError : virtual Error
{ virtual const char *what() const throw() { return "Quoted-printable related error."; } };


/**
 * @brief Decode quoted-printable string.
 *
 * Decode  the  string  given  by   @e  str  in  a  variation  of  the
 * quoted-printable  encoding, as  defined in  the description  of the
 * qp_encode() function.   If the data given  by @e str is  not of the
 * expected  format, this  call will  fail.  This  can happen  when an
 * equal sign (@c  =) in the input is not  followed by two hexadecimal
 * digits (@c 0 to @c 9 or @c A to @c F or @c a to @c f).
 *
 * @param str Data to decode.
 * @returns Original representation of data.
 * @throws QPFormatError when @e str is invalid.
 */
std::string qp_decode( const std::string &str );
/**
 * @brief Encode quoted-printable string.
 *
 * Encode  the  string  given  by   @e  str  in  a  variation  of  the
 * quoted-printable   encoding.    In   contrast   to   the   original
 * quoted-printable  encoding as  defined in  RFC 2045,  this function
 * implements no special handling of  line breaks, rather, it is to be
 * used when the  exact binary representation of the  data given by @e
 * str is  to be  encoded in a  textual way containing  only printable
 * characters (ASCII range 32 to  126). The space character (ASCII 32)
 * is also escaped whenever it appears  at the beginning or at the end
 * of the  input string.  Escaping is  done as described  in RFC 2045,
 * using <code>=XX</code> sequences, where  each @c X is a hexadecimal
 * digit (@c 0 to @c 9 or @c A to @c F).
 *
 * If escaping of additional characters  is needed, those can be given
 * in the @e add parameter.  Any character that appears in this string
 * will  also be  escaped and  not  be used  in the  result. The  only
 * characters not  allowed in this  string are the  hexadecimal digits
 * (@c 0 to @c 9 and @c A to @c F) and the equal sign (@c =), as those
 * are  used  for  the  quoted-printable  encoding. If  one  of  these
 * characters is given, the behavior of this function is undefined.
 *
 * The following code shows some examples of the encoding.
 *
 * @code
assert( qp_encode("Test")        == "Test"        );
assert( qp_encode("A\nB")        == "A=0AB"       );
assert( qp_encode(" blank ")     == "=20blank=20" );
assert( qp_encode("A,B&C", ",&") == "A=2CB=26C"   );
@endcode
 *
 * @param str Data to encode.
 * @param add Additional characters to escape.
 * @returns Quoted-printable representation of data.
 */
std::string qp_encode( const std::string &str, const std::string &add = std::string() );

#endif //DICON_UTIL_HPP_

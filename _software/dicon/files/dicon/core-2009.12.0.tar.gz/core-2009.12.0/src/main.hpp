#ifndef DICON_MAIN_HPP_
#define DICON_MAIN_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief The main() function.
 */
/**
 * @mainpage
 *
 * DiCon  is  the  Disease  Control  System.  It  provides  a  general
 * framework for solving optimization problems on distributed computer
 * clusters.
 *
 * This is  the main  source documentation on  DiCon.  It is  meant to
 * provide  an  introduction  to   how  the  system's  internals  work
 * together,  in order  to  facilitate future  development and  custom
 * modifications  to the  system. The  following entry  points  to the
 * documentation might be useful.
 *
 * <dl>
 * <dt>General definitions</dt>
 * <dd><dl>
 *   <dt>types.hpp file</dt>
 *   <dd>Global types in DiCon.</dd>
 *   <dt>log.hpp file</dt>
 *   <dd>Global log system to report debug and error information.</dd>
 *   <dt>specifier.hpp file</dt>
 *   <dd>Argument  and  schedule   specifiers  in  main  configuration
 *     file.</dd>
 * </dl></dd>
 * <dt>%Job handling</dt>
 * <dd><dl>
 *   <dt>Job structure</dt>
 *   <dd>Main  structure to hold  each %optimizer  job defined  in any
 *     DiCon run.</dd>
 *   <dt>LazySet and LazyValue interfaces</dt>
 *   <dd>Two  lazy  constructs used  to  create  concrete job  objects
 *     on-the-fly.</dd>
 * </dl></dd>
 * <dt>Node managers</dt>
 * <dd><dl>
 *   <dt>NodeManager,     MainNodeManager,     and     ProcNodeManager
 *     interfaces</dt>
 *   <dd>Split  of processing  cluster into  main node  and processing
 *     nodes.</dd>
 *   <dt>message.hpp file</dt>
 *   <dd>Actions  available at processing  node for  the main  node to
 *     call.</dd>
 * </dl></dd>
 * <dt>External interfaces</dt>
 * <dd><dl>
 *   <dt>Communicator class</dt>
 *   <dd>Message-oriented protocol for simulators.</dd>
 *   <dt>Simulator class</dt>
 *   <dd>Interface that custom simulators must fulfill.</dd>
 *   <dt>optimizer namespace</dt>
 *   <dd>Interface that custom %optimizers must fulfill.</dd>
 * </dl></dd>
 * </dl>
 */
/**
 * @brief Main entry point.
 *
 * The   main   function   is   the   main  entry   point   into   the
 * program. Execution of everything starts here.
 *
 * @param argc Command-line argument count.
 * @param argv Command-line argument array.
 * @returns Process return value.
 */
int main( int argc, char *argv[] );

#endif //DICON_MAIN_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "optimizer.hpp"
#include "log.hpp"
#include "util.hpp"
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/filesystem/operations.hpp>
#include <boost/foreach.hpp>
#include <boost/format.hpp>
#include <boost/scoped_ptr.hpp>
#include <fstream>


namespace detail {

  static Optimizer *optimizer_instance = NULL;

}



namespace detail {

  extern "C"
  int
  optimizer_children( const optimizer::node_t *path, const optimizer::node_t **children ) {
    try {
      try {
        if( detail::optimizer_instance == NULL )
          BOOST_THROW_EXCEPTION( AssertionError() );

        detail::optimizer_instance->children_c( path, children );
        return 0;
      }
      catch( boost::exception &e ) {
        log_error( (boost::format("Optimizer children callback failed.\n%s")
                    % boost::diagnostic_information(e)).str() );
        return -1;
      }
    }
    catch( ... ) {
      return -99;
    }
  }

}



template< typename T >
void
Optimizer::load_symbol( T &variable, const std::string &symbol ) {
  *reinterpret_cast<void **>(&variable) = library_[symbol];
}


Optimizer::Optimizer( const boost::filesystem::path &optimizer_logfile
                    , const boost::filesystem::path &simulator_logfile
                    , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                    , const std::string &simulator_command, const arguments_t &simulator_arguments
                    , const boost::optional<boost::filesystem::path> &optimizer_map_file
                    , const boost::optional<boost::filesystem::path> &optimizer_lib_file
                    )
  : library_(optimizer_library), simulator_(simulator_logfile, simulator_command, simulator_arguments),
    policy_count_(0)
{
  if( detail::optimizer_instance != NULL )
    BOOST_THROW_EXCEPTION( AssertionError() );

  if( !optimizer_logfile.empty() ) {
    File file = File::unique( optimizer_logfile );
    stdout_.reset( new Redirector(file.file(), STDOUT_FILENO) );
    stderr_.reset( new Redirector(file.file(), STDERR_FILENO) );
  }

  if( optimizer_map_file )
    load_state( optimizer_map_file->file_string() );

  try {
    detail::optimizer_instance = this;

    load_symbol( initialize_, "initialize" );
    load_symbol( get_policy_, "get_policy" );
    load_symbol( update_    , "update"     );
    load_symbol( policies_  , "policies"   );
    load_symbol( dump_state_, "dump_state" );
    load_symbol( get_error_ , "get_error"  );

    initialize( optimizer_library, optimizer_arguments,
                detail::optimizer_children, optimizer_lib_file );
  }
  catch( ... ) {
    // Make sure to unregister instance.
    detail::optimizer_instance = NULL;
    throw;
  }
}


Optimizer::~Optimizer() {
  assert( detail::optimizer_instance == this );
  detail::optimizer_instance = NULL;
}


void
Optimizer::load_state( std::istream &in ) {
  boost::archive::binary_iarchive( in )
    >> boost::serialization::make_nvp( "nodes", nodes_ );
}


void
Optimizer::save_state( std::ostream &out ) {
  boost::archive::binary_oarchive( out )
    << boost::serialization::make_nvp( "nodes", nodes_ );
}


void
Optimizer::load_state( const std::string &file ) {
  std::ifstream in( file.c_str() );
  if( in.fail() )
    BOOST_THROW_EXCEPTION( FileReadError() << errinfo_file_name(file) );
  load_state( in );
}


void
Optimizer::save_state( const std::string &file ) {
  std::ofstream out( file.c_str() );
  save_state( out );
  if( out.fail() )
    BOOST_THROW_EXCEPTION( FileWriteError() << errinfo_file_name(file) );
}


policy_t
Optimizer::id_to_name( const optimizer::node_t *const list ) {
  std::vector<std::string> policy;

  for( size_t i = 0; list[i]; ++i ) {
    nodes_t::map_by<id>::const_iterator it;

    if( (it = nodes_.by<id>().find(list[i])) == nodes_.by<id>().end() )
      BOOST_THROW_EXCEPTION( OptimizerUnknownNodeError() << errinfo_value<optimizer::node_t>(list[i]) );

    policy.push_back( it->second );
  }

  return policy;
}


const optimizer::node_t *
Optimizer::name_to_id( const policy_t &policy ) {
  temporary_.clear();

  BOOST_FOREACH( const std::string &node, policy ) {
    nodes_t::map_by<name>::const_iterator it;

    if( (it = nodes_.by<name>().find(node)) == nodes_.by<name>().end() ) {
      size_t new_id = nodes_.size() + 1;

      if( new_id >= size_t(std::numeric_limits<optimizer::node_t>::max()) ) {
        BOOST_THROW_EXCEPTION( OptimizerTooManyNodesError() << errinfo_value<size_t>(nodes_.size())
                               << errinfo_max_value<size_t>(size_t(std::numeric_limits<optimizer::node_t>::max())-1) );
      }

      it = nodes_.by<name>().insert( std::make_pair(node, new_id) ).first;
    }

    assert( it->second != 0 );
    temporary_.push_back( it->second );
  }

  temporary_.push_back( 0 );
  return temporary_.data();
}


void
Optimizer::children_c( const optimizer::node_t *const path, const optimizer::node_t **const children ) {
  *children = name_to_id(simulator_.children( id_to_name(path) ));
}


boost::optional<policy_t>
Optimizer::get_policy() {
  assert( policy_count_ <= std::numeric_limits<policy_count_t>::max() );
  if( policy_count_ == std::numeric_limits<policy_count_t>::max() )
    BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<policy_count_t>(policy_count_) );

  const optimizer::node_t *policy;

  // This call to get_policy_() might in turn (and probably will in most
  // cases) result in the library indirectly calling children_c() above.

  if( get_policy_(&policy) != 0 )
    BOOST_THROW_EXCEPTION( OptimizerGetPolicyError() << errinfo_slave_error(get_error_()) );

  assert( policy_count_ < std::numeric_limits<policy_count_t>::max() );

  if( policy != NULL ) {
    ++policy_count_;  // count
    return id_to_name( policy );
  }
  else
    return boost::none;
}


void
Optimizer::update( const policy_t &policy, double reward ) {
  if( policy_count_ == 0 )
    BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<policy_count_t>(policy_count_) );

  DICON_ASSERT_RANGE<double>( reward, 0, 1 );

  if( update_(name_to_id(policy), reward) != 0 )
    BOOST_THROW_EXCEPTION( OptimizerUpdateError() << errinfo_slave_error(get_error_()) );

  assert( policy_count_ > 0 );
  --policy_count_;
}


Optimizer::policies_result_type
Optimizer::policies( unsigned count ) {
  if( policy_count_ != 0 )
    BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<policy_count_t>(policy_count_) );

  const optimizer::node_t *policies;
  const double *rewards;

  if( policies_(&count, &policies, &rewards) != 0 )
    BOOST_THROW_EXCEPTION( OptimizerPoliciesError() << errinfo_slave_error(get_error_()) );

  policies_result_type list;

  size_t offset = 0;
  for( unsigned i = 0; i < count; ++i ) {
    const policy_t &policy
      = id_to_name( policies+offset );

    offset += (policy.size() + 1);
    list.push_back( policies_result_type::value_type(policy, rewards[i]) );
  }

  return list;
}


void
Optimizer::dump_optimizer_map( const boost::filesystem::path &file ) {
  if( policy_count_ != 0 )
    BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<policy_count_t>(policy_count_) );

  boost::filesystem::path tmp_file = File::unique_temporary( file );

  save_state( tmp_file.file_string() );

  File::rename( tmp_file, file );
}


void
Optimizer::dump_optimizer_lib( const boost::filesystem::path &file ) {
  if( policy_count_ != 0 )
    BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<policy_count_t>(policy_count_) );

  boost::filesystem::path tmp_file = File::unique_temporary( file );

  if( dump_state_(tmp_file.file_string().c_str()) != 0 )
    BOOST_THROW_EXCEPTION( OptimizerDumpStateError() << errinfo_slave_error(get_error_()) );

  File::rename( tmp_file, file );
}



namespace detail {

  static
  std::string
  policy_to_str( const policy_t &policy ) {
    std::string result;

    bool first = true;
    BOOST_FOREACH( const std::string &node, policy ) {
      if( !first )
        result += ',';
      else
        first = false;

      result += qp_encode( node, "," );
    }

    return result;
  }

}



void
Optimizer::dump_policies( const boost::filesystem::path &file, unsigned count, bool display ) {
  if( policy_count_ != 0 )
    BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<policy_count_t>(policy_count_) );

  boost::filesystem::path tmp_file = File::unique_temporary( file );

  {
    std::ofstream out( tmp_file.file_string().c_str() );

    BOOST_FOREACH( const policies_result_type::value_type &entry, policies(count) ) {
      const policy_t &policy = entry.first;
      const double &reward = entry.second;

      std::string str;

      if( display )
        str = qp_encode( simulator_.display(policy) );
      else
        str = detail::policy_to_str( policy );

      out << (boost::format("%.12f") % reward) << std::endl
          << str << std::endl;
    }

    if( out.fail() )
      BOOST_THROW_EXCEPTION( FileWriteError() << errinfo_file_name(tmp_file.file_string()) );

    out.close();
  }

  File::rename( tmp_file, file );
}


void
Optimizer::initialize( const std::string &name, const arguments_t &arguments,
                       optimizer::children_t children, const boost::optional<boost::filesystem::path> &state_file )
{
  std::vector<const char *> argv;
  argv.push_back( name.c_str() );

  BOOST_FOREACH( const std::string &arg, arguments ) {
    argv.push_back( arg.c_str() );
  }

  if( initialize_(argv.size(), argv.data(), children,
                  state_file ? state_file->file_string().c_str() : NULL) != 0 )
  {
    BOOST_THROW_EXCEPTION( OptimizerInitializeError() << errinfo_slave_error(get_error_()) );
  }
}


Simulator &
Optimizer::simulator() {
  return simulator_;
}


Combined::Combined( const boost::filesystem::path &optimizer_logfile
                  , const boost::filesystem::path &simulator_logfile
                  , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                  , const std::string &simulator_command, const arguments_t &simulator_arguments
                  , const boost::optional<boost::filesystem::path> &optimizer_map_file
                  , const boost::optional<boost::filesystem::path> &optimizer_lib_file
                  )
  : optimizer_(optimizer_logfile, simulator_logfile,
               optimizer_library, optimizer_arguments,
               simulator_command, simulator_arguments,
               optimizer_map_file, optimizer_lib_file)
{
}


void
Combined::dump_optimizer_map( const boost::filesystem::path &file ) {
  optimizer_.dump_optimizer_map( file );
}


void
Combined::dump_optimizer_lib( const boost::filesystem::path &file ) {
  optimizer_.dump_optimizer_lib( file );
}


void
Combined::dump_policies( const boost::filesystem::path &file, unsigned count, bool display ) {
  optimizer_.dump_policies( file, count, display );
}


bool
Combined::step() {
  const boost::optional<policy_t> &policy = optimizer_.get_policy();

  if( !policy )
    return false;

  double reward = optimizer_.simulator().simulate( *policy );

  optimizer_.update( *policy, reward );

  return true;
}

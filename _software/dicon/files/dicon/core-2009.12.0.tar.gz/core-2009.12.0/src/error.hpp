#ifndef DICON_ERROR_HPP_
#define DICON_ERROR_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Exception related classes, macros and functions.
 */
#include <boost/exception.hpp>
#include <boost/version.hpp>


/**
 * @brief Define new @c errinfo structure.
 *
 * Define a new @c errinfo structure to be used with Boost's exception
 * mechanism (see Boost reference). The name of the new structure will
 * have the prefix @c errinfo_ and  the suffix given by @e NAME (e.g.,
 * if @e NAME is @c value, the class will be named @c %errinfo_value).
 *
 * @param NAME Suffix of the new @c errinfo structure.
 * @param TYPE Type of the new @c errinfo structure.
 *
 * @see DICON_ERRINFO_TPL.
 */
#define DICON_ERRINFO(NAME, TYPE)                                       \
struct errinfo_##NAME                                                   \
  : boost::error_info<struct errinfo_##NAME##_, TYPE>                   \
{                                                                       \
  typedef boost::error_info<errinfo_##NAME##_, TYPE>                    \
    errinfo_t;                                                          \
  errinfo_##NAME( const TYPE &value )                                   \
    : boost::error_info<errinfo_##NAME##_, TYPE>(value) {}              \
}


/**
 * @brief Define new @c errinfo class with template.
 *
 * Define a new @c errinfo structure to be used with Boost's exception
 * mechanism (see Boost reference).  In contrast to DICON_ERRINFO, the
 * structure defined by this macro  will be templated with exactly one
 * parameter that  gives the type of  the value carried by  the new @c
 * errinfo structure.
 *
 * The name of the new structure  will have the prefix @c errinfo_ and
 * the suffix  given by  @e NAME (e.g.,  if @e  NAME is @c  value, the
 * class will be named @c %errinfo_value).
 *
 * @param NAME Suffix of the new @c errinfo structure.
 *
 * @see DICON_ERRINFO.
 */
#define DICON_ERRINFO_TPL(NAME)                                         \
template< typename T >                                                  \
struct errinfo_##NAME                                                   \
  : boost::error_info<struct errinfo_##NAME##_, T>                      \
{                                                                       \
  typedef boost::error_info<errinfo_##NAME##_, T>                       \
    errinfo_t;                                                          \
  errinfo_##NAME( const T &value )                                      \
    : boost::error_info<errinfo_##NAME##_, T>(value) {}                 \
}

#if BOOST_VERSION >= 104000
using boost::errinfo_errno;
using boost::errinfo_api_function;
#else
DICON_ERRINFO( errno, int );
DICON_ERRINFO( api_function, std::string );
#endif

/// Errinfo storing the pointer to another exception.
DICON_ERRINFO( nested_exception, boost::exception_ptr );

/// Templated errinfo storing the actual value.
DICON_ERRINFO_TPL( value );
/// Templated errinfo storing the minimum allowed value.
DICON_ERRINFO_TPL( min_value );
/// Templated errinfo storing the maximum allowed value.
DICON_ERRINFO_TPL( max_value );
/// Templated errinfo storing the expected value.
DICON_ERRINFO_TPL( expected_value );


/// Unspecified error.
struct Error : public virtual std::exception, public virtual boost::exception
{
  /// Get a general description of the error.
  virtual const char *what() const throw() { return "Unspecified error."; }
};


/// Assertion failed; invalid condition occurred.
struct AssertionError : virtual Error
{ virtual const char *what() const throw() { return "Assertion failed; invalid condition occurred."; } };

/// System call or system-related call failed.
struct SystemError : virtual Error
{ virtual const char *what() const throw() { return "System call or system-related call failed."; } };


/// Operation failed during I/O.
struct IOError : virtual SystemError
{ virtual const char *what() const throw() { return "Operation failed during I/O."; } };

/// Read failed while performing I/O.
struct IOReadError : virtual IOError
{ virtual const char *what() const throw() { return "Read failed while performing I/O."; } };

/// Write failed while performing I/O.
struct IOWriteError : virtual IOError
{ virtual const char *what() const throw() { return "Write failed while performing I/O."; } };


/// Calculation did not succeed.
struct CalculationError : virtual Error
{ virtual const char *what() const throw() { return "Calculation did not succeed."; } };

/// Calculation gave non-finite result.
struct CalculationNotFiniteError : virtual CalculationError
{ virtual const char *what() const throw() { return "Calculation gave non-finite result."; } };


/// Unix signal related operation failed.
struct SignalError : virtual SystemError
{ virtual const char *what() const throw() { return "Unix signal related operation failed."; } };

/// System time related operation failed.
struct TimeError : virtual SystemError
{ virtual const char *what() const throw() { return "System time related operation failed."; } };


/**
 * @brief Check if value is in range.
 *
 * Check if the given value is finite and within the given range. This
 * function throws  an exception of type AssertionError  when @e value
 * is less  than @e  minimum or greater  than @e maximum.   The actual
 * check performed is as follows.
 *
 * @code
if( !(minimum <= value && value <= maximum) ) {
  // Throw AssertionError().
}
@endcode
 *
 * The  resulting  AssertionError  will  have the  errinfo  structures
 * errinfo_value,   errinfo_min_value,   and   errinfo_max_value   set
 * accordingly.
 *
 * @param value Value to check.
 * @param minimum Minimum allowed value.
 * @param maximum Maximum allowed value.
 * @throws AssertionError when value is not within range.
 */
template< typename T >
void DICON_ASSERT_RANGE( const T &value, const T &minimum, const T &maximum );


#include "error.ipp"

#endif //DICON_ERROR_HPP_

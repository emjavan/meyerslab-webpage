#ifndef DICON_MANAGER_PROC_IMPL_HPP_
#define DICON_MANAGER_PROC_IMPL_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief ProcNodeManagerImpl class.
 */
#include "manager_proc.hpp"
#include "optimizer.hpp"
#include "simulator.hpp"


class LogFile;

/**
 * @brief Processing node manager implementation.
 *
 * The ProcNodeManagerImpl  class implements the  node manager running
 * on any processing node  inside the computing cluster. Specifically,
 * it handles all the requests sent  to it by the main node manager in
 * order to achieve the required functionality.
 *
 * As  defined  in  the  NodeManager interface,  the  processing  node
 * manager is run by calling the run() method.
 */
class ProcNodeManagerImpl
  : public ProcNodeManager
{
  friend class NodeManager;

protected:
  /**
   * @brief Create processing node manager.
   *
   * Constructor  that creates  a new  processing node  manager.  This
   * constructor is protected since objects of the ProcNodeManagerImpl
   * class  are  only  to  be  costructed  through  the  static  @link
   * NodeManager::create() create()@endlink  method of the NodeManager
   * class.
   *
   * @param world MPI communicator.
   */
  ProcNodeManagerImpl( boost::mpi::communicator &world );

protected:
  virtual void                      start_logging ( const boost::filesystem::path &logfile, LogLevel min_level                   );
  virtual void                      init_optimizer( const boost::filesystem::path &optimizer_logfile
                                                  , const boost::filesystem::path &simulator_logfile
                                                  , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                                                  , const std::string &simulator_command, const arguments_t &simulator_arguments
                                                  , const boost::optional<boost::filesystem::path> &optimizer_map_file
                                                  , const boost::optional<boost::filesystem::path> &optimizer_lib_file           );
  virtual void                      init_simulator( const boost::filesystem::path &simulator_logfile
                                                  , const std::string &simulator_command, const arguments_t &simulator_arguments );
  virtual void                      init_combined ( const boost::filesystem::path &optimizer_logfile
                                                  , const boost::filesystem::path &simulator_logfile
                                                  , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                                                  , const std::string &simulator_command, const arguments_t &simulator_arguments
                                                  , const boost::optional<boost::filesystem::path> &optimizer_map_file
                                                  , const boost::optional<boost::filesystem::path> &optimizer_lib_file           );
  virtual boost::optional<policy_t> get_policy    (                                                                              );
  virtual double                    simulate      ( const policy_t &policy                                                       );
  virtual void                      update        ( const policy_t &policy, double reward                                        );
  virtual bool                      step_combined (                                                                              );
  virtual void                      dump_optimizer( const boost::filesystem::path &file, DumpOptimizerMode mode                  );
  virtual void                      dump_policies ( const boost::filesystem::path &file, unsigned count, bool display            );
  virtual bool                      shutdown      (                                                                              );

private:
  void reset_all( bool logfile = false );

private:
  boost::shared_ptr<LogFile> logfile_;
  boost::scoped_ptr<Optimizer> optimizer_;
  boost::scoped_ptr<Simulator> simulator_;
  boost::scoped_ptr<Combined > combined_;
};

#endif //DICON_MANAGER_PROC_IMPL_HPP_

#ifndef DICON_TYPES_HPP_
#define DICON_TYPES_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief General types.
 */
#include <stdint.h>
#include <string>
#include <vector>


/**
 * @brief Log level.
 *
 * The  @link ::LogLevel LogLevel@endlink  enum defines  the different
 * log levels  available in the main  log system, as  described in the
 * log.hpp file.
 */
enum LogLevel
{ LOG_DEBUG   /// Debug messages.
, LOG_INFO    /// Info messages.
, LOG_WARNING /// Warning messages.
, LOG_ERROR   /// %Error messages.
, LOG_FAILURE /// Failure messages.
};


/// Convert textual representation to log level.
std::istream &operator>>( std::istream &in, LogLevel &result );


/**
 * @brief %Job ID.
 *
 * The @link  ::job_id_t job_id_t@endlink  type defines the  type used
 * for job IDs. A valid job  ID is a positive integer within the range
 * defined by this  type. The special value 0 can  be used to indicate
 * an error  condition or an invalid job  as it is not  used for valid
 * jobs.
 *
 * @see Job structure.
 */
typedef size_t job_id_t;
/**
 * @brief Simulation count.
 *
 * The  @link ::simcount_t  simcount_t@endlink type  defines  the type
 * used  for  simulation  counts.   A  valid  simulation  count  is  a
 * non-negative  integer within  the range  defined by  this  type. As
 * there can easily  exist more than 4 billion  simulations within one
 * optimization run  (including system restarts  after checkpointing),
 * this type provides at least 64 bits.
 */
typedef uint64_t simcount_t;

/// Argument set.
typedef std::vector<std::string> arguments_t;
/// Policy path.
typedef std::vector<std::string> policy_t;

#endif //DICON_TYPES_HPP_

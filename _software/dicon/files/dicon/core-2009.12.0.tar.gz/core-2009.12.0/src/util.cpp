/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "util.hpp"

#include <boost/format.hpp>
#include <boost/scoped_array.hpp>
#include <cstring>
#include <stdexcept>


namespace detail {

  static
  char
  hex_to_chr( unsigned char x, bool upcase = false ) {
    DICON_ASSERT_RANGE<unsigned char>( x, 0, 15 );

    if( 0 <= x && x < 10 )
      return char( x + static_cast<unsigned char>('0') );
    else
      return char( (x-10) + static_cast<unsigned char>(upcase ? 'A' : 'a') );
  }


  static
  unsigned char
  chr_to_hex( char x ) {
    if( '0' <= x && x <= '9' )
      return static_cast<unsigned char>(x) - static_cast<unsigned char>('0');
    else if( 'a' <= x && x <= 'f' )
      return static_cast<unsigned char>(x) - static_cast<unsigned char>('a') + 10;
    else if( 'A' <= x && x <= 'F' )
      return static_cast<unsigned char>(x) - static_cast<unsigned char>('A') + 10;
    else
      BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<char>(x) );
  }

}



std::string
qp_decode( const std::string &str ) {
  std::string result;

  for( size_t i = 0; i < str.length(); ++i ) {
    unsigned char x = static_cast<unsigned char>( str[i] );

    if( x == 61 ) {
      if( i < str.length()-2 ) {
        try {
          x = detail::chr_to_hex(str[i+1]) * 16 + detail::chr_to_hex(str[i+2]);
          i += 2;
        }
        catch( boost::exception &e ) {
          BOOST_THROW_EXCEPTION( QPFormatError() << errinfo_value<std::string>(str.substr(i, 3))
                                 << errinfo_nested_exception(boost::copy_exception(e)) );
        }
      }
      else
        BOOST_THROW_EXCEPTION( QPFormatError() );
    }

    result += char( x );
  }

  return result;
}


std::string
qp_encode( const std::string &str, const std::string &add ) {
  std::string result;

  for( size_t i = 0; i < str.length(); ++i ) {
    unsigned char x = static_cast<unsigned char>( str[i] );

    if( (33 <= x && x <= 126 && x != 61 && add.find(x) == std::string::npos)
        || (x == 32 && i != 0 && i != (str.length() - 1)) )
    {
      // All printable ASCII characters (except '=' and those in add)
      // can be represented by themselves. Also spaces not at begin
      // or end of input string are represented by themselves.
      result += char( x );
    }
    else {
      // Escape according to quoted-printable encoding.
      result += '=';
      result += detail::hex_to_chr( x/16, true );
      result += detail::hex_to_chr( x%16, true );
    }
  }

  return result;
}

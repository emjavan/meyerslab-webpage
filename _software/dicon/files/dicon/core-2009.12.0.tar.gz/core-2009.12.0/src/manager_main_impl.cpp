/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "manager_main_impl.hpp"
#include "file.hpp"
#include <boost/archive/xml_iarchive.hpp>
#include <boost/archive/xml_oarchive.hpp>
#include <fstream>


namespace detail {

  static const std::string default_config_file       = "main.conf";

  static const std::string default_main_logfile      = "log/main.log";
  static const std::string default_node_logfile_mask = "log/node_%04u.log";

  static const LogLevel default_main_log_level       = LOG_INFO;
  static const LogLevel default_node_log_level       = LOG_INFO;


  static
  std::string
  command_line( const std::string &command, const arguments_t &arguments ) {
    std::string result;

    result += command;
    BOOST_FOREACH( const std::string &argument, arguments ) {
      result += ' ';
      result += argument;
    }

    return result;
  }

}



MainNodeManagerImpl::JobInfo::JobInfo()
  : state(JOB_INIT_OPTIMIZER), combined_node(false),
    optimizer_initd(false), ign_checkpoints(false), getting_policy(false),
    out_of_policy(false), starting_up(true), failure(false),
    dumping_count(0), total_policies(0), checkpoint_skips(0), pending_step_calls(0),
    checkpoint_time(time_t(-1)), checkpoint_sims(0)
{
}


MainNodeManagerImpl::NodeInfo::NodeInfo()
  : simulator_initd(false)
{
}


MainNodeManagerImpl::MainNodeManagerImpl( boost::mpi::communicator &world )
  : MainNodeManager(world), shutdown_(false), jobs_done_(0)
{
  StatsEntry se( *this, "starting up", 0 );

  for( int node = min_child(); node <= max_child(); ++node )
    job_map_.register_node( node );

  // Load main configuration.

  const std::string config_file = detail::default_config_file;
  config_.import( config_file );

  // Initialize main logfile.

  const std::string &main_logfile   = config_.get( "global", "main_logfile"  , detail::default_main_logfile   );
  LogLevel           main_log_level = config_.get( "global", "main_log_level", detail::default_main_log_level );

  log_file_.reset( new LogFile(main_logfile) );
  log_register_sink( log_file_, main_log_level );

  // Create master's job queue.

  try {
    job_queue_.reset( new JobQueue(config_) );
  }
  catch( boost::exception &e ) {
    e << errinfo_config_file(config_file);
    throw;
  }

  // Initialize node logfiles.

  for( int node = min_child(); node <= max_child(); ++node ) {
    const std::string &node_logfile_mask = config_.get( "global", "node_logfile"  , detail::default_node_logfile_mask );
    LogLevel           node_log_level    = config_.get( "global", "node_log_level", detail::default_node_log_level    );
    boost::filesystem::path node_logfile;

    {
      boost::format formatter( node_logfile_mask );

      using namespace boost::io;
      // Ignore error when mask does not contain a placeholder.
      formatter.exceptions( all_error_bits ^ too_many_args_bit );

      node_logfile = (formatter % node).str();
    }

    start_logging( node, node_logfile, node_log_level );
  }
}


boost::filesystem::path
MainNodeManagerImpl::job_logfile( const Job::ptr_t &job ) {
  return job->job_directory / job->job_logfile;
}


boost::filesystem::path
MainNodeManagerImpl::checkpoint_file( const Job::ptr_t &job ) {
  return job->job_directory / job->checkpoint_file;
}


boost::filesystem::path
MainNodeManagerImpl::opt_logfile( const Job::ptr_t &job, int node ) {
  boost::format formatter( job->opt_logfile_mask );

  using namespace boost::io;
  // Ignore error when mask does not contain a placeholder.
  formatter.exceptions( all_error_bits ^ too_many_args_bit );

  return job->job_directory / (formatter % node).str();
}


boost::filesystem::path
MainNodeManagerImpl::sim_logfile( const Job::ptr_t &job, int node ) {
  boost::format formatter( job->sim_logfile_mask );

  using namespace boost::io;
  // Ignore error when mask does not contain a placeholder.
  formatter.exceptions( all_error_bits ^ too_many_args_bit );

  return job->job_directory / (formatter % node).str();
}


boost::filesystem::path
MainNodeManagerImpl::optimizer_map_file( const Job::ptr_t &job, simcount_t simulation ) {
  boost::format formatter( job->optimizer_map_file_mask );

  using namespace boost::io;
  // Ignore error when mask does not contain a placeholder.
  formatter.exceptions( all_error_bits ^ too_many_args_bit );

  return job->job_directory / (formatter % simulation).str();
}


boost::filesystem::path
MainNodeManagerImpl::optimizer_lib_file( const Job::ptr_t &job, simcount_t simulation ) {
  boost::format formatter( job->optimizer_lib_file_mask );

  using namespace boost::io;
  // Ignore error when mask does not contain a placeholder.
  formatter.exceptions( all_error_bits ^ too_many_args_bit );

  return job->job_directory / (formatter % simulation).str();
}


boost::filesystem::path
MainNodeManagerImpl::policy_bin_dumpfile( const Job::ptr_t &job, simcount_t simulation ) {
  boost::format formatter( job->policy_bin_dumpfile_mask );

  using namespace boost::io;
  // Ignore error when mask does not contain a placeholder.
  formatter.exceptions( all_error_bits ^ too_many_args_bit );

  return job->job_directory / (formatter % simulation).str();
}


boost::filesystem::path
MainNodeManagerImpl::policy_txt_dumpfile( const Job::ptr_t &job, simcount_t simulation ) {
  boost::format formatter( job->policy_txt_dumpfile_mask );

  using namespace boost::io;
  // Ignore error when mask does not contain a placeholder.
  formatter.exceptions( all_error_bits ^ too_many_args_bit );

  return job->job_directory / (formatter % simulation).str();
}


boost::filesystem::path
MainNodeManagerImpl::policy_bin_result( const Job::ptr_t &job ) {
  return job->job_directory / job->policy_bin_result;
}


boost::filesystem::path
MainNodeManagerImpl::policy_txt_result( const Job::ptr_t &job ) {
  return job->job_directory / job->policy_txt_result;
}


void
MainNodeManagerImpl::finish_start_logging( int node ) {
  // Nothing to do.
}


void
MainNodeManagerImpl::finish_init_optimizer( int node ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );
  assert( !job_info.combined_node );

  assert( !job_info.optimizer_initd );
  job_info.optimizer_initd = true;
}


void
MainNodeManagerImpl::finish_init_simulator( int node ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );
  assert( !job_info.combined_node );
  (void) job_info;

  NodeInfo &node_info = job_map_.node_info( job, node );

  assert( !node_info.simulator_initd );
  node_info.simulator_initd = true;
}


void
MainNodeManagerImpl::finish_init_combined( int node ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );
  assert( job_info.combined_node );

  assert( !job_info.optimizer_initd );
  job_info.optimizer_initd = true;
}


void
MainNodeManagerImpl::finish_get_policy( int node, const boost::optional<policy_t> &policy ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );
  assert( !job_info.combined_node );

  assert( job_info.getting_policy );
  job_info.getting_policy = false;

  assert( !job_info.out_of_policy );

  if( policy ) {
    job_info.backlog.push( *policy );
    ++job_info.total_policies;
  }
  else
    job_info.out_of_policy = true;
}


void
MainNodeManagerImpl::finish_simulate( int node, double reward ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );
  assert( !job_info.combined_node );

  int opt_node = job_map_.optimizer_node( job );
  NodeInfo &node_info = job_map_.node_info( job, node );

  assert( !node_info.simulate_queue.empty() );
  policy_t policy = node_info.simulate_queue.front();
  node_info.simulate_queue.pop();

  update( opt_node, policy, reward );

  job_info.update_queue.push( policy );
}


void
MainNodeManagerImpl::finish_update( int node ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );
  assert( !job_info.combined_node );

  assert( !job_info.update_queue.empty() );
  job_info.update_queue.pop();

  job_info.out_of_policy = false;
}


void
MainNodeManagerImpl::finish_step_combined( int node, bool got_policy ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );
  assert( job_info.combined_node );

  assert( job_info.pending_step_calls > 0 );
  --job_info.pending_step_calls;

  if( !got_policy ) {
    --job_info.total_policies;
    job_info.out_of_policy = true;
  }
}


void
MainNodeManagerImpl::finish_dump_optimizer( int node ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );

  assert( job_info.dumping_count > 1 );
  --job_info.dumping_count;
}


void
MainNodeManagerImpl::finish_dump_policies( int node ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );

  assert( job_info.dumping_count > 1 );
  --job_info.dumping_count;
}


void
MainNodeManagerImpl::finish_shutdown( int node, bool done ) {
  assert( done );
}


void
MainNodeManagerImpl::handle_failure_without_job( int node, const std::string &what ) {
  if( state(node) == NODE_SHUTTING_DOWN ) {
    // Failed to shutdown node gracefully. Throw exception to force
    // the system down, by indirectly calling MPI_Abort in main().

    log_failure( (boost::format("Failed to shutdown at node #%u. Aborting system.\n%s")
                  % node % what).str() );

    BOOST_THROW_EXCEPTION( NodeManagerShutdownError() );
  }

  if( !shutdown_ ) {
    log_failure( (boost::format("Request (%s) failed at node #%u. Stopping system.\n%s")
                  % boost::lexical_cast<std::string>(state(node)) % node % what).str() );

    shutdown_ = true;
  }
}


void
MainNodeManagerImpl::handle_failure_with_job( int node, const std::string &what ) {
  const Job::ptr_t &job = job_map_.job( node );
  JobInfo &job_info = job_map_.job_info( job );

  if( !job_info.failure ) {
    log_error( job->id,
               (boost::format("Request (%s) failed at node #%u. Stopping job.\n%s")
                % boost::lexical_cast<std::string>(state(node)) % node % what).str() );

    job_info.failure = true;
  }
}


void
MainNodeManagerImpl::handle_failure( int node, const std::string &what ) {
  switch( state(node) ) {
  case NODE_IDLE:
    BOOST_THROW_EXCEPTION( AssertionError() );
    break;

  case NODE_STARTING_LOGGING:
  case NODE_SHUTTING_DOWN:
    handle_failure_without_job( node, what );
    break;

  case NODE_INITIALIZING_OPTIMIZER:
  case NODE_INITIALIZING_SIMULATOR:
  case NODE_INITIALIZING_COMBINED:
  case NODE_GETTING_POLICY:
  case NODE_SIMULATING:
  case NODE_UPDATING:
  case NODE_STEPPING_COMBINED:
  case NODE_DUMPING_OPTIMIZER:
  case NODE_DUMPING_POLICIES:
    handle_failure_with_job( node, what );
    break;
  }
}


template< class Archive >
void
MainNodeManagerImpl::Checkpoint::serialize( Archive &ar, const unsigned int version ) {
  ar & boost::serialization::make_nvp( "job_completed"      , job_completed       );

  ar & boost::serialization::make_nvp( "total_policies"     , total_policies      );
  ar & boost::serialization::make_nvp( "checkpoint_skips"   , checkpoint_skips    );

  ar & boost::serialization::make_nvp( "optimizer_library"  , optimizer_library   );
  ar & boost::serialization::make_nvp( "optimizer_arguments", optimizer_arguments );

  ar & boost::serialization::make_nvp( "simulator_command"  , simulator_command   );
  ar & boost::serialization::make_nvp( "simulator_arguments", simulator_arguments );

  ar & boost::serialization::make_nvp( "current_map_file"   , current_map_file    );
  ar & boost::serialization::make_nvp( "current_lib_file"   , current_lib_file    );
}


void
MainNodeManagerImpl::Checkpoint::load( std::istream &in ) {
  boost::archive::xml_iarchive( in )
    >> boost::serialization::make_nvp( "checkpoint", *this );
}


void
MainNodeManagerImpl::Checkpoint::save( std::ostream &out ) {
  boost::archive::xml_oarchive( out )
    << boost::serialization::make_nvp( "checkpoint", *this );
}


void
MainNodeManagerImpl::Checkpoint::load( const std::string &file ) {
  std::ifstream in( file.c_str() );
  if( in.fail() )
    BOOST_THROW_EXCEPTION( FileReadError() << errinfo_file_name(file) );
  load( in );
}


void
MainNodeManagerImpl::Checkpoint::save( const std::string &file ) {
  std::ofstream out( file.c_str() );
  save( out );
  if( out.fail() )
    BOOST_THROW_EXCEPTION( FileWriteError() << errinfo_file_name(file) );
}


void
MainNodeManagerImpl::dump_checkpoint( const Job::ptr_t &job, bool job_completed,
                                      simcount_t total_policies, simcount_t checkpoint_skips,
                                      const std::string &current_map_file, const std::string &current_lib_file )
{
  const boost::filesystem::path &file = checkpoint_file( job );

  Checkpoint checkpoint;

  checkpoint.optimizer_library   = job->optimizer_library;
  checkpoint.optimizer_arguments = job->optimizer_arguments;
  checkpoint.simulator_command   = job->simulator_command;
  checkpoint.simulator_arguments = job->simulator_arguments;

  checkpoint.job_completed    = job_completed;
  checkpoint.total_policies   = total_policies;
  checkpoint.checkpoint_skips = checkpoint_skips;
  checkpoint.current_map_file = current_map_file;
  checkpoint.current_lib_file = current_lib_file;

  boost::filesystem::path tmp_file = File::unique_temporary( file );

  checkpoint.save( tmp_file.file_string() );

  File::rename( tmp_file, file );

  log_info( job->id,
            (boost::format("Wrote checkpoint file `%s'.") % file.file_string()).str() );
}


bool
MainNodeManagerImpl::restore_checkpoint( const Job::ptr_t &job, bool &job_completed,
                                         simcount_t &total_policies, simcount_t &checkpoint_skips,
                                         std::string &current_map_file, std::string &current_lib_file )
{
  const boost::filesystem::path &file = checkpoint_file( job );

  if( !File::exists(file) ) {
    log_info( job->id,
              (boost::format("Checkpoint file `%s' does not exist.") % file.file_string()).str() );
    return false;
  }

  Checkpoint checkpoint;
  checkpoint.load( file.file_string() );

  log_info( job->id,
            (boost::format("Read checkpoint data from file `%s'.") % file.file_string()).str() );

  if( checkpoint.optimizer_library   != job->optimizer_library   ||
      checkpoint.optimizer_arguments != job->optimizer_arguments ||
      checkpoint.simulator_command   != job->simulator_command   ||
      checkpoint.simulator_arguments != job->simulator_arguments )
  {
    BOOST_THROW_EXCEPTION( CheckpointNoMatchError() << errinfo_file_name(file.file_string()) );
  }

  job_completed    = checkpoint.job_completed;
  total_policies   = checkpoint.total_policies;
  checkpoint_skips = checkpoint.checkpoint_skips;
  current_map_file = checkpoint.current_map_file;
  current_lib_file = checkpoint.current_lib_file;

  return true;
}


boost::optional<MainNodeManagerImpl::JobState>
MainNodeManagerImpl::manage_init_optimizer( const Job::ptr_t &job, JobInfo &job_info ) {
  // Check if optimizer is ready now.

  if( job_info.optimizer_initd ) {
    if( (job_info.checkpoint_time = time(NULL)) == time_t(-1) )
      BOOST_THROW_EXCEPTION( TimeError() << errinfo_api_function("time") << errinfo_errno(errno) );

    job_info.checkpoint_sims = job_info.total_policies;

    log_info( job->id,
              "Optimizer has initialized. Starting simulation." );

    return JOB_RUNNING_NORMAL;
  }

  return boost::none;
}


boost::tuple<bool, unsigned>
MainNodeManagerImpl::distribute_policies( const Job::ptr_t &job, JobInfo &job_info, bool drop_nodes ) {
  bool sim_initializing = false;
  unsigned total_sim_queue = 0;

  // Check each simulator node: if simulator queue not full and policy
  // available, push another policy on queue; if simulator queue empty
  // and no policies available, remove node from current job (a max of
  // one node will be removed per invocation, and only if at least two
  // nodes are idling).

  typedef std::multimap<size_t, int> queues_t;
  queues_t queues;

  // Generate list of nodes that are candidates for new policies. Also
  // save current backlog size for each node. Sort nodes, according to
  // backlog size, in multimap.

  BOOST_FOREACH( int sim_node, job_map_.simulator_nodes(job) ) {
    NodeInfo &node_info = job_map_.node_info( job, sim_node );

    total_sim_queue += node_info.simulate_queue.size();

    if( !node_info.simulator_initd ) {
      sim_initializing = true;
      continue;
    }

    queues.insert( std::make_pair(node_info.simulate_queue.size(), sim_node) );
  }

  // As long as jobs are in job backlog, and nodes are available, push
  // policies to node with smallest number of policies in its backlog.

  while( !job_info.backlog.empty() ) {
    const policy_t &policy = job_info.backlog.front();

    if( queues.empty() )
      break;

    queues_t::iterator it = queues.begin();

    size_t size = it->first;
    int sim_node = it->second;

    if( !(size < (job->node_backlog + 1)) )
      break;

    NodeInfo &node_info = job_map_.node_info( job, sim_node );
    assert( node_info.simulate_queue.size() == size );

    simulate( sim_node, policy );

    node_info.simulate_queue.push( policy );
    ++total_sim_queue;

    queues.erase( it );
    assert( node_info.simulate_queue.size() == size+1 );
    queues.insert( std::make_pair(size+1, sim_node) );

    job_info.backlog.pop();
  }

  // If at least two nodes are running empty, and no more policies are
  // available right now, drop one of those nodes from the job.

  if( drop_nodes && job_info.out_of_policy
      && queues.size() >= 2 && queues.begin()->first == 0
      && (++queues.begin())->first == 0 && job_info.backlog.empty() )
  {
    int sim_node = queues.begin()->second;

    assert( state(sim_node) == NODE_IDLE );

    log_info( job->id,
	      (boost::format("Not enough policies available. Removing simulator node #%u from job.") % sim_node).str() );

    job_map_.release_node( job, sim_node );
  }

  return boost::make_tuple( sim_initializing, total_sim_queue );
}


boost::optional<MainNodeManagerImpl::JobState>
MainNodeManagerImpl::manage_running_normal( const Job::ptr_t &job, JobInfo &job_info ) {
  bool repeat_this = false;
  bool reached_max_sims = false;

  if( job->max_sims != 0 && job_info.total_policies >= job->max_sims ) {
    reached_max_sims = true;
  }

  if( !job_info.combined_node ) {
    // If no policies are available anymore, job is started. This allows
    // a new job to be created in run() below.

    if( job_info.out_of_policy )
      job_info.starting_up = false;
  }
  else {
    // Combined opt/ sim node. Job is always "started" to allow new jobs
    // to be created in run(). For combined nodes, the maximum number of
    // nodes has been reached from the beginning, anyway.

    job_info.starting_up = false;
  }

  // These variables will only be valid for job_info.combined_node equal
  // to false (they are not needed for combined opt/ sim nodes, anyway).
  bool sim_initializing = false;
  unsigned total_sim_queue = 0;

  if( !job_info.combined_node ) {
    // Distribute policies among simulator nodes. Remove nodes which are
    // idling (if no policies are available for distribution anymore).

    boost::tie(sim_initializing, total_sim_queue)
      = distribute_policies( job, job_info, true );

    // If there are still policies available in backlog and job can take
    // another node, assign available node to job; initialize simulator.

    if( !job_info.backlog.empty() && !sim_initializing && job_map_.free_node_count() != 0 &&
        (job->max_nodes == 0 || job_map_.simulator_nodes(job).size() < job->max_nodes) )
    {
      int sim_node = job_map_.get_free_node();
      assert( state(sim_node) == NODE_IDLE );

      log_info( job->id,
                (boost::format("All simulators are busy. Initializing new simulator on node #%u.") % sim_node).str() );

      init_simulator( sim_node
                    , sim_logfile(job, sim_node)
                    , job->simulator_command, job->simulator_arguments
                    );

      job_map_.assign_node( job, sim_node );
    }

    // If maximum number of nodes has been reached, job is started. This
    // allows a new job to be created in run() below.

    if( job->max_nodes != 0 && job_map_.simulator_nodes(job).size() >= job->max_nodes )
      job_info.starting_up = false;
  }
  else {
    // Combined opt/ sim node. Step only one policy at a time because we
    // don't want to miss the checkpoint condition (checked below); loop
    // this implicitly by returning the JOB_RUNNING_NORMAL state again.

    if( !reached_max_sims && !job_info.out_of_policy &&
        job_info.pending_step_calls < (job->node_backlog + 1) )
    {
      step_combined( job_map_.optimizer_node(job) );
      ++job_info.pending_step_calls;
      ++job_info.total_policies;
      repeat_this = true;
    }
  }

  // Check to see if we have reached a checkpoint. This happens either
  // when the desired number of policies (i.e., simulations) since the
  // last checkpoint has been reached or the desired number of seconds
  // since the last checkpoint has passed.

  bool reached_checkpoint = false;

  time_t current_time;
  if( (current_time = time(NULL)) == time_t(-1) )
    BOOST_THROW_EXCEPTION( TimeError() << errinfo_api_function("time") << errinfo_errno(errno) );

  if(  (job->checkpoint_sims != 0 && unsigned(job_info.total_policies - job_info.checkpoint_sims) >= job->checkpoint_sims)
    || (job->checkpoint_secs != 0 && unsigned(current_time            - job_info.checkpoint_time) >= job->checkpoint_secs)
    )
  {
    reached_checkpoint = true;
  }

  if( job->checkpoints->has() &&
      !job_info.ign_checkpoints &&
      job_info.total_policies != job_info.checkpoint_sims )
  {
    boost::optional<simcount_t> checkpoint;

    try {
      checkpoint = job->checkpoints->get();
    }
    catch( boost::exception &e ) {
      log_error( job->id,
                 (boost::format("Error in checkpoint list. Disabling (nonrecurring) checkpoints.\n%s")
                  % boost::diagnostic_information(e)).str() );
      job_info.ign_checkpoints = true;
    }

    if( checkpoint && *checkpoint == job_info.total_policies ) {
      ++job_info.checkpoint_skips;
      reached_checkpoint = true;
      job->checkpoints->inc();
    }
    else if( checkpoint && *checkpoint < job_info.total_policies ) {
      log_error( job->id,
                 (boost::format("Checkpoint list is not a strictly increasing sequence of positive numbers "
                                "(got `%u' in checkpoint list after doing %u simulations). "
                                "Disabling (nonrecurring) checkpoints.")
                  % *checkpoint % job_info.total_policies).str() );
      job_info.ign_checkpoints = true;
    }
  }

  if( !job_info.combined_node ) {
    // When not currently getting a policy and we don't know for sure we
    // are out of policies, try to get a new policy; if backlog permits,
    // and we are not doing a checkpoint next or reached the max. number
    // of simulations.

    if( !job_info.getting_policy && !job_info.out_of_policy &&
        job_info.backlog.size() < (job->job_backlog + 1) &&
        !reached_checkpoint && !reached_max_sims )
    {
      int opt_node = job_map_.optimizer_node( job );
      job_info.getting_policy = true;
      get_policy( opt_node );
    }

    // When there are no more policies available, and no simulator works
    // on any simulation right now, we have reached the end of this job.

    if( total_sim_queue == 0 &&
        (reached_max_sims || job_info.out_of_policy) &&
        job_info.backlog.empty() && job_info.update_queue.empty() )
    {
      BOOST_FOREACH( int sim_node, job_map_.simulator_nodes(job) ) {
        assert( state(sim_node) == NODE_IDLE );

        job_map_.release_node( job, sim_node );
      }

      return JOB_DUMPING_RESULT;
    }
  }
  else {
    // Combined opt/ sim node. When step_combined() returned false once,
    // and all remaining step_combined() calls have returned, we reached
    // the end the job.

    if( (reached_max_sims || job_info.out_of_policy) &&
        job_info.pending_step_calls == 0 )
    {
      return JOB_DUMPING_RESULT;
    }
  }

  // If we are to have a checkpoint, allow other jobs to start now (we
  // won't be using any more nodes while checkpointing), and go change
  // the state accordingly.

  if( reached_checkpoint && !reached_max_sims ) {
    job_info.starting_up = false;

    return JOB_DUMPING_STATES;
  }

  if( !repeat_this )
    return boost::none;
  else
    return JOB_RUNNING_NORMAL;
}


void
MainNodeManagerImpl::start_dump( const Job::ptr_t &job, JobInfo &job_info, bool job_completed ) {
  assert( job_info.dumping_count == 0 );
  job_info.dumping_count = 1;

  job_info.current_map_file.clear();
  job_info.current_lib_file.clear();

  int opt_node = job_map_.optimizer_node( job );

  boost::filesystem::path optimizer_map_file  = this->optimizer_map_file( job, job_info.total_policies );
  boost::filesystem::path optimizer_lib_file  = this->optimizer_lib_file( job, job_info.total_policies );
  boost::filesystem::path policy_bin_dumpfile = this->policy_bin_dumpfile( job, job_info.total_policies );
  boost::filesystem::path policy_txt_dumpfile = this->policy_txt_dumpfile( job, job_info.total_policies );

  if( !optimizer_map_file.empty() ) {
    optimizer_map_file = File::unique_name( optimizer_map_file );
    log_info( job->id,
              (boost::format("Writing optimizer map to `%s'.") % optimizer_map_file.file_string()).str() );
    job_info.current_map_file = optimizer_map_file.file_string();
    dump_optimizer( opt_node, optimizer_map_file, DUMP_OPTIMIZER_MAP );
    ++job_info.dumping_count;
  }

  if( !optimizer_lib_file.empty() ) {
    optimizer_lib_file = File::unique_name( optimizer_lib_file );
    log_info( job->id,
              (boost::format("Writing optimizer state to `%s'.") % optimizer_lib_file.file_string()).str() );
    job_info.current_lib_file = optimizer_lib_file.file_string();
    dump_optimizer( opt_node, optimizer_lib_file, DUMP_OPTIMIZER_LIB );
    ++job_info.dumping_count;
  }

  if( !policy_bin_dumpfile.empty() ) {
    policy_bin_dumpfile = File::unique_name( policy_bin_dumpfile );
    log_info( job->id,
              (boost::format("Writing best policy list (binary) to `%s'.") % policy_bin_dumpfile.file_string()).str() );
    dump_policies( opt_node, policy_bin_dumpfile, job->policy_count, false );
    ++job_info.dumping_count;
  }

  if( !policy_txt_dumpfile.empty() ) {
    policy_txt_dumpfile = File::unique_name( policy_txt_dumpfile );
    log_info( job->id,
              (boost::format("Writing best policy list (textual) to `%s'.") % policy_txt_dumpfile.file_string()).str() );
    dump_policies( opt_node, policy_txt_dumpfile, job->policy_count, true );
    ++job_info.dumping_count;
  }

  if( job_completed ) {
    boost::filesystem::path policy_bin_result = this->policy_bin_result( job );
    boost::filesystem::path policy_txt_result = this->policy_txt_result( job );

    if( !policy_bin_result.empty() ) {
      policy_bin_result = File::unique_name( policy_bin_result );
      log_info( job->id,
                (boost::format("Writing final best policy list (binary) to `%s'.") % policy_bin_result.file_string()).str() );
      dump_policies( opt_node, policy_bin_result, job->policy_count, false );
      ++job_info.dumping_count;
    }

    if( !policy_txt_result.empty() ) {
      policy_txt_result = File::unique_name( policy_txt_result );
      log_info( job->id,
                (boost::format("Writing final best policy list (textual) to `%s'.") % policy_txt_result.file_string()).str() );
      dump_policies( opt_node, policy_txt_result, job->policy_count, true );
      ++job_info.dumping_count;
    }
  }
}


void
MainNodeManagerImpl::finish_dump( const Job::ptr_t &job, JobInfo &job_info, bool job_completed ) {
  assert( job_info.dumping_count == 1 );
  job_info.dumping_count = 0;

  try {
    dump_checkpoint( job, job_completed,
                     job_info.total_policies, job_info.checkpoint_skips,
                     job_info.current_map_file, job_info.current_lib_file );
  }
  catch( boost::exception &e ) {
    log_error( job->id,
               (boost::format("Failed to dump checkpoint.\n%s") % diagnostic_information(e)).str() );
  }

  if( !job_completed ) {
    if( (job_info.checkpoint_time = time(NULL)) == time_t(-1) )
      BOOST_THROW_EXCEPTION( TimeError() << errinfo_api_function("time") << errinfo_errno(errno) );

    job_info.checkpoint_sims = job_info.total_policies;
  }
}


boost::optional<MainNodeManagerImpl::JobState>
MainNodeManagerImpl::manage_dumping_states( const Job::ptr_t &job, JobInfo &job_info ) {
  if( job_info.dumping_count == 0 ) {
    bool start_dumping = false;

    if( !job_info.combined_node ) {
      // Distribute policies among simulator nodes but do NOT remove nodes
      // that are idling: we will need them again once state dump has been
      // completed.

      unsigned total_sim_queue;

      boost::tie(boost::tuples::ignore, total_sim_queue)
        = distribute_policies( job, job_info, false );

      // As soon as all policies from policy backlog have been done, start
      // the dumping, according to job's config settings.

      if( total_sim_queue == 0 &&
          job_info.backlog.empty() )
      {
        start_dumping = true;
      }
    }
    else {
      // Combined opt/ sim node. As soon as no step_combined() calls are
      // active anymore, start the actual dumping.

      if( job_info.out_of_policy && job_info.pending_step_calls == 0 ) {
        // The step_combined() function returned false, i.e., we reached
        // the end of the job. Therefore this state dump isn't necessary
        // anymore and we can directly proceed to dumping the results.

        return JOB_DUMPING_RESULT;
      }
      else if( job_info.pending_step_calls == 0 )
        start_dumping = true;
    }

    if( start_dumping ) {
      log_info( job->id,
                (boost::format("Creating checkpoint after %u simulations.") % job_info.total_policies).str() );

      start_dump( job, job_info, false );
      assert( job_info.dumping_count >= 1 );
    }
  }

  // When all dump operations have finished, write checkpoint file, then
  // reset job to normal mode.

  if( job_info.dumping_count == 1 ) {
    finish_dump( job, job_info, false );
    assert( job_info.dumping_count == 0 );

    log_info( job->id,
              "Finished creating checkpoint." );

    return JOB_RUNNING_NORMAL;
  }

  return boost::none;
}


boost::optional<MainNodeManagerImpl::JobState>
MainNodeManagerImpl::manage_dumping_result( const Job::ptr_t &job, JobInfo &job_info ) {
  if( job_info.dumping_count == 0 ) {
    log_info( job->id,
              (boost::format("Reached end of job after %u simulations. Dumping results.") % job_info.total_policies).str() );

    start_dump( job, job_info, true );
    assert( job_info.dumping_count >= 1 );
  }

  // When all dump operations have finished, finish job and free node.

  if( job_info.dumping_count == 1 ) {
    finish_dump( job, job_info, true );
    assert( job_info.dumping_count == 0 );

    int opt_node = job_map_.optimizer_node( job );
    assert( state(opt_node) == NODE_IDLE );

    log_info( job->id,
              "Finished dumping results. Stopping job." );

    job_map_.finish_job( job, opt_node );

    ++jobs_done_;

    return boost::none;
  }

  return boost::none;
}


boost::optional<MainNodeManagerImpl::JobState>
MainNodeManagerImpl::manage( const Job::ptr_t &job, JobInfo &job_info ) {
  switch( job_info.state ) {
  case JOB_INIT_OPTIMIZER: return manage_init_optimizer(job, job_info); break;
  case JOB_RUNNING_NORMAL: return manage_running_normal(job, job_info); break;
  case JOB_DUMPING_STATES: return manage_dumping_states(job, job_info); break;
  case JOB_DUMPING_RESULT: return manage_dumping_result(job, job_info); break;
  }

  BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<JobState>(job_info.state) );
}


bool
MainNodeManagerImpl::create_job( const Job::ptr_t &job ) {
  boost::shared_ptr<LogFile> job_logfile( new LogFile(this->job_logfile(job)) );
  log_register_sink( job_logfile, job->job_log_level, job->id );

  log_info( job->id,
            ( boost::format("Starting job (#%u; job-%u, argument-%u) in directory `%s'."
                            "\nOptimizer command line: `%s'\nSimulator command line: `%s'")
            % job->id % job->job_set_id % job->arg_set_id % job->job_directory.file_string()
            % detail::command_line(job->optimizer_library, job->optimizer_arguments)
            % detail::command_line(job->simulator_command, job->simulator_arguments)
            ).str() );

  bool restore_job = false;

  bool job_completed;
  simcount_t total_policies;
  simcount_t checkpoint_skips;
  std::string current_map_file;
  std::string current_lib_file;

  bool got_checkpoint;

  try {
    got_checkpoint = restore_checkpoint( job, job_completed,
                                         total_policies, checkpoint_skips,
                                         current_map_file, current_lib_file );
  }
  catch( boost::exception &e ) {
    log_error( job->id,
               (boost::format("Failed to restore checkpoint. Skipping job.\n%s") % diagnostic_information(e)).str() );
    return false;
  }

  if( got_checkpoint ) {
    if( job_completed ) {
      log_info( job->id,
                "Job has checkpoint; has already completed. Skipping job." );
      ++jobs_done_;
      return false;
    }

    // Check if we actually have a dumpfile: dumping the optimizer state
    // might have been disabled at the time the checkpoint was taken.

    if( !current_map_file.empty() && !current_lib_file.empty() ) {
      restore_job = true;
    }
  }

  if( restore_job ) {
    log_info( job->id,
              (boost::format("Job has checkpoint; continuing job with %u simulations done.") % total_policies).str() );
  }
  else {
    log_info( job->id,
              "Job has no checkpoints; beginning job from scratch." );
  }

  const bool create_combined = job->max_nodes == 1;

  int opt_node = job_map_.get_free_node();
  assert( state(opt_node) == NODE_IDLE );

  if( !create_combined ) {
    // Use regular optimizer node.

    log_info( job->id,
              (boost::format("Initializing optimizer on node #%u.") % opt_node).str() );

    init_optimizer( opt_node
                  , opt_logfile(job, opt_node)
                  , sim_logfile(job, opt_node)
                  , job->optimizer_library, job->optimizer_arguments
                  , job->simulator_command, job->simulator_arguments
                  , (restore_job ? boost::optional<boost::filesystem::path>(current_map_file) : boost::none)
                  , (restore_job ? boost::optional<boost::filesystem::path>(current_lib_file) : boost::none)
                  );
  }
  else {
    // Use combined opt/ sim node.

    log_info( job->id,
              (boost::format("Initializing combined optimizer/simulator on node #%u.") % opt_node).str() );

    init_combined( opt_node
                 , opt_logfile(job, opt_node)
                 , sim_logfile(job, opt_node)
                 , job->optimizer_library, job->optimizer_arguments
                 , job->simulator_command, job->simulator_arguments
                 , (restore_job ? boost::optional<boost::filesystem::path>(current_map_file) : boost::none)
                 , (restore_job ? boost::optional<boost::filesystem::path>(current_lib_file) : boost::none)
                 );
  }

  job_map_.create_job( job, opt_node );

  JobInfo &job_info = job_map_.job_info( job );
  job_info.job_logfile = job_logfile;

  if( !create_combined ) {
    int sim_node = job_map_.get_free_node();
    assert( state(sim_node) == NODE_IDLE );

    log_info( job->id,
              (boost::format("Initializing simulator on node #%u.") % sim_node).str() );

    init_simulator( sim_node
                  , sim_logfile(job, sim_node)
                  , job->simulator_command, job->simulator_arguments
                  );

    job_map_.assign_node( job, sim_node );
  }
  else
    job_info.combined_node = true;

  if( restore_job ) {
    job_info.total_policies = total_policies;
    job_info.checkpoint_skips = checkpoint_skips;

    for( simcount_t i = 0; i < job_info.checkpoint_skips && job->checkpoints->has(); ++i ) {
      job->checkpoints->inc();
    }
  }

  return true;
}


void
MainNodeManagerImpl::remove_job( const Job::ptr_t &job, JobInfo &job_info ) {
  BOOST_FOREACH( int sim_node, job_map_.simulator_nodes(job) ) {
    if( state(sim_node) == NODE_IDLE )
      job_map_.release_node( job, sim_node );
  }

  int opt_node = job_map_.optimizer_node( job );

  if( state(opt_node) == NODE_IDLE &&
      job_map_.simulator_nodes(job).empty() )
  {
    job_map_.finish_job( job, opt_node );
  }
}


void
MainNodeManagerImpl::run() {
  StatsEntry se_running( *this, "running", 50 );

  // Wait for start_logging() to complete.

  while( process() );

  // Main loop: process job state machines.

  do {
    StatsEntry se_scheduling( *this, "scheduling", 50 );

    if( shutdown_ ) {
      // Shutting down: process and finish only remaining jobs.

      BOOST_FOREACH( const Job::ptr_t &job, job_map_.jobs() ) {
        JobInfo &job_info = job_map_.job_info( job );

        // Handle cleaning-up of job.
        remove_job( job, job_info );
      }

      continue;
    }

    bool starting_up = false;

    BOOST_FOREACH( const Job::ptr_t &job, job_map_.jobs() ) {
      JobInfo &job_info = job_map_.job_info( job );

      if( job_info.failure ) {
        // Handle cleaning-up of job.
        remove_job( job, job_info );
        continue;
      }

      boost::optional<JobState> new_state;
      while( (new_state = manage(job, job_info)) )
        job_info.state = *new_state;

      if( job_info.starting_up )
        starting_up = true;
    }

    while( !starting_up && !job_queue_->empty() &&
           job_map_.free_node_count() >= (job_queue_->front()->max_nodes == 1 ? 1 : 2) )
    {
      Job::ptr_t job = job_queue_->front();
      job_queue_->pop();

      if( create_job(job) ) {
        starting_up = true;
        break;
      }
    }
  } while( process() );

  se_running.stop();
  StatsEntry se_shutting_down( *this, "shutting down", 100 );

  // In case not all jobs finished successfully, log error message.

  assert( job_queue_->empty() || jobs_done_ != job_queue_->total_jobs() );

  if( jobs_done_ != job_queue_->total_jobs() ) {
    log_error( (boost::format("Failed to run all jobs from job queue.\n"
                              "Only %u jobs out of %u completed successfully." )
                % jobs_done_ % job_queue_->total_jobs()).str() );
  }
  else {
    log_info( (boost::format("Successfully completed all %u jobs from job queue.")
               % jobs_done_).str() );
  }

  // Give all nodes the signal to shutdown gracefully. Should this
  // fail, handle_failure() will throw an exception, forcing the
  // system down.

  for( int node = min_child(); node <= max_child(); ++node )
    shutdown( node );

  while( process() );

  // Output final statistics.

  log_statistics();
}

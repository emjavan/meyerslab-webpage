#ifndef DICON_JOB_MAP_HPP_
#define DICON_JOB_MAP_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief JobMap class.
 */
#include "job.hpp"
#include <boost/noncopyable.hpp>
#include <deque>
#include <map>
#include <set>


/**
 * @brief Mapping of jobs to processing nodes.
 *
 * The templated  JobMap class provides the mapping  between jobs (Job
 * structure) and  processing nodes (@c  int representing the  node in
 * the  corresponding  MPI communicator  context),  in  the main  node
 * manager.  It allows to associate processing nodes with jobs, either
 * as  %optimizer  or   simulator  nodes,  and  provides  user-defined
 * additional structures  per job (and  thus per %optimizer  node) and
 * per  simulator node  associated with  a  job.  The  types of  these
 * user-defined structures are given  by @c JobInfoT and @c NodeInfoT,
 * respectively.
 *
 * Each job, when it is  currently active in the system, is associated
 * with  exactly  one %optimizer  node,  and  an  arbitrary number  of
 * simulator nodes  (only limited  by the number  of nodes in  the MPI
 * communicator), though typically each job has at least one simulator
 * node    (the   only   exceptions    being   jobs    with   combined
 * %optimizer/simulator nodes, and jobs that have already finished and
 * are only dumping results).
 *
 * The JobMap  class provides  methods to  look up the  job a  node is
 * currently  associated  with,  and  get  appropriate  job  and  node
 * information for  a job or node.  It also keeps track  of nodes that
 * have been registered but are not associated with any job.
 *
 * Any node in the job map must  be associated with at most one job at
 * any time (i.e., nodes may not share a job). As jobs (Job structure)
 * are typically  shared by the  means of smart pointers,  equality of
 * jobs is compared in terms of pointer equality, i.e., only identical
 * job objects are considered equal.  In particular, the job ID is not
 * used when comparing jobs.
 *
 * @tparam JobInfoT  Type of additional structure per  active job (and
 *   thus per %optimizer node).
 * @tparam NodeInfoT  Type of additional structure  per each simulator
 *   node associated with job.
 *
 * @see MainNodeManager, MainNodeManagerImpl.
 */
template< typename JobInfoT, typename NodeInfoT >
class JobMap
  : boost::noncopyable
{
public:
  /**
   * @brief Register processing node.
   *
   * Register  the processing  node  given  by @e  node  with the  job
   * map. This method  must be called before any  of the other methods
   * accept the given node as a parameter.
   *
   * @param node Node in the MPI communicator context.
   * @throws AssertionError when node is already registered.
   */
  void register_node( int node );

  /**
   * @brief Create new job.
   *
   * Create new job  given by @e job with %optimizer  node given by @e
   * optimizer_node.  The  job must not be active,  and the %optimizer
   * node must not be registered with any other job, when calling this
   * method.
   *
   * A new object of the  user-defined job structure given by template
   * argument  @e JobInfoT  is default-constructed  when  calling this
   * method.
   *
   * @param job %Job.
   * @param optimizer_node %Optimizer node.
   * @throws AssertionError when %optimizer  node is not registered or
   *   already assigned to another job, or job is already active.
   */
  void create_job( const Job::ptr_t &job, int optimizer_node );
  /**
   * @brief Assign simulator node to job.
   *
   * Assign simulator node given by  @e simulator_node to job given by
   * @e job. The  job must be active, and the  simulator node must not
   * be associated with any other job, when calling this method.
   *
   * A new object of the user-defined node structure given by template
   * argument  @e NodeInfoT is  default-constructed when  calling this
   * method.
   *
   * @param job %Job.
   * @param simulator_node %Simulator node.
   * @throws AssertionError  when simulator node is  not registered or
   *   already assigned to another job, or job is not active.
   */
  void assign_node( const Job::ptr_t &job, int simulator_node );

  /**
   * @brief Finish active job.
   *
   * Finish  the job  given by  @e  job and  @e optimizer_node.   This
   * removes the  job from the job  map, so that it  is not considered
   * active anymore. Any simulator  nodes associated with the job must
   * be removed with release_node()  prior to calling this method. The
   * %optimizer  node will  be returned  to the  pool  of unassociated
   * nodes.
   *
   * @param job %Job.
   * @param optimizer_node %Optimizer node.
   * @throws AssertionError when %optimizer  node is not registered or
   *   is not  the %optimizer node  associated with the given  job, or
   *   the  job  is  not  active  or has  any  simulator  nodes  still
   *   assigned.
   */
  void finish_job( const Job::ptr_t &job, int optimizer_node );
  /**
   * @brief Release simulator node from job.
   *
   * Release the  simulator node given  by @e simulator_node  from the
   * job given by @e job. This returns the given simulator node to the
   * pool of unassociated nodes.
   *
   * @param job %Job.
   * @param simulator_node %Simulator node.
   * @throws AssertionError  when simulator node is  not registered or
   *   is not an associated simulator  node with the given job, or the
   *   job is not active.
   */
  void release_node( const Job::ptr_t &job, int simulator_node );

public:
  /**
   * @brief Get free node count.
   *
   * Get the  number of currently  unassociated nodes in the  job map.
   * This is  equivalent to the number of  nodes previously registered
   * with  register_node(),  minus  the  number  of  registered  nodes
   * currently  associated  with  a   job  (either  as  %optimizer  or
   * simulator nodes).
   *
   * @returns Number of unassociated nodes.
   */
  unsigned free_node_count() const;
  /**
   * @brief Get unassociated node.
   *
   * Get an unassociated node from  the job map. This returns the node
   * number  (@c int representing  the node  in the  corresponding MPI
   * communicator context) of an unassociated  node in the job map. If
   * no such node is available, this call fails.
   *
   * @note This method does not remove the returned node from the pool
   * of unassociated nodes.  Therefore, two consecutive invocations of
   * this method are allowed to return the same node.
   *
   * @returns Unassociated node.
   * @throws AssertionError when no unassociated node is available.
   *
   * @see free_node_count().
   */
  int get_free_node() const;

  /**
   * @brief Get active jobs.
   *
   * Get the list of jobs currently  active in the system. This is the
   * list of all jobs previously created with create_job() and not yet
   * removed with finish_job().
   *
   * @returns List of active jobs.
   */
  std::vector<Job::ptr_t> jobs() const;

  /**
   * @brief Get job associated with node.
   *
   * Get  the job  currently  associated  with the  node  given by  @e
   * node.  If this node  does not  have a  job associated,  this call
   * fails.
   *
   * @param node Node.
   * @returns %Job associated with node.
   * @throws AssertionError when the node  is not registered or has no
   *   job associated.
   */
  Job::ptr_t job( int node ) const;

public:
  /**
   * @brief Get %optimizer node of job.
   *
   * Get the %optimizer  node of the job given by @e  job. If this job
   * is not active, this call fails.
   *
   * @param job %Job.
   * @returns %Optimizer node associated with job.
   * @throws AssertionError when job is not active.
   */
  int optimizer_node( const Job::ptr_t &job ) const;
  /**
   * @brief Get simulator nodes of job.
   *
   * Get the  list of simulator nodes of  the job given by  @e job. If
   * this job is not active, this call fails.
   *
   * @param job %Job.
   * @returns List of simulator nodes associated with job.
   * @throws AssertionError when job is not active.
   */
  std::vector<int> simulator_nodes( const Job::ptr_t &job ) const;

public:
  /// Get user-defined job structure.
  const JobInfoT &job_info( const Job::ptr_t &job ) const;
  /**
   * @brief Get user-defined job structure.
   *
   * Get the  user-defined structure for the  job given by  @e job. If
   * this job is not active, this call fails.
   *
   * @param job %Job.
   * @returns User-defined job structure.
   * @throws AssertionError when job is not active.
   */
  JobInfoT &job_info( const Job::ptr_t &job );

  /// Get user-defined node structure.
  const NodeInfoT &node_info( const Job::ptr_t &job, int simulator_node ) const;
  /**
   * @brief Get user-defined node structure.
   *
   * Get the user-defined structure for the simulator node given by @e
   * simulator_node associated with  the job given by @e  job. If this
   * job  is  not active,  or  the given  node  not  a simulator  node
   * associated with the job, this call fails.
   *
   * @param job %Job.
   * @param simulator_node %Simulator node.
   * @returns User-defined node structure.
   * @throws AssertionError when simulator  node is not registered, or
   *   is not a  simulator node associated with the  given job, or job
   *   is not active.
   */
  NodeInfoT &node_info( const Job::ptr_t &job, int simulator_node );

private:
  struct NodeInfo {
    NodeInfoT node_info;
  };

  typedef std::map<int, NodeInfo> simulator_nodes_t;

  struct JobInfo {
    simulator_nodes_t simulator_nodes;
    int optimizer_node;
    JobInfoT job_info;
  };

  typedef std::map<int, Job::ptr_t> nodes_t;
  nodes_t nodes_;

  typedef std::map<Job::ptr_t, JobInfo> jobs_t;
  jobs_t jobs_;
};


#include "job_map.ipp"

#endif //DICON_JOB_MAP_HPP_

#ifndef DICON_SLAVEDRIVER_HPP_
#define DICON_SLAVEDRIVER_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Slavedriver class.
 */
#include "file.hpp"
#include <boost/filesystem/path.hpp>
#include <boost/noncopyable.hpp>
#include <boost/optional.hpp>
#include <boost/scoped_ptr.hpp>
#include <string>
#include <vector>


/// Errinfo storing the child's process ID.
DICON_ERRINFO( slave_pid, pid_t );


/// %Slavedriver related error.
struct SlavedriverError : virtual Error
{ virtual const char *what() const throw() { return "Slavedriver related error."; } };

/// Failed to execute given query.
struct SlavedriverExecuteError : virtual SlavedriverError
{ virtual const char *what() const throw() { return "Failed to execute given query."; } };


class Communicator;

/**
 * @brief Running child process.
 *
 * The Slavedriver class implements running a child process. It offers
 * methods to  communicate with the  process using standard  input and
 * output  using  the  simple   %message  protocol  described  in  the
 * documentation of the Communicator  class. If the child process dies
 * unexpectedly  during  a  query,  i.e.,  without  returning  a  full
 * response,  it   is  automatically  restarted   until  communication
 * succeeds or the given retry limit is reached.
 *
 * In addition, the child's output to standard error can be redirected
 * to a logfile. If the  logfile given on construction already exists,
 * it will not be overwritten, but instead a new, unused filename will
 * be chosen  by the means  of File::unique().  This will  be repeated
 * whenever the child process has  to be restarted (using the original
 * filename given on construction as a template), so that old logfiles
 * from previous runs are never lost.
 */
class Slavedriver
  : boost::noncopyable
{
public:
  /// @showinitializer
  /// Default number of retries on execute().
  static const unsigned default_retries = 2;

public:
  /**
   * @brief Create slavedriver.
   *
   * Constructor that  creates a new slavedriver. This  does not spawn
   * the child process until execute() is called.
   *
   * @param logfile Logfile to used for child's standard error output.
   * @param command Command of child process to execute.
   * @param arguments Command-line arguments.
   */
  Slavedriver( const boost::filesystem::path &logfile,
               const std::string &command, const std::vector<std::string> &arguments );
  /**
   * @brief Kill slavedriver.
   *
   * Destructor  that  destroy the  slavedriver  and  kills any  child
   * process that is still running.  When killing a child process, the
   * slavedriver will  first send the  hang-up signal (SIGHUP)  to the
   * process.  If  it still  exists after 5  seconds, the  kill signal
   * (SIGKILL) will be sent, ultimately killing the process.
   */
  ~Slavedriver();

public:
  /**
   * @brief Reset child process.
   *
   * Reset the child process. If a child process is currently running,
   * it  will be  killed as  described in  ~Slavedriver(). If  a child
   * process does not exist, this call does nothing.
   */
  void reset();
  /**
   * @brief Reset child process with new arguments.
   *
   * Reset the child process,  changing the command-line arguments. If
   * a  child process  is  currently  running, it  will  be killed  as
   * described  in  ~Slavedriver(). When  the  child  process is  next
   * started, the new command-line arguments will be used.
   *
   * @param arguments New command-line arguments.
   */
  void reset( const std::vector<std::string> &arguments );
  /**
   * @brief Reset child process with new command and arguments.
   *
   * Reset the child process, changing both the command to execute and
   * the  command-line  arguments. If  a  child  process is  currently
   * running, it  will be killed as described  in ~Slavedriver(). When
   * the  child   process  is  next  started,  the   new  command  and
   * command-line arguments will be used.
   *
   * @param command New command of child process to execute.
   * @param arguments New command-line arguments.
   */
  void reset( const std::string &command, const std::vector<std::string> &arguments );

protected:
  /**
   * @brief Run query on child.
   *
   * Run the given query on the child process, using the communication
   * protocol  described in  the  Communicator class,  on the  child's
   * standard input  and standard output.   If a child process  is not
   * running,  it will be  started with  the command  and command-line
   * arguments specified  in the constructor  or as given at  the last
   * call of either @link reset(const std::vector<std::string> &) reset(vector<string>)@endlink
   * or @link reset(const std::string &, const std::vector<std::string> &) reset(string, vector<string>)@endlink.
   *
   * In  case the  child process  dies unexpectedly  before  sending a
   * complete answer to the  query, it will be automatically restarted
   * up to @e retries times.
   *
   * @param query Query to send.
   * @param retries Number of retries.
   * @returns Child's answer to given query.
   *
   * @throws  SlavedriverExecuteError when  querying  child ultimately
   *   failed.
   */
  std::string execute( const std::string &query, unsigned retries = default_retries );

  /**
   * @brief Run query on child.
   *
   * Run  the  given query  on  the  child  process.  This  method  is
   * equivalent to the non-templated  execute() method, except that it
   * uses the  Google Protocol Buffer library to  serialize the object
   * @e question and then sends  this serialized version of the object
   * to  the   child  process.   Similarly,  the   child's  answer  is
   * deserialized  using  the   Google  Protocol  Buffer  library  and
   * returned in @e answer.
   *
   * @note This  uses the @e  SerializeToOstream(std::ostream*) method
   *   on  @e  question,  and the  @e  ParseFromIstream(std::istream*)
   *   method on  @e answer.  Any  objects that can provide  these two
   *   methods can be used here.
   */
  template< typename Q, typename A >
  void execute( const Q &question, A &answer, unsigned retries = default_retries );

private:
  boost::optional<File> logfile();

  void check_child();
  void kill_child();
  void run_child();

private:
  boost::filesystem::path logfile_;

  mutable pid_t child_;

  std::string command_;
  std::vector<std::string> arguments_;

  boost::scoped_ptr<Communicator> communicator_;
};


#include "slavedriver.ipp"

#endif //DICON_SLAVEDRIVER_HPP_

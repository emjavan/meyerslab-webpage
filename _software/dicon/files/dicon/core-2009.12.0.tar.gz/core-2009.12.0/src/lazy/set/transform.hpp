#ifndef DICON_LAZY_SET_TRANSFORM_HPP_
#define DICON_LAZY_SET_TRANSFORM_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyTransform class.
 */
#include "../set.hpp"
#include <boost/noncopyable.hpp>
#include <functional>


/**
 * @brief Transform lazy set.
 *
 * The LazyTransform class implements  the transformation of the given
 * lazy  set. Thus,  it contains  exactly the  values returned  by the
 * application of the given functor  to all elements from the original
 * set.
 *
 * The functor  of type  @e Op must  be compatible with  the following
 * function type signature: <code>T(const S &)</code>.
 *
 * @tparam Op Functor to apply.
 * @tparam T Value type of this set.
 * @tparam S Value type of original set.
 */
template< typename Op
        , typename T = typename Op::result_type
        , typename S = typename Op::argument_type
        >
class LazyTransform
  : boost::noncopyable, public LazySet<T>
{
public:
  /**
   * @brief Create lazy transformation set.
   *
   * Constructor that creates the  lazy set that is the transformation
   * of the  lazy set given by  @e x.  The resulting  set contains the
   * results from the application of the functor given by @e op to the
   * values from set @e x.
   *
   * The  resulting  set contains  exactly  as  many  elements as  the
   * original set given  by @e x. Therefore, it is  finite if and only
   * if the original set @e x is finite.
   *
   * In order  to fulfill  the lazy set  interface, the functor  @e op
   * must return the  same value each time it is  called with the same
   * argument.
   *
   * @param x Original set.
   * @param op Functor to apply.
   */
  LazyTransform( typename LazySet<S>::ptr_t &x, const Op &op = Op() );

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();

private:
  const typename LazySet<S>::ptr_t x_;
  const Op op_;
};


/**
 * @brief Create lazy transformation set.
 *
 * Create lazy transformation set as described in the documentation of
 * the LazyTransform  class. This templated helper  function returns a
 * smart pointer to the newly created set.
 *
 * @param x Original set.
 * @param op Functor to apply.
 * @returns Pointer to new lazy set.
 */
template< typename Op, typename S >
typename LazySet<typename Op::result_type>::ptr_t lazy_transform( S x, const Op &op );


#include "transform.ipp"

#endif //DICON_LAZY_SET_TRANSFORM_HPP_

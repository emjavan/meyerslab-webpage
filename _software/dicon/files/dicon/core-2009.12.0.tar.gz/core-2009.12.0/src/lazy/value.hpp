#ifndef DICON_LAZY_VALUE_HPP_
#define DICON_LAZY_VALUE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyValue interface.
 */
#include <map>
#include <memory>
#include <set>
#include <string>


/**
 * @brief Lazy value.
 *
 * The templated LazyValue class provides the interface to an abstract
 * lazy value. Such  a value can be evaluated at  any time providing a
 * specific  variable assignment. It  also provides  means to  get the
 * list of variables that are actually used by the lazy value.
 *
 * The lazy value  interface requires the lazy value  to be immutable,
 * i.e., when evaluating it with the same variable assignment again at
 * a later time, it has to evaluate to the same value.
 *
 * Due  to the  nature  of an  abstract  base class,  lazy values  are
 * typically  referenced to by  pointer.  The  pointer class  used and
 * defined   by   @link    LazyValue::ptr_t   ptr_t@endlink   is   the
 * std::auto_ptr pointer.   This allows for the efficient  use of lazy
 * values, e.g.,  as constructor arguments  as used in several  of the
 * implementations  (such as LazyBinaryOp,  and LazyUnaryOp)  while at
 * the same time avoiding memory leaks.
 *
 * Variable names  are always treated case-sensitive,  i.e., an actual
 * comparison  for equality  is  performed by  the  @c string  class's
 * <code>operator=()</code>  method.   There   is  no  restriction  on
 * variable names,  i.e., even  the empty string  is a  valid variable
 * name.
 *
 * For  each lazy  value  implementation (LazyBinaryOp,  LazyConstant,
 * LazyUnaryOp, or  LazyVariable), there is  a corresponding templated
 * global   helper    function   (lazy_binary_op(),   lazy_constant(),
 * lazy_unary_op(), or lazy_variable()) to  create a new lazy value of
 * that type  and return a smart  pointer to it. In  most cases, these
 * helper functions can be  automatically instantiated by the compiler
 * as  to  avoid  the  necessity  of  explicitly  specifying  template
 * arguments. The following code demonstrates this.
 *
 * @code
LazyValue<int>::ptr_t value = lazy_binary_op( lazy_constant(42)
                                            , lazy_binary_op( lazy_variable<int>("x")
                                                            , lazy_variable<int>("y")
                                                            , std::plus<int>()
                                                            )
                                            , std::minus<int>()
                                            );
@endcode
 *
 * Notice how neither  lazy_binary_op() nor lazy_constant() required a
 * template argument: the lazy  values' type was automatically deduced
 * from the functions' arguments.   Also, the helper functions allowed
 * for the  exception-safe immediate use of the  resulting lazy values
 * as arguments to other lazy value constructors and helper functions.
 */
template< typename T >
class LazyValue {
public:
  /// Value type.
  typedef T value_t;
  /// Pointer to lazy value.
  typedef std::auto_ptr<LazyValue> ptr_t;
  /// Set of variable names.
  typedef std::set<std::string> references_t;
  /// Variable assignment.
  typedef std::map<std::string, T> variables_t;

public:
  virtual ~LazyValue() {}

public:
  /**
   * @brief Get list of references.
   *
   * Get  the  list  of  variables  actually referenced  by  the  lazy
   * value. This method must always return the same set since the lazy
   * value interface  requires lazy values  to be immutable.   See the
   * description of the LazyValue class for details.
   *
   * @returns List of references.
   */
  virtual references_t references() const = 0;

public:
  /**
   * @brief Evaluate lazy value.
   *
   * Evaluate the  lazy value, using the variable  assignment given by
   * @e variables. This method must  always return the same value when
   * called  with the same  variable assignment  since the  lazy value
   * interface  requires  lazy  values   to  be  immutable.   See  the
   * description of the LazyValue class for details.
   *
   * @param variables Variables assignment.
   * @returns Evaluated lazy value.
   */
  virtual T operator()( const variables_t &variables ) const = 0;
};


namespace detail {

  template< typename T >
  struct LazyValuePtr {
    typedef typename T::element_type::value_t value_t;
    typedef typename LazyValue<value_t>::ptr_t ptr_t;
  };

}

#endif //DICON_LAZY_VALUE_HPP_

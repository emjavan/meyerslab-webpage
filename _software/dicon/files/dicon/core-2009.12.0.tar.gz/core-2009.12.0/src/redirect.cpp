/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "redirect.hpp"
#include "error.hpp"


Redirector::Redirector( int old_file, int new_file )
  : new_file_(new_file)
{
  if( (pre_file_ = dup(new_file_)) == -1 ) {
    BOOST_THROW_EXCEPTION( RedirectorError() << errinfo_api_function("dup")
                           << errinfo_errno(errno) << errinfo_file_descriptor(new_file_) );
  }

  try {
    if( dup2(old_file, new_file_) == -1 ) {
      BOOST_THROW_EXCEPTION( RedirectorError() << errinfo_api_function("dup2") << errinfo_errno(errno)
                             << errinfo_file_descriptor(old_file) << errinfo_file_descriptor_2(new_file_) );
    }
  }
  catch( ... ) {
    restore();
    throw;
  }
}


Redirector::~Redirector() {
  restore();
}


void
Redirector::restore() {
  // Restore previous file desc.
  dup2( pre_file_, new_file_ );
  // Remove backup file desc.
  close( pre_file_ );
}

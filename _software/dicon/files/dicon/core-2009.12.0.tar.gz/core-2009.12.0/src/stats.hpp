#ifndef DICON_STATS_HPP_
#define DICON_STATS_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Statistics class.
 */
#include <boost/noncopyable.hpp>
#include <boost/optional.hpp>
#include <map>
#include <ostream>
#include <stdint.h>
#include <sys/time.h>
#include <vector>


class StatsEntry;

/**
 * @brief Collect time statistics.
 *
 * The Statistics class collects time statistics showing how much time
 * the program spent in a certain  state or function.  This works in a
 * hierarchical way:  at each point  that an object of  the Statistics
 * class exists, a scope can  be defined by instantiating an object of
 * the  StatsEntry class,  referring  to the  Statistics object.   The
 * Statistics  object then  keeps track  of  the wall  clock time  the
 * program ran while the StatsEntry object was still alive.
 *
 * This can be demonstrated as follows.
 *
 * @code
static Statistics statistics;

void function_a() {
  StatsEntry entry( statistics, "function_a()" );
  // Do some work here, taking some time.
}

void function_b() {
  StatsEntry entry( statistics, "function_b()" );
  // Do some work here, taking some time.
  // Call function_a() also.
}

int main() {
  StatsEntry entry( statistics, "main()" );
  // Do some work here, taking some time.
  // Call function_a() and function_b().
  statistics.print( std::cout );
}
@endcode
 *
 * This might result in an output like the following.
 *
 * @verbatim
name                         ticks    %/rel    %/tot           total time
(total)                          0    100.0    100.0      0 days 00:00:35
   main()                        1    100.0    100.0      0 days 00:00:35
      function_a()               1     28.6     28.6      0 days 00:00:10
      function_b()               1     42.9     42.9      0 days 00:00:15
         function_a()            1     66.7     28.6      0 days 00:00:10
@endverbatim
 *
 * As can be seen in this example, the sum of all children need not be
 * equal to the  total time spent in any given  node in the statistics
 * tree.  For this  reason, an additional parameter can  be given when
 * creating an object of  the StatsEntry class, creating an additional
 * virtual node that appears to be active whenever no other child node
 * exists.  If this  were used in the example  above, the output might
 * have looked like the following.
 *
 * @verbatim
name                         ticks    %/rel    %/tot           total time
(total)                          0    100.0    100.0      0 days 00:00:35
   main()                        1    100.0    100.0      0 days 00:00:35
      (rest)                     0     28.6     28.6      0 days 00:00:10
      function_a()               1     28.6     28.6      0 days 00:00:10
         (rest)                  0    100.0     28.6      0 days 00:00:10
      function_b()               1     42.9     42.9      0 days 00:00:15
         (rest)                  0     33.3     14.3      0 days 00:00:05
         function_a()            1     66.7     28.6      0 days 00:00:10
            (rest)               0    100.0     28.6      0 days 00:00:10
@endverbatim
 */
class Statistics
  : boost::noncopyable
{
  friend class StatsEntry;

public:
  /**
   * @brief Initialize statistics.
   *
   * Constructor  that  initializes a  new  statistics counter.   This
   * starts  the  internal  clock  of  the new  Statistics  object  as
   * described in the description of the Statistics class.
   *
   * @throws TimeError when getting current time failed.
   */
  Statistics();

public:
  /**
   * @brief Output statistics.
   *
   * Output  the  collected  time   statistics  to  the  given  output
   * stream. The  format might  look similar to  the one shown  in the
   * description of the Statistics class,  with lines for each node in
   * the statistics tree.
   *
   * The statistics object's internal state  is kept frozen as long as
   * the  output  has  not  fully  completed.  This  ensures  that  no
   * incoherent state  is created. For this reason,  this method might
   * throw an exception of type TimeError.
   *
   * @param output Output stream.
   * @throws TimeError when freezing or resuming statistics failed.
   */
  void print( std::ostream &output );

protected:
  /**
   * @brief Push node onto tree.
   *
   * Push  another  node onto  the  statistics  tree,  at the  current
   * position given by  previous calls to push() and  pop(), or at the
   * root node if no such call has been made so far. If the node (with
   * name  given  by @e  what)  does not  exist  it  will be  created,
   * otherwise the node's existing data will be updated.
   *
   * The  priority (given by  @e priority)  can be  used to  define an
   * order in which  this node will be arranged  relative to the other
   * child nodes of its parent node, when printing the statistics with
   * print(). If more than one  child has the same priority, they will
   * be arranged in the lexicographical order of the names given by @e
   * what.
   *
   * If  parameter @e  idle  is  non-empty, an  idle  node is  created
   * whenever  the   new  node  has  no  active   children.   This  is
   * demonstrated  by the  examples given  in the  description  of the
   * Statistics class. This idle node  can have its own priority given
   * by @e idle_priority.
   *
   * @param what Node name.
   * @param priority Node priority.
   * @param idle Idle node name.
   * @param idle_priority Idle node priority.
   *
   * @throws TimeError when getting current time failed.
   */
  void push( const std::string &what, int priority = 0,
             const std::string &idle = std::string(), int idle_priority = 0 );
  /**
   * @brief Pop node from tree.
   *
   * Pop the current node from the statistics tree. If the parent node
   * had an  idle node defined,  it will automatically be  pushed onto
   * the tree in place of the current node.
   *
   * @throws TimeError when getting current time failed.
   */
  void pop();

private:
  void push_( const std::pair<int, std::string> &entry, bool tick );
  void pop_();

private:
  class TimeRecord {
  public:
    TimeRecord();
  public:
    void start( bool tick = false );
    void stop();
  public:
    double time() const;
    uint64_t ticks() const;
  private:
    bool running_;
    uint64_t ticks_;
    double total_time_;
    timeval last_start_;
  };

private:
  typedef std::vector<std::pair<int, std::string> > path_t;
  typedef std::map<path_t, TimeRecord> records_t;

  records_t records_;
  path_t current_;
  path_t idlers_;
};


/**
 * @brief %Statistics helper.
 *
 * The StatsEntry  class pushes  a new node  onto the  statistics tree
 * defined  by  the  Statistics  object  given  on  construction,  and
 * automatically  pops this  node on  destruction, as  defined  in the
 * documentation of the Statistics class.
 */
class StatsEntry
  : boost::noncopyable
{
public:
  /**
   * @brief Push node onto tree.
   *
   * Constructor  that pushes  another node  onto the  statistics tree
   * defined by the Statistics object given as @e stats, as defined in
   * the documentation of the Statistics::push() method.
   *
   * @param stats Statistics object.
   * @param what Node name.
   * @param priority Node priority.
   * @param idle Idle node name.
   * @param idle_priority Idle node priority.
   *
   * @throws TimeError when getting current time failed.
   */
  StatsEntry( Statistics &stats, const std::string &what, int priority = 0,
              const std::string &idle = std::string(), int idle_priority = 0 );
  /**
   * @brief Pop node from tree.
   *
   * Destructor that  pops the current  node from the  statistics tree
   * defined  by  the  Statistics  object given  on  construction,  as
   * defined in the documentation of the Statistics::pop() method.
   */
  ~StatsEntry();

public:
  /**
   * @brief Stop entry.
   *
   * Stop  the current statistics  entry. This  pops the  current node
   * from the  statistics tree defined by the  Statistics object given
   * on  construction,   as  defined  in  the   documentation  of  the
   * Statistics::pop() method, while also preventing the destructor of
   * the StatsEntry from  doing so. Thus, calling this  method has the
   * same effect as actually destroying the object. This can be useful
   * in situations like the one in the following example.
   *
   * @code
StatsEntry entry_a( "entry_a()" );
// Do some time consuming task.
entry_a.stop();

StatsEntry entry_b( "entry_b()" );
// Do some time consuming task.
entry_b.stop();
@endcode
   *
   * Using  the stop() method  in this  case allowed  every StatsEntry
   * object to remain  in the same scope, freeing  the programmer from
   * the need  of actually  creating a new  scope for  each StatsEntry
   * object used.
   *
   * @throws TimeError when getting current time failed.
   */
  void stop();

private:
  bool stopped_;
  Statistics &stats_;
};

#endif //DICON_STATS_HPP_

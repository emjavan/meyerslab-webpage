#ifndef DICON_JOB_HPP_
#define DICON_JOB_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Job structure.
 */
#include "lazy/set.hpp"
#include "message.hpp"
#include <boost/filesystem/path.hpp>
#include <boost/shared_ptr.hpp>


/**
 * @brief %Job descriptor.
 *
 * The Job  structure holds the main information  associated with each
 * job.  This information  is normally  not copied  but  rather passed
 * around  by  the  means  of   a  smart  pointer,  as  referenced  by
 * Job::ptr_t.
 */
struct Job {
  /// Pointer to Job structure.
  typedef boost::shared_ptr<Job> ptr_t;

  /// Unique ID of job (>= 1).
  job_id_t id;

  /// Number of job set job belongs to (>= 1).
  size_t job_set_id;
  /// Number of argument set within job set job belongs to (>= 1).
  size_t arg_set_id;

  /// Maximum allowed number of simulator nodes (0 = unlimited).
  unsigned max_nodes;
  /// Maximum allowed number of simulations (0 = unlimited).
  simcount_t max_sims;
  /// Size of job backlog queue.
  unsigned job_backlog;
  /// Size of node backlog queue, per node.
  unsigned node_backlog;

  /// Maximum number of seconds between checkpoints (0 = disabled).
  unsigned checkpoint_secs;
  /// Maximum number of simulations between checkpoints (0 = disabled).
  unsigned checkpoint_sims;
  /// Pointer to lazy set containing absolute simulation counts for checkpoint.
  boost::shared_ptr<LazySet<simcount_t> > checkpoints;

  /// Path to job directory.
  boost::filesystem::path job_directory;

  /// Path to job logfile within job directory.
  boost::filesystem::path job_logfile;
  /// Log level to use for job logfile.
  LogLevel job_log_level;
  /// Path to checkpoint file within job directory.
  boost::filesystem::path checkpoint_file;
  /// @c printf mask (with <code>\%u</code>: node number) for optimizer logfile within job directory.
  std::string opt_logfile_mask;
  /// @c printf mask (with <code>\%u</code>: node number) for simulator logfile within job directory.
  std::string sim_logfile_mask;

  /// @c printf mask (with <code>\%u</code>: simulation count) for optimizer map dumpfile within job directory.
  std::string optimizer_map_file_mask;
  /// @c printf mask (with <code>\%u</code>: simulation count) for optimizer lib dumpfile within job directory.
  std::string optimizer_lib_file_mask;
  /// @c printf mask (with <code>\%u</code>: simulation count) for binary policy file within job directory.
  std::string policy_bin_dumpfile_mask;
  /// @c printf mask (with <code>\%u</code>: simulation count) for textual policy file within job directory.
  std::string policy_txt_dumpfile_mask;

  /// Number of policies to output in policy files.
  unsigned policy_count;
  /// Path to binary policy result file within job directory.
  boost::filesystem::path policy_bin_result;
  /// Path to textual policy result file within job directory.
  boost::filesystem::path policy_txt_result;

  /// Path to optimizer library.
  std::string optimizer_library;
  /// Arguments to optimizer library.
  arguments_t optimizer_arguments;

  /// Path to simulator command.
  std::string simulator_command;
  /// Arguments to simulator command.
  arguments_t simulator_arguments;
};

#endif //DICON_JOB_HPP_

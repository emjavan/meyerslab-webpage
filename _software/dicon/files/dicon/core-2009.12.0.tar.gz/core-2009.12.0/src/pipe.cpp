/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "pipe.hpp"
#include "file.hpp"
#include <cerrno>


Pipe::Pipe() {
  if( pipe(pipefd_) != 0 )
    BOOST_THROW_EXCEPTION( PipeError() << errinfo_api_function("pipe") << errinfo_errno(errno) );

  owned_[0] = true;
  owned_[1] = true;
}


Pipe::~Pipe() {
  if( owned_[0] ) close(pipefd_[0]);
  if( owned_[1] ) close(pipefd_[1]);
}


int
Pipe::read_end() const {
  if( !owned_[0] ) {
    BOOST_THROW_EXCEPTION( FileNotOwnedError()
                           << errinfo_file_descriptor(pipefd_[0]) );
  }

  return pipefd_[0];
}


int
Pipe::write_end() const {
  if( !owned_[1] ) {
    BOOST_THROW_EXCEPTION( FileNotOwnedError()
                           << errinfo_file_descriptor(pipefd_[1]) );
  }

  return pipefd_[1];
}


int
Pipe::read_end( bool take_ownership ) {
  if( !owned_[0] ) {
    BOOST_THROW_EXCEPTION( FileNotOwnedError()
                           << errinfo_file_descriptor(pipefd_[0]) );
  }

  if( take_ownership )
    owned_[0] = false;

  return pipefd_[0];
}


int
Pipe::write_end( bool take_ownership ) {
  if( !owned_[1] ) {
    BOOST_THROW_EXCEPTION( FileNotOwnedError()
                           << errinfo_file_descriptor(pipefd_[1]) );
  }

  if( take_ownership )
    owned_[1] = false;

  return pipefd_[1];
}

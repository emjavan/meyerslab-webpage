#ifndef DICON_MANAGER_MAIN_IMPL_HPP_
#define DICON_MANAGER_MAIN_IMPL_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief MainNodeManagerImpl class.
 */
#include "config.hpp"
#include "error.hpp"
#include "job_map.hpp"
#include "job_queue.hpp"
#include "log.hpp"
#include "manager_main.hpp"
#include <boost/shared_ptr.hpp>
#include <boost/tuple/tuple.hpp>


/// Checkpoint related error.
struct CheckpointError : virtual Error
{ virtual const char *what() const throw() { return "Checkpoint related error."; } };

/// Checkpoint file does not match job.
struct CheckpointNoMatchError : virtual CheckpointError
{ virtual const char *what() const throw() { return "Checkpoint file does not match job."; } };


/**
 * @brief Main node manager implementation.
 *
 * The MainNodeManagerImpl  class implements the  node manager running
 * on the main node in  the computing cluster.  Specifically, it reads
 * in and parses the  main configuration file (using the Configuration
 * and JobQueue  classes), and processes  each job defined  therein by
 * repeatedly   spawning    optimizers,   simulators,   and   combined
 * %optimizer/simulators  on the  processing nodes  in the  cluster as
 * required, and  managing the communication among  these nodes, i.e.,
 * it  passes along policies  from the  optimizers to  the simulators,
 * collects  resulting  reward  values,  dumps  %optimizer  states  to
 * checkpoint  files,  and  writes  out  the final  result  from  each
 * individual job  (using the  methods defined in  the MainNodeManager
 * interface).
 *
 * As defined in  the NodeManager interface, the main  node manager is
 * run by calling the run() method.
 */
class MainNodeManagerImpl
  : public MainNodeManager
{
  friend class NodeManager;

protected:
  /**
   * @brief Create main node manager.
   *
   * Constructor that creates a  new node manager. This constructor is
   * protected since objects of the MainNodeManagerImpl class are only
   * to be  costructed through the  static @link NodeManager::create()
   * create()@endlink method of the NodeManager class.
   *
   * @param world MPI communicator.
   */
  MainNodeManagerImpl( boost::mpi::communicator &world );

protected:
  virtual void finish_start_logging ( int node                                          );
  virtual void finish_init_optimizer( int node                                          );
  virtual void finish_init_simulator( int node                                          );
  virtual void finish_init_combined ( int node                                          );
  virtual void finish_get_policy    ( int node, const boost::optional<policy_t> &policy );
  virtual void finish_simulate      ( int node, double reward                           );
  virtual void finish_update        ( int node                                          );
  virtual void finish_step_combined ( int node, bool got_policy                         );
  virtual void finish_dump_optimizer( int node                                          );
  virtual void finish_dump_policies ( int node                                          );
  virtual void finish_shutdown      ( int node, bool done                               );

  virtual void handle_failure       ( int node, const std::string &what                 );

public:
  /**
   * @brief Run main node manager.
   *
   * Run  the  main  node   manager.   This  method  handles  all  the
   * communication  between  the  processing  nodes in  the  computing
   * cluster  as  necessary  in  order to  achieve  the  functionality
   * outlined in the description of the MainNodeManagerImpl class.
   *
   * This method should only be called once during the lifetime of the
   * MainNodeManagerImpl object.
   *
   * @throws NodeManagerShutdownError when  shutting down a processing
   *   node gracefully failed.
   */
  virtual void run();

private:
  void handle_failure_without_job   ( int node, const std::string &what                 );
  void handle_failure_with_job      ( int node, const std::string &what                 );

private:
  boost::filesystem::path job_logfile( const Job::ptr_t &job );
  boost::filesystem::path checkpoint_file( const Job::ptr_t &job );
  boost::filesystem::path opt_logfile( const Job::ptr_t &job, int node );
  boost::filesystem::path sim_logfile( const Job::ptr_t &job, int node );
  boost::filesystem::path optimizer_map_file( const Job::ptr_t &job, simcount_t simulation );
  boost::filesystem::path optimizer_lib_file( const Job::ptr_t &job, simcount_t simulation );
  boost::filesystem::path policy_bin_dumpfile( const Job::ptr_t &job, simcount_t simulation );
  boost::filesystem::path policy_txt_dumpfile( const Job::ptr_t &job, simcount_t simulation );
  boost::filesystem::path policy_bin_result( const Job::ptr_t &job );
  boost::filesystem::path policy_txt_result( const Job::ptr_t &job );

private:
  enum JobState
  { JOB_INIT_OPTIMIZER
  , JOB_RUNNING_NORMAL
  , JOB_DUMPING_STATES
  , JOB_DUMPING_RESULT
  };

  struct JobInfo {
    JobInfo();

    JobState state;
    bool combined_node;

    bool optimizer_initd;
    bool ign_checkpoints;
    bool getting_policy;                // [R]
    bool out_of_policy;
    bool starting_up;
    bool failure;

    unsigned dumping_count;
    simcount_t total_policies;
    simcount_t checkpoint_skips;
    unsigned pending_step_calls;        // [C]

    time_t checkpoint_time;
    simcount_t checkpoint_sims;

    std::string current_map_file;
    std::string current_lib_file;

    std::queue<policy_t> backlog;       // [R]
    std::queue<policy_t> update_queue;  // [R]

    boost::shared_ptr<LogFile> job_logfile;
  };

  struct NodeInfo {
    NodeInfo();

    bool simulator_initd;

    std::queue<policy_t> simulate_queue;
  };

  struct Checkpoint {
    bool job_completed;

    simcount_t total_policies;
    simcount_t checkpoint_skips;

    std::string optimizer_library;
    arguments_t optimizer_arguments;

    std::string simulator_command;
    arguments_t simulator_arguments;

    std::string current_map_file;
    std::string current_lib_file;

    void load( std::istream &in );
    void save( std::ostream &out );

    void load( const std::string &file );
    void save( const std::string &file );

    template< class Archive >
    void serialize( Archive &ar, const unsigned int version );
  };

private:
  void dump_checkpoint( const Job::ptr_t &job, bool job_completed,
                        simcount_t total_policies, simcount_t checkpoint_skips,
                        const std::string &current_map_file, const std::string &current_lib_file );

  bool restore_checkpoint( const Job::ptr_t &job, bool &job_completed,
                           simcount_t &total_policies, simcount_t &checkpoint_skips,
                           std::string &current_map_file, std::string &current_lib_file );

  bool create_job( const Job::ptr_t &job );
  void remove_job( const Job::ptr_t &job, JobInfo &job_info );

  void start_dump( const Job::ptr_t &job, JobInfo &job_info, bool job_completed );
  void finish_dump( const Job::ptr_t &job, JobInfo &job_info, bool job_completed );

  boost::tuple<bool, unsigned>
  distribute_policies( const Job::ptr_t &job, JobInfo &job_info, bool drop_nodes );

  boost::optional<JobState> manage_init_optimizer( const Job::ptr_t &job, JobInfo &job_info );
  boost::optional<JobState> manage_running_normal( const Job::ptr_t &job, JobInfo &job_info );
  boost::optional<JobState> manage_dumping_states( const Job::ptr_t &job, JobInfo &job_info );
  boost::optional<JobState> manage_dumping_result( const Job::ptr_t &job, JobInfo &job_info );
  boost::optional<JobState> manage( const Job::ptr_t &job, JobInfo &job_info );

private:
  bool shutdown_;
  size_t jobs_done_;

  Configuration config_;
  JobMap<JobInfo, NodeInfo> job_map_;
  boost::shared_ptr<LogFile> log_file_;
  boost::shared_ptr<JobQueue> job_queue_;
};

#endif //DICON_MANAGER_MAIN_IMPL_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "manager_proc.hpp"
#include "log.hpp"
#include <boost/format.hpp>
#include <boost/mpi/communicator.hpp>


namespace detail {

  static const size_t isend_queue_size = 10;

}



namespace detail {

  class QuestionDispatcher
    : public boost::static_visitor<message::Answer>
  {
  public:
    QuestionDispatcher( ProcNodeManager &manager );

  public:
    message::Answer operator()( const message::question::StartLogging  &data ) const;
    message::Answer operator()( const message::question::InitOptimizer &data ) const;
    message::Answer operator()( const message::question::InitSimulator &data ) const;
    message::Answer operator()( const message::question::InitCombined  &data ) const;
    message::Answer operator()( const message::question::GetPolicy     &data ) const;
    message::Answer operator()( const message::question::Simulate      &data ) const;
    message::Answer operator()( const message::question::Update        &data ) const;
    message::Answer operator()( const message::question::StepCombined  &data ) const;
    message::Answer operator()( const message::question::DumpOptimizer &data ) const;
    message::Answer operator()( const message::question::DumpPolicies  &data ) const;
    message::Answer operator()( const message::question::Shutdown      &data ) const;

  private:
    ProcNodeManager &manager_;
  };

}



namespace detail {

  template< typename A >
  static
  message::Answer
  make_answer( const A &answer ) {
    message::Answer res;
    res.data = answer;
    return res;
  }


  static
  message::Answer
  make_failure( const std::string &what ) {
    message::answer::Failure failure;
    failure.what = what;

    return make_answer( failure );
  }


  static
  inline
  void
  log_debug( const std::string &what ) throw() {
    try {
      ::log_debug( what );
    }
    catch( ... ) {
      // Ignore.
    }
  }


  class LogDebug
    : boost::noncopyable
  {
  public:
    LogDebug( const std::string &what )
      : what_(what)
    {
      log_debug(             what_ + "()" );
    }

    ~LogDebug() {
      log_debug( "finish_" + what_ + "()" );
    }

  private:
    std::string what_;
  };


  QuestionDispatcher::QuestionDispatcher( ProcNodeManager &manager )
    : manager_(manager)
  {
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::StartLogging &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "start_logging()", 10 );
    LogDebug log_debug( "start_logging" );

    message::answer::StartLogging answer;

    manager_.start_logging( data.logfile, data.min_level );

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::InitOptimizer &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "init_optimizer()", 20 );
    LogDebug log_debug( "init_optimizer" );

    message::answer::InitOptimizer answer;

    manager_.init_optimizer( data.optimizer_logfile, data.simulator_logfile,
                             data.optimizer_library, data.optimizer_arguments,
                             data.simulator_command, data.simulator_arguments,
                             data.optimizer_map_file, data.optimizer_lib_file );

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::InitSimulator &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "init_simulator()", 30 );
    LogDebug log_debug( "init_simulator" );

    message::answer::InitSimulator answer;

    manager_.init_simulator( data.simulator_logfile,
                             data.simulator_command, data.simulator_arguments );

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::InitCombined &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "init_combined()", 40 );
    LogDebug log_debug( "init_combined" );

    message::answer::InitCombined answer;

    manager_.init_combined( data.optimizer_logfile, data.simulator_logfile,
                            data.optimizer_library, data.optimizer_arguments,
                            data.simulator_command, data.simulator_arguments,
                            data.optimizer_map_file, data.optimizer_lib_file );

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::GetPolicy &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "get_policy()", 50 );
    LogDebug log_debug( "get_policy" );

    message::answer::GetPolicy answer;

    answer.policy = manager_.get_policy();

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::Simulate &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "simulate()", 60 );
    LogDebug log_debug( "simulate" );

    message::answer::Simulate answer;

    answer.reward = manager_.simulate( data.policy );

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::Update &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "update()", 70 );
    LogDebug log_debug( "update" );

    message::answer::Update answer;

    manager_.update( data.policy, data.reward );

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::StepCombined &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "step_combined()", 80 );
    LogDebug log_debug( "step_combined" );

    message::answer::StepCombined answer;

    answer.got_policy = manager_.step_combined();

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::DumpOptimizer &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "dump_optimizer()", 90 );
    LogDebug log_debug( "dump_optimizer" );

    message::answer::DumpOptimizer answer;

    manager_.dump_optimizer( data.file, data.mode );

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::DumpPolicies &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "dump_policies()", 100 );
    LogDebug log_debug( "dump_policies" );

    message::answer::DumpPolicies answer;

    manager_.dump_policies( data.file, data.count, data.display );

    return make_answer( answer );
  }


  message::Answer
  QuestionDispatcher::operator()( const message::question::Shutdown &data ) const {
    ProcNodeManager::StatsEntry se( manager_, "shutdown()", 110 );
    LogDebug log_debug( "shutdown" );

    message::answer::Shutdown answer;

    answer.done = manager_.shutdown();

    if( answer.done )
      manager_.shutdown_ = true;

    return make_answer( answer );
  }

}



ProcNodeManager::ProcNodeManager( boost::mpi::communicator &world )
  : NodeManager(world), shutdown_(false), current_tag_(min_tag())
{
  StatsEntry se( *this, "starting up", 0 );
}


ProcNodeManager::~ProcNodeManager() {
  assert( isend_queue_.empty() );
}


void
ProcNodeManager::process() {
  StatsEntry se( *this, "processing", 0, "(idle)", 0 );

  assert( isend_queue_.size() <= detail::isend_queue_size );
  if( isend_queue_.size() == detail::isend_queue_size ) {
    assert( !isend_queue_.empty() );
    isend_queue_.front().wait();
    isend_queue_.pop_front();
  }

  const unsigned tag = next_tag(current_tag_);

  message::Question question;

  world().recv( 0, tag, question );

  boost::optional<message::Answer> answer;

  try {
    answer = boost::apply_visitor( detail::QuestionDispatcher(*this), question.data );
  }
#if BOOST_VERSION >= 103900
  catch( ... ) {
    const std::string &info = boost::current_exception_diagnostic_information();
    log_error( (boost::format("Failed to process request.\n%s") % info).str() );
    answer = detail::make_failure( info );
  }
#else
  catch( boost::exception &e ) {
    const std::string &info = boost::diagnostic_information( e );
    log_error( (boost::format("Failed to process request.\n%s") % info).str() );
    answer = detail::make_failure( info );
  }
  catch( ... ) {
    const std::string &info = "<unknown exception>\n";
    log_error( (boost::format("Failed to process request.\n%s") % info).str() );
    answer = detail::make_failure( info );
  }
#endif

  isend_queue_.push_back( world().isend(0, tag, answer.get()) );
}


void
ProcNodeManager::run() {
  StatsEntry se_running( *this, "running", 50 );

  while( !shutdown_ ) {
    process();
  }

  se_running.stop();
  StatsEntry se_shutting_down( *this, "shutting down", 0 );

  while( !isend_queue_.empty() ) {
    isend_queue_.front().wait();
    isend_queue_.pop_front();
  }

  // Output final statistics.

  log_statistics();
}

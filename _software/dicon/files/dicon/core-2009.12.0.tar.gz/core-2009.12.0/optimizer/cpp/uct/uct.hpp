#ifndef DICON_CPP_UCT_UCT_HPP_
#define DICON_CPP_UCT_UCT_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "../optimizer.hpp"
#include <boost/variant.hpp>
#include <boost/serialization/map.hpp>
#include <boost/serialization/vector.hpp>


class UCT
  : public Optimizer
{
public:
  UCT( const std::string &name,
       const optimizer::arguments_t &arguments,
       const boost::optional<std::string> &state_file );

protected:
  virtual boost::optional<optimizer::policy_t> get_policy();
  virtual void update( const optimizer::policy_t &policy, double reward );
  virtual policies_result_type policies( unsigned count );
  virtual void dump_state( const std::string &filename );

private:
  void load_state( std::istream &in );
  void save_state( std::ostream &out );

public:
  struct Node;

  typedef std::map<optimizer::node_t, Node> tree_t;

  struct Node {
    Node();

    bool is_leaf;
    double reward;
    unsigned count;
    tree_t children;
  };

private:
  struct Data {
    Node root_node;
    std::vector<Node *> current_path;
  };

  Data data;
};


BOOST_SERIALIZATION_SPLIT_FREE( UCT::Data )

namespace boost {
  namespace serialization {

    template< class Archive >
    void save( Archive &ar, const UCT::Data &data, const unsigned int version );

    template< class Archive >
    void load( Archive &ar, UCT::Data &data, const unsigned int version );

  }
}


namespace boost {
  namespace serialization {

    template< class Archive >
    void serialize( Archive &ar, UCT::Node &node, const unsigned int version );

  }
}


#include "uct.ipp"

#endif //DICON_CPP_UCT_UCT_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "exhaustive.hpp"
#include <boost/archive/binary_iarchive.hpp>
#include <boost/archive/binary_oarchive.hpp>
#include <boost/foreach.hpp>
#include <boost/lexical_cast.hpp>
#include <fstream>
#include <limits>


static const size_t default_max_best_policies = 10;


ExhaustiveSearch::ExhaustiveSearch( const std::string &name,
                                    const optimizer::arguments_t &arguments,
                                    const boost::optional<std::string> &state_file )
{
  if( !state_file ) {
    // Initialize new optimizer.
    data.queue.push_back( optimizer::policy_t() );
    data.max_best_policies = default_max_best_policies;

    if( !arguments.empty() ) {
      if( arguments.size() == 2 && arguments[0] == "-n" )
        data.max_best_policies = boost::lexical_cast<size_t>( arguments[1] );
      else if( arguments.size() == 1 && arguments[0].substr(0, 2) == "-n" )
        data.max_best_policies = boost::lexical_cast<size_t>( arguments[0].substr(2) );
      else
        throw OptimizerError( "ExhaustiveSearch::ExhaustiveSearch(): Failed to parse arguments." );
    }
  }
  else {
    // Resume: get state from given file.
    std::ifstream in( state_file->c_str() );
    load_state( in );
    if( in.fail() )
      throw OptimizerError( "ExhaustiveSearch::ExhaustiveSearch(): Failed to read state file." );
  }
}


boost::optional<optimizer::policy_t>
ExhaustiveSearch::get_policy() {
  while( true ) {
    if( data.queue.empty() )
      return boost::none;

    optimizer::policy_t path = data.queue.back();
    data.queue.pop_back();

    const optimizer::policy_t &list = children( path );

    if( list.empty() ) {
      // Reached leaf.
      return path;
    }
    else {
      for( optimizer::policy_t::const_reverse_iterator it = list.rbegin(); it != list.rend(); ++it ) {
        optimizer::policy_t new_path = path;
        new_path.push_back( *it );
        data.queue.push_back( new_path );
      }
    }
  }
}


void
ExhaustiveSearch::update( const optimizer::policy_t &policy, double reward ) {
  data.best_policies.insert( std::make_pair(reward, policy) );

  if( data.best_policies.size() > data.max_best_policies ) {
    assert( !data.best_policies.empty() );
    data.best_policies.erase( data.best_policies.begin() );
  }
}


ExhaustiveSearch::policies_result_type
ExhaustiveSearch::policies( unsigned count ) {
  policies_result_type result;

  for( best_policies_t::const_reverse_iterator it = data.best_policies.rbegin(); it != data.best_policies.rend(); ++it ) {
    result.push_back( policies_result_type::value_type(it->second, it->first) );
  }

  return result;
}


void
ExhaustiveSearch::dump_state( const std::string &filename ) {
  std::ofstream out( filename.c_str() );
  save_state( out );
  if( out.fail() )
    throw OptimizerError( "ExhaustiveSearch::dump_state(): Failed to write to file." );
}


void
ExhaustiveSearch::load_state( std::istream &in ) {
  boost::archive::binary_iarchive( in )
    >> boost::serialization::make_nvp( "data", data );
}


void
ExhaustiveSearch::save_state( std::ostream &out ) {
  boost::archive::binary_oarchive( out )
    << boost::serialization::make_nvp( "data", data );
}

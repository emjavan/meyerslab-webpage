#ifndef DICON_MESSAGE_HPP_
#define DICON_MESSAGE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Node intercommunication.
 *
 * The  message.hpp file  provides the  structures necessary  for node
 * intercommunication   between   the   main   node   (MainNodeManager
 * interface,  MainNodeManagerImpl  class)  and the  processing  nodes
 * (ProcNodeManager   interface,   ProcNodeManagerImpl  class).    The
 * following messages are defined.
 *
 * - @c  start_logging(): Start  logging to  the given  file  with the
 *   given minimum log level.
 * - @c  init_optimizer():  Initialize  %optimizer instance  with  the
 *   given %optimizer  library and arguments, and  the given simulator
 *   command  and   arguments,  using  the  given   logfiles  for  the
 *   %optimizer  and  simulator;  optionally restoring  an  %optimizer
 *   state from the  given map and lib dumpfiles.   This will shutdown
 *   any other %optimizer, simulator, or combined %optimizer/simulator
 *   running at the target node.
 * - @c init_simulator(): Initialize simulator instance with the given
 *   simulator command and arguments,  using the given logfile for the
 *   simulator. This will shutdown any other %optimizer, simulator, or
 *   combined %optimizer/simulator running at the target node.
 * - @c  init_combined():   Initialize  combined  %optimizer/simulator
 *   instance with the given %optimizer library and arguments, and the
 *   given simulator  command and arguments, using  the given logfiles
 *   for  the  %optimizer   and  simulator;  optionally  restoring  an
 *   %optimizer state from the given map and lib dumpfiles.  This will
 *   shutdown   any   other   %optimizer,   simulator,   or   combined
 *   %optimizer/simulator running at the target node.
 * - @c get_policy():  Get next policy  from %optimizer, or  a special
 *   value indicating that no policy is available until @c update() is
 *   called at least once. This call is only valid after an %optimizer
 *   (@c init_optimizer()) has been initialized on the target node.
 * - @c simulate(): Simulate the given policy. This call is only valid
 *   after a  simulator (@c init_simulator()) has  been initialized on
 *   the target node.
 * - @c update():  Update the reward  for the given policy  which must
 *   have been  returned by the target  node on a previous  call to @c
 *   get_policy().  This  call is only  valid after an  %optimizer (@c
 *   init_optimizer()) has been initialized on the target node.
 * - @c step_combined(): Do another  step, i.e., get policy, simulate,
 *   and  update.    This  call  is   only  valid  after   a  combined
 *   %optimizer/simulator (@c init_combined()) has been initialized on
 *   the target node.
 * - @c dump_optimizer():  Dump current %optimizer state  to the given
 *   file (either map or lib state).  This call is only valid after an
 *   %optimizer (@c init_optimizer()) or combined %optimizer/simulator
 *   (@c init_combined()) has been initialized on the target node.
 * - @c dump_policies(): Dump list of  best policies to the given file
 *   (either  binary or  textual). This  call is  only valid  after an
 *   %optimizer (@c init_optimizer()) or combined %optimizer/simulator
 *   (@c init_combined()) has been initialized on the target node.
 * - @c shutdown():  Shutdown the node.  After this  %message has been
 *   confirmed,  no more messages  are processed  at the  target node.
 *   Also, logging to a file (@c start_logging()) will be stopped.
 *
 * The   @c   dump_optimizer()  %message   defines   two  dump   modes
 * (DumpOptimizerMode enum), used for dumping different aspects of the
 * %optimizer state:
 *
 * - DUMP_OPTIMIZER_MAP: Dump of the one-to-one correspondence between
 *   policies as returned by the simulator's @c children() method, and
 *   the @c int values handed over to the optimization algorithm.
 * - DUMP_OPTIMIZER_LIB:  Dump   of  the  %optimizer's   own  internal
 *   state. This data belongs  to the optimization algorithm alone and
 *   can have an arbitrary format.
 *
 * To each  %message defined  above there is  a corresponding  pair of
 * structures in the message::question and message::answer namespaces.
 * The  corresponding methods  in the  MainNodeManager  interface send
 * serialized  question  objects  that the  ProcNodeManager  interface
 * receives.    After  calling   the  corresponding   method   in  the
 * ProcNodeManagerImpl class,  an answer object is sent  back and will
 * be handled  by calling a  corresponding <code>finish_</code> method
 * in the MainNodeManagerImpl class.
 *
 * @note The target  node will never overwrite a  logfile that already
 *   exists.   If  the filename  of  a logfile  given  in  any of  the
 *   messages    @c   start_logging(),    @c    init_optimizer(),   @c
 *   init_simulator(),  or @c  init_combined()  indicates an  existing
 *   file, the  target node will choose  another name by  the means of
 *   File::unique().  This  behavior is used  exclusively for logfiles
 *   and is @e  not applied to dump files,  as in @c dump_optimizer(),
 *   or @c dump_policies(): with  these messages, the target node will
 *   @e  always  use the  given  filename,  overwriting  any files  as
 *   necessary.
 */
#include "types.hpp"
#include <boost/filesystem/path.hpp>
#include <boost/serialization/optional.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/variant.hpp>
#include <boost/serialization/vector.hpp>


/// Dump mode used for @c dump_optimizer() %message.
enum DumpOptimizerMode
{ DUMP_OPTIMIZER_MAP
, DUMP_OPTIMIZER_LIB
};

/// Node intercommunication messages.
namespace message {
  /// Messages from main node to processing node.
  namespace question {

    /**
     * Message @c start_logging().
     * @see message.hpp.
     */
    struct StartLogging {
      /// Logfile to start logging to.
      boost::filesystem::path logfile;
      /// Minimum log level for file.
      LogLevel min_level;
    };

    /**
     * Message @c init_optimizer().
     * @see message.hpp.
     */
    struct InitOptimizer {
      /// Logfile to use for logging %optimizer error output.
      boost::filesystem::path optimizer_logfile;
      /// Filename of the %optimizer library.
      std::string optimizer_library;
      /// %Optimizer library arguments.
      arguments_t optimizer_arguments;
      /// %Optimizer map dumpfile to restore.
      boost::optional<boost::filesystem::path> optimizer_map_file;
      /// %Optimizer lib dumpfile to restore.
      boost::optional<boost::filesystem::path> optimizer_lib_file;

      /// Logfile to use for logging simulator error output.
      boost::filesystem::path simulator_logfile;
      /// Filename of the simulator command.
      std::string simulator_command;
      /// %Simulator command arguments.
      arguments_t simulator_arguments;
    };

    /**
     * Message @c init_simulator().
     * @see message.hpp.
     */
    struct InitSimulator {
      /// Logfile to use for logging simulator error output.
      boost::filesystem::path simulator_logfile;
      /// Filename of the simulator command.
      std::string simulator_command;
      /// %Simulator command arguments.
      arguments_t simulator_arguments;
    };

    /**
     * Message @c init_combined().
     * @see message.hpp.
     */
    struct InitCombined {
      /// Logfile to use for logging %optimizer error output.
      boost::filesystem::path optimizer_logfile;
      /// Filename of the %optimizer library.
      std::string optimizer_library;
      /// %Optimizer library arguments.
      arguments_t optimizer_arguments;
      /// %Optimizer map dumpfile to restore.
      boost::optional<boost::filesystem::path> optimizer_map_file;
      /// %Optimizer lib dumpfile to restore.
      boost::optional<boost::filesystem::path> optimizer_lib_file;

      /// Logfile to use for logging simulator error output.
      boost::filesystem::path simulator_logfile;
      /// Filename of the simulator command.
      std::string simulator_command;
      /// %Simulator command arguments.
      arguments_t simulator_arguments;
    };

    /**
     * Message @c get_policy().
     * @see message.hpp.
     */
    struct GetPolicy {
    };

    /**
     * Message @c simulate().
     * @see message.hpp.
     */
    struct Simulate {
      /// Policy to simulate.
      policy_t policy;
    };

    /**
     * Message @c update().
     * @see message.hpp.
     */
    struct Update {
      /// Simulated policy.
      policy_t policy;
      /// Policy's reward.
      double reward;
    };

    /**
     * Message @c step_combined().
     * @see message.hpp.
     */
    struct StepCombined {
    };

    /**
     * Message @c dump_optimizer().
     * @see message.hpp.
     */
    struct DumpOptimizer {
      /// Filename of %optimizer dump file.
      boost::filesystem::path file;
      /// Dump mode to use for file.
      DumpOptimizerMode mode;
    };

    /**
     * Message @c dump_policies().
     * @see message.hpp.
     */
    struct DumpPolicies {
      /// Filename of policy list file.
      boost::filesystem::path file;
      /// Maximum number of policies.
      unsigned count;
      /// Use textual display for policies?
      bool display;
    };

    /**
     * Message @c shutdown().
     * @see message.hpp.
     */
    struct Shutdown {
    };

  }
}


namespace message {
  /// Messages from processing node to main node.
  namespace answer {

    /**
     * Message @c start_logging().
     * @see message.hpp.
     */
    struct StartLogging {
    };

    /**
     * Message @c init_optimizer().
     * @see message.hpp.
     */
    struct InitOptimizer {
    };

    /**
     * Message @c init_simulator().
     * @see message.hpp.
     */
    struct InitSimulator {
    };

    /**
     * Message @c init_combined().
     * @see message.hpp.
     */
    struct InitCombined {
    };

    /**
     * Message @c get_policy().
     * @see message.hpp.
     */
    struct GetPolicy {
      /// Policy.
      boost::optional<policy_t> policy;
    };

    /**
     * Message @c simulate().
     * @see message.hpp.
     */
    struct Simulate {
      /// Reward.
      double reward;
    };

    /**
     * Message @c update().
     * @see message.hpp.
     */
    struct Update {
    };

    /**
     * Message @c step_combined().
     * @see message.hpp.
     */
    struct StepCombined {
      /// Policy was available?
      bool got_policy;
    };

    /**
     * Message @c dump_optimizer().
     * @see message.hpp.
     */
    struct DumpOptimizer {
    };

    /**
     * Message @c dump_policies().
     * @see message.hpp.
     */
    struct DumpPolicies {
    };

    /**
     * Message @c shutdown().
     * @see message.hpp.
     */
    struct Shutdown {
      /// Node was shutdown?
      bool done;
    };

    /**
     * %Failure.
     * @see message.hpp.
     */
    struct Failure {
      /// Description of error.
      std::string what;
    };

  }
}


namespace message {

  // Order of different %message types has to be the same for Question
  // and Answer: we have  to use boost::variant::which() on those data
  // attributes.

  // Main node -> processing node.
  struct Question {
    boost::variant< question::StartLogging
                  , question::InitOptimizer
                  , question::InitSimulator
                  , question::InitCombined
                  , question::GetPolicy
                  , question::Simulate
                  , question::Update
                  , question::StepCombined
                  , question::DumpOptimizer
                  , question::DumpPolicies
                  , question::Shutdown
                  > data;
  };

  // Processing node -> main node.
  struct Answer {
    boost::variant< answer::StartLogging
                  , answer::InitOptimizer
                  , answer::InitSimulator
                  , answer::InitCombined
                  , answer::GetPolicy
                  , answer::Simulate
                  , answer::Update
                  , answer::StepCombined
                  , answer::DumpOptimizer
                  , answer::DumpPolicies
                  , answer::Shutdown
                  , answer::Failure
                  > data;
  };

}


BOOST_SERIALIZATION_SPLIT_FREE( boost::filesystem::path )

namespace boost {
  namespace serialization {

    template< class Archive >
    void save( Archive &ar, const boost::filesystem::path &path, const unsigned int version );

    template< class Archive >
    void load( Archive &ar, boost::filesystem::path &path, const unsigned int version );

  }
}


namespace boost {
  namespace serialization {

    template< class Archive >
    void serialize( Archive &ar, message::Question &question, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::StartLogging &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::InitOptimizer &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::InitSimulator &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::InitCombined &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::GetPolicy &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::Simulate &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::Update &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::StepCombined &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::DumpOptimizer &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::DumpPolicies &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::question::Shutdown &data, const unsigned int version );

  }
}


namespace boost {
  namespace serialization {

    template< class Archive >
    void serialize( Archive &ar, message::Answer &answer, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::StartLogging &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::InitOptimizer &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::InitSimulator &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::InitCombined &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::GetPolicy &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::Simulate &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::Update &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::StepCombined &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::DumpOptimizer &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::DumpPolicies &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::Shutdown &data, const unsigned int version );

    template< class Archive >
    void serialize( Archive &ar, message::answer::Failure &data, const unsigned int version );

  }
}


#include "message.ipp"

#endif //DICON_MESSAGE_HPP_

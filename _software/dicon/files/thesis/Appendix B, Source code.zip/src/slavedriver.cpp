/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "slavedriver.hpp"
#include "communicator.hpp"
#include "error.hpp"
#include "pipe.hpp"
#include <boost/filesystem/operations.hpp>
#include <boost/format.hpp>
#include <cerrno>
#include <iostream>
#include <sys/wait.h>


Slavedriver::Slavedriver( const boost::filesystem::path &logfile,
                          const std::string &command, const std::vector<std::string> &arguments )
  : logfile_(logfile), child_(0), command_(command), arguments_(arguments)
{
}


Slavedriver::~Slavedriver() {
  try {
    kill_child();
  }
  catch( ... ) {
    // Ignore.
  }
}


void
Slavedriver::reset() {
  reset( command_, arguments_ );
}


void
Slavedriver::reset( const std::vector<std::string> &arguments ) {
  reset( command_, arguments );
}


void
Slavedriver::reset( const std::string &command, const std::vector<std::string> &arguments ) {
  kill_child();

  command_ = command;
  arguments_ = arguments;
}


std::string
Slavedriver::execute( const std::string &query, unsigned retries ) {
  while( true ) {
    try {
      run_child();
      assert( communicator_ );
      communicator_->send_message( query );
      return communicator_->receive_message();
    }
    catch( boost::exception &e ) {
      if( retries-- != 0 ) {
        kill_child();
        sleep( 1 );
        continue;
      }
      else {
        BOOST_THROW_EXCEPTION( SlavedriverExecuteError()
                               << errinfo_nested_exception(boost::copy_exception(e)) );
      }
    }
  }
}


boost::optional<File>
Slavedriver::logfile() {
  if( logfile_.empty() )
    return boost::none;
  else
    return File::unique( logfile_ );
}


void
Slavedriver::check_child() {
  if( child_ == 0 ) {
    // Nothing to do.
    return;
  }

  pid_t res;
  if( (res = waitpid(child_, NULL, WNOHANG)) == -1 ) {
    BOOST_THROW_EXCEPTION( SystemError() << errinfo_api_function("waitpid")
                           << errinfo_errno(errno) << errinfo_slave_pid(child_) );
  }

  assert( res == 0 || res == child_ );

  if( res == child_ ) {
    // Child is dead now.
    child_ = 0;
    communicator_.reset();
  }
}


void
Slavedriver::kill_child() {
  if( child_ == 0 ) {
    // Nothing to do.
    return;
  }

  // Send the hang-up signal.
  if( kill(child_, SIGHUP) != 0 ) {
    BOOST_THROW_EXCEPTION( SystemError() << errinfo_api_function("kill")
                           << errinfo_errno(errno) << errinfo_slave_pid(child_) );
  }

  // Give child process five seconds to shutdown gracefully.
  for( unsigned i = 0; child_ != 0 && i < 5000; ++i ) {
    usleep( 1000 );
    check_child();
  }

  if( child_ == 0 ) {
    // Nothing to do.
    return;
  }

  // Send the kill signal.
  if( kill(child_, SIGKILL) != 0 ) {
    BOOST_THROW_EXCEPTION( SystemError() << errinfo_api_function("kill")
                           << errinfo_errno(errno) << errinfo_slave_pid(child_) );
  }

  if( waitpid(child_, NULL, 0) != child_ ) {
    BOOST_THROW_EXCEPTION( SystemError() << errinfo_api_function("waitpid")
                           << errinfo_errno(errno) << errinfo_slave_pid(child_) );
  }

  child_ = 0;
  communicator_.reset();
}



namespace detail {

  void
  dup2( int oldfd, int newfd ) {
    if( ::dup2(oldfd, newfd) == -1 ) {
      BOOST_THROW_EXCEPTION( SystemError() << errinfo_api_function("dup2") << errinfo_errno(errno)
                             << errinfo_file_descriptor(oldfd) << errinfo_file_descriptor_2(newfd) );
    }
  }

}



void
Slavedriver::run_child() {
  check_child();

  if( child_ != 0 ) {
    // Nothing to do.
    return;
  }

  // Create pipes.

  Pipe pipe_pc;  // parent -> child
  Pipe pipe_cp;  // child -> parent

  // Create error logfile.

  boost::optional<File> logfile = this->logfile();

  // Prepare exec() arguments.

  const char *path;
  std::vector<char *> argv( arguments_.size()+2 );

  path = argv[0] = const_cast<char *>(command_.c_str());

  for( unsigned i = 0; i < arguments_.size(); ++i )
    argv[i+1] = const_cast<char *>(arguments_[i].c_str());

  argv[arguments_.size()+1] = NULL;

  // Fork child process.

  pid_t child;

  switch( (child = fork()) ) {
  case -1:
    BOOST_THROW_EXCEPTION( SystemError() << errinfo_api_function("fork") << errinfo_errno(errno) );

  case 0:
    // Child process.
    close( pipe_cp.read_end(true) );  // read end of child -> parent
    close( pipe_pc.write_end(true) );  // write end of parent -> child

    try {
      try {
        detail::dup2( pipe_pc.read_end(), STDIN_FILENO );
        close( pipe_pc.read_end(true) );

        detail::dup2( pipe_cp.write_end(), STDOUT_FILENO );
        close( pipe_cp.write_end(true) );

        if( logfile ) {
          detail::dup2( logfile->file(), STDERR_FILENO );
          close( logfile->file(true) );
        }

        execv( path, argv.data() );

        // If we reach this, something went wrong.
        BOOST_THROW_EXCEPTION( SystemError() << errinfo_api_function("execv")
                               << errinfo_errno(errno) << errinfo_value<std::string>(path) );
      }
#if BOOST_VERSION >= 103900
      catch( ... ) {
        std::cerr << "Caught unhandled exception in fork'd child process.\n"
                  << boost::current_exception_diagnostic_information();
        std::cerr << std::flush;
      }
#else
      catch( boost::exception &e ) {
        std::cerr << "Caught unhandled exception in fork'd child process.\n"
                  << boost::diagnostic_information( e );
        std::cerr << std::flush;
      }
      catch( ... ) {
        std::cerr << "Caught unhandled exception in fork'd child process.\n"
                  << "<unknown exception>\n";
        std::cerr << std::flush;
      }
#endif
    }
    catch( ... ) {
      // Ignore all exceptions. We have to call exit and not let
      // exceptions fall through here because we don't want any
      // destructors to be executed inside the child process.
    }

    exit( EXIT_FAILURE );

  default:
    // Parent process.
    close( pipe_pc.read_end(true) );  // read end of parent -> child
    close( pipe_cp.write_end(true) );  // write end of child -> parent

    if( logfile )
      close( logfile->file(true) );

    communicator_.reset( new Communicator(pipe_cp.read_end(), pipe_pc.write_end()) );
    pipe_pc.write_end( true );
    pipe_cp.read_end( true );
    child_ = child;
  }
}

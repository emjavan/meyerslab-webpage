/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "manager.hpp"
#include "error.hpp"
#include "manager_main_impl.hpp"
#include "manager_proc_impl.hpp"
#include <boost/mpi/communicator.hpp>
#include <boost/mpi/environment.hpp>


NodeManager::StatsEntry::StatsEntry( NodeManager &manager,
                                     const std::string &what, int priority,
                                     const std::string &idle, int idle_priority )
  : ::StatsEntry(manager.stats_, what, priority, idle, idle_priority)
{
}


NodeManager::NodeManager( boost::mpi::communicator &world )
  : world_(world)
{
}


boost::shared_ptr<NodeManager>
NodeManager::create( boost::mpi::communicator &world ) {
  if( world.rank() == 0 )
    return boost::shared_ptr<NodeManager>( new MainNodeManagerImpl(world) );
  else
    return boost::shared_ptr<NodeManager>( new ProcNodeManagerImpl(world) );
}


void
NodeManager::log_statistics() {
  std::stringstream buffer;
  stats_.print( buffer );
  log_info( (boost::format("Time statistics:\n%s") % buffer.str()).str() );
}


int
NodeManager::min_tag() {
  return 0;
}


int
NodeManager::max_tag() {
  return boost::mpi::environment::max_tag();
}


unsigned
NodeManager::tag_count() {
  assert( min_tag() <= max_tag() );
  return unsigned(max_tag() - min_tag()) + 1;
}


int &
NodeManager::next_tag( int &tag ) {
  DICON_ASSERT_RANGE( tag, min_tag(), max_tag() );

  if( tag != max_tag() )
    ++tag;
  else
    tag = min_tag();

  return tag;
}

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "library.hpp"
#include "file.hpp"
#include <boost/format.hpp>
#include <dlfcn.h>


namespace detail {

  std::string
  dlerror() {
    char *res;

    if( (res = ::dlerror()) != NULL )
      return res;
    else
      return "NULL";
  }

}



DynamicLibrary::DynamicLibrary( const std::string &file ) {
  if( (handle_ = dlopen(file.c_str(), RTLD_NOW)) == NULL ) {
    BOOST_THROW_EXCEPTION( LibraryOpenError() << errinfo_api_function("dlopen")
                           << errinfo_file_name(file) << errinfo_library_dlerror(detail::dlerror()) );
  }
}


DynamicLibrary::~DynamicLibrary() {
  dlclose( handle_ );
  // Ignore errors.
}


void *
DynamicLibrary::operator[]( const std::string &symbol ) {
  void *res;

  if( (res = dlsym(handle_, symbol.c_str())) == NULL ) {
    BOOST_THROW_EXCEPTION( LibrarySymbolError() << errinfo_api_function("dlsym")
                           << errinfo_library_symbol(symbol) << errinfo_library_dlerror(detail::dlerror()) );
  }

  return res;
}

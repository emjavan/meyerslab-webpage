/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "manager_main.hpp"
#include "error.hpp"
#include "log.hpp"
#include <boost/format.hpp>
#include <boost/mpi/communicator.hpp>


namespace detail {

  static const size_t isend_queue_size = 50;

}



namespace detail {

  class AnswerDispatcher
    : public boost::static_visitor<>
  {
  public:
    AnswerDispatcher( MainNodeManager &manager, const boost::mpi::status &status );

  public:
    void operator()( const message::answer::StartLogging  &data ) const;
    void operator()( const message::answer::InitOptimizer &data ) const;
    void operator()( const message::answer::InitSimulator &data ) const;
    void operator()( const message::answer::InitCombined  &data ) const;
    void operator()( const message::answer::GetPolicy     &data ) const;
    void operator()( const message::answer::Simulate      &data ) const;
    void operator()( const message::answer::Update        &data ) const;
    void operator()( const message::answer::StepCombined  &data ) const;
    void operator()( const message::answer::DumpOptimizer &data ) const;
    void operator()( const message::answer::DumpPolicies  &data ) const;
    void operator()( const message::answer::Shutdown      &data ) const;

    void operator()( const message::answer::Failure       &data ) const;

  private:
    MainNodeManager &manager_;
    const boost::mpi::status &status_;
  };

}



namespace detail {

  template< typename Q >
  static
  message::Question
  make_question( const Q &question ) {
    message::Question res;
    res.data = question;
    return res;
  }


  static
  inline
  void
  log_debug( const std::string &what, int node, bool finish = false ) throw() {
    try {
      ::log_debug( (boost::format( !finish
                                   ? "[Node #%u] %s()"
                                   : "[Node #%u] finish_%s()" ) % node % what).str() );
    }
    catch( ... ) {
      // Ignore.
    }
  }


  AnswerDispatcher::AnswerDispatcher( MainNodeManager &manager, const boost::mpi::status &status )
    : manager_(manager), status_(status)
  {
  }


  void
  AnswerDispatcher::operator()( const message::answer::StartLogging &data ) const {
    MainNodeManager::StatsEntry se( manager_, "start_logging()", 10 );
    log_debug( "start_logging", status_.source(), true );
    manager_.finish_start_logging( status_.source() );
  }


  void
  AnswerDispatcher::operator()( const message::answer::InitOptimizer &data ) const {
    MainNodeManager::StatsEntry se( manager_, "init_optimizer()", 20 );
    log_debug( "init_optimizer", status_.source(), true );
    manager_.finish_init_optimizer( status_.source() );
  }


  void
  AnswerDispatcher::operator()( const message::answer::InitSimulator &data ) const {
    MainNodeManager::StatsEntry se( manager_, "init_simulator()", 30 );
    log_debug( "init_simulator", status_.source(), true );
    manager_.finish_init_simulator( status_.source() );
  }


  void
  AnswerDispatcher::operator()( const message::answer::InitCombined &data ) const {
    MainNodeManager::StatsEntry se( manager_, "init_combined()", 40 );
    log_debug( "init_combined", status_.source(), true );
    manager_.finish_init_combined( status_.source() );
  }


  void
  AnswerDispatcher::operator()( const message::answer::GetPolicy &data ) const {
    MainNodeManager::StatsEntry se( manager_, "get_policy()", 50 );
    log_debug( "get_policy", status_.source(), true );
    manager_.finish_get_policy( status_.source(), data.policy );
  }


  void
  AnswerDispatcher::operator()( const message::answer::Simulate &data ) const {
    MainNodeManager::StatsEntry se( manager_, "simulate()", 60 );
    log_debug( "simulate", status_.source(), true );
    manager_.finish_simulate( status_.source(), data.reward );
  }


  void
  AnswerDispatcher::operator()( const message::answer::Update &data ) const {
    MainNodeManager::StatsEntry se( manager_, "update()", 70 );
    log_debug( "update", status_.source(), true );
    manager_.finish_update( status_.source() );
  }


  void
  AnswerDispatcher::operator()( const message::answer::StepCombined &data ) const {
    MainNodeManager::StatsEntry se( manager_, "step_combined()", 80 );
    log_debug( "step_combined", status_.source(), true );
    manager_.finish_step_combined( status_.source(), data.got_policy );
  }


  void
  AnswerDispatcher::operator()( const message::answer::DumpOptimizer &data ) const {
    MainNodeManager::StatsEntry se( manager_, "dump_optimizer()", 90 );
    log_debug( "dump_optimizer", status_.source(), true );
    manager_.finish_dump_optimizer( status_.source() );
  }


  void
  AnswerDispatcher::operator()( const message::answer::DumpPolicies &data ) const {
    MainNodeManager::StatsEntry se( manager_, "dump_policies()", 100 );
    log_debug( "dump_policies", status_.source(), true );
    manager_.finish_dump_policies( status_.source() );
  }


  void
  AnswerDispatcher::operator()( const message::answer::Shutdown &data ) const {
    MainNodeManager::StatsEntry se( manager_, "shutdown()", 110 );
    log_debug( "shutdown", status_.source(), true );
    manager_.finish_shutdown( status_.source(), data.done );
  }


  void
  AnswerDispatcher::operator()( const message::answer::Failure &data ) const {
    MainNodeManager::StatsEntry se( manager_, "handle_failure()", 900 );
    log_debug( "handle_failure", status_.source() );
    manager_.handle_failure( status_.source(), data.what );
  }

}



std::ostream &
operator<<( std::ostream &out, NodeState state ) {
  switch( state ) {
#define DICON_HANDLE_STATE_( STATE ) case STATE: out << #STATE; break
  DICON_HANDLE_STATE_( NODE_IDLE                   );
  DICON_HANDLE_STATE_( NODE_STARTING_LOGGING       );
  DICON_HANDLE_STATE_( NODE_INITIALIZING_OPTIMIZER );
  DICON_HANDLE_STATE_( NODE_INITIALIZING_SIMULATOR );
  DICON_HANDLE_STATE_( NODE_INITIALIZING_COMBINED  );
  DICON_HANDLE_STATE_( NODE_GETTING_POLICY         );
  DICON_HANDLE_STATE_( NODE_SIMULATING             );
  DICON_HANDLE_STATE_( NODE_UPDATING               );
  DICON_HANDLE_STATE_( NODE_STEPPING_COMBINED      );
  DICON_HANDLE_STATE_( NODE_DUMPING_OPTIMIZER      );
  DICON_HANDLE_STATE_( NODE_DUMPING_POLICIES       );
  DICON_HANDLE_STATE_( NODE_SHUTTING_DOWN          );
#undef DICON_HANDLE_STATE_
  }

  return out;
}


MainNodeManager::NodeRecord::NodeRecord( int min_tag )
  : current_tag(min_tag)
{
}


MainNodeManager::MainNodeManager( boost::mpi::communicator &world )
  : NodeManager(world), nodes_(child_count(), NodeRecord(min_tag()))
{
}


MainNodeManager::~MainNodeManager() {
  try {
    while( !isend_queue_.empty() ) {
      try {
        isend_queue_.front().wait();
      }
      catch( ... ) {
        // Ignore.
      }

      isend_queue_.pop_front();
    }
  }
  catch( ... ) {
    // Ignore.
  }
}


int
MainNodeManager::min_child() const {
  return 1;
}


int
MainNodeManager::max_child() const {
  return world().size() - 1;
}


unsigned
MainNodeManager::child_count() const {
  return max_child() - min_child() + 1;
}


int &
MainNodeManager::current_tag( int node ) {
  assert( min_child() <= node && node <= max_child() );
  return nodes_[node - min_child()].current_tag;
}


MainNodeManager::state_queue_t &
MainNodeManager::state_queue( int node ) {
  assert( min_child() <= node && node <= max_child() );
  return nodes_[node - min_child()].state_queue;
}


const MainNodeManager::state_queue_t &
MainNodeManager::state_queue( int node ) const {
  assert( min_child() <= node && node <= max_child() );
  return nodes_[node - min_child()].state_queue;
}


template< typename Q >
void
MainNodeManager::async_enqueue( int node, const Q &question, NodeState state ) {
  DICON_ASSERT_RANGE( node, min_child(), max_child() );

  unsigned requests = request_queue_.size();
  assert( requests <= tag_count() );
  if( requests == tag_count() )
    BOOST_THROW_EXCEPTION( AssertionError() );

  assert( isend_queue_.size() <= detail::isend_queue_size );
  if( isend_queue_.size() == detail::isend_queue_size ) {
    assert( !isend_queue_.empty() );
    isend_queue_.front().wait();
    isend_queue_.pop_front();
  }

  const message::Question &q = detail::make_question( question );
  const unsigned tag = next_tag(current_tag(node));

  isend_queue_.push_back( world().isend(node, tag, q) );

  RequestData data;
  data.which_message = q.data.which();
  data.answer.reset( new message::Answer() );

  request_queue_.push( node,
                       world().irecv(node, tag, *data.answer), data );

  assert( state != NODE_IDLE );
  state_queue(node).push( state );
}


void
MainNodeManager::start_logging( int node, const boost::filesystem::path &logfile, LogLevel min_level ) {
  detail::log_debug( "start_logging", node );

  message::question::StartLogging question;

  question.logfile   = logfile;
  question.min_level = min_level;

  async_enqueue( node, question, NODE_STARTING_LOGGING );
}


void
MainNodeManager::init_optimizer( int node
                               , const boost::filesystem::path &optimizer_logfile
                               , const boost::filesystem::path &simulator_logfile
                               , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                               , const std::string &simulator_command, const arguments_t &simulator_arguments
                               , const boost::optional<boost::filesystem::path> &optimizer_map_file
                               , const boost::optional<boost::filesystem::path> &optimizer_lib_file
                               )
{
  detail::log_debug( "init_optimizer", node );

  message::question::InitOptimizer question;

  question.optimizer_logfile   = optimizer_logfile;
  question.optimizer_library   = optimizer_library;
  question.optimizer_arguments = optimizer_arguments;
  question.optimizer_map_file  = optimizer_map_file;
  question.optimizer_lib_file  = optimizer_lib_file;

  question.simulator_logfile   = simulator_logfile;
  question.simulator_command   = simulator_command;
  question.simulator_arguments = simulator_arguments;

  async_enqueue( node, question, NODE_INITIALIZING_OPTIMIZER );
}


void
MainNodeManager::init_simulator( int node
                               , const boost::filesystem::path &simulator_logfile
                               , const std::string &simulator_command, const arguments_t &simulator_arguments
                               )
{
  detail::log_debug( "init_simulator", node );

  message::question::InitSimulator question;

  question.simulator_logfile   = simulator_logfile;
  question.simulator_command   = simulator_command;
  question.simulator_arguments = simulator_arguments;

  async_enqueue( node, question, NODE_INITIALIZING_SIMULATOR );
}


void
MainNodeManager::init_combined( int node
                              , const boost::filesystem::path &optimizer_logfile
                              , const boost::filesystem::path &simulator_logfile
                              , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                              , const std::string &simulator_command, const arguments_t &simulator_arguments
                              , const boost::optional<boost::filesystem::path> &optimizer_map_file
                              , const boost::optional<boost::filesystem::path> &optimizer_lib_file
                              )
{
  detail::log_debug( "init_combined", node );

  message::question::InitCombined question;

  question.optimizer_logfile   = optimizer_logfile;
  question.optimizer_library   = optimizer_library;
  question.optimizer_arguments = optimizer_arguments;
  question.optimizer_map_file  = optimizer_map_file;
  question.optimizer_lib_file  = optimizer_lib_file;

  question.simulator_logfile   = simulator_logfile;
  question.simulator_command   = simulator_command;
  question.simulator_arguments = simulator_arguments;

  async_enqueue( node, question, NODE_INITIALIZING_COMBINED );
}


void
MainNodeManager::get_policy( int node ) {
  detail::log_debug( "get_policy", node );

  message::question::GetPolicy question;

  // Nothing to do.

  async_enqueue( node, question, NODE_GETTING_POLICY );
}


void
MainNodeManager::simulate( int node, const policy_t &policy ) {
  detail::log_debug( "simulate", node );

  message::question::Simulate question;

  question.policy = policy;

  async_enqueue( node, question, NODE_SIMULATING );
}


void
MainNodeManager::update( int node, const policy_t &policy, double reward ) {
  detail::log_debug( "update", node );

  message::question::Update question;

  question.policy = policy;
  question.reward = reward;

  async_enqueue( node, question, NODE_UPDATING );
}


void
MainNodeManager::step_combined( int node ) {
  detail::log_debug( "step_combined", node );

  message::question::StepCombined question;

  // Nothing to do.

  async_enqueue( node, question, NODE_STEPPING_COMBINED );
}


void
MainNodeManager::dump_optimizer( int node, const boost::filesystem::path &file, DumpOptimizerMode mode ) {
  detail::log_debug( "dump_optimizer", node );

  message::question::DumpOptimizer question;

  question.file = file;
  question.mode = mode;

  async_enqueue( node, question, NODE_DUMPING_OPTIMIZER );
}


void
MainNodeManager::dump_policies( int node, const boost::filesystem::path &file, unsigned count, bool display ) {
  detail::log_debug( "dump_policies", node );

  message::question::DumpPolicies question;

  question.file = file;
  question.count = count;
  question.display = display;

  async_enqueue( node, question, NODE_DUMPING_POLICIES );
}


void
MainNodeManager::shutdown( int node ) {
  detail::log_debug( "shutdown", node );

  message::question::Shutdown question;

  // Nothing to do.

  async_enqueue( node, question, NODE_SHUTTING_DOWN );
}


NodeState
MainNodeManager::state( int node ) const {
  DICON_ASSERT_RANGE( node, min_child(), max_child() );

  const state_queue_t &queue
    = state_queue( node );

  if( queue.empty() )
    return NODE_IDLE;
  else
    return queue.front();
}


bool
MainNodeManager::process() {
  if( request_queue_.empty() )
    return false;

  StatsEntry se( *this, "processing", 0, "(idle)", 0 );

  const std::pair<boost::mpi::status, RequestData> &res
    = request_queue_.wait();

  const RequestData &data = res.second;
  const message::Answer &answer = *data.answer;

  if( answer.data.which() != data.which_message &&
      !boost::get<message::answer::Failure>(&answer.data) )
  {
    // Answer type did not match question (and request did not fail).
    BOOST_THROW_EXCEPTION( AssertionError()
                           << errinfo_value<int>(answer.data.which())
                           << errinfo_expected_value<int>(data.which_message) );
  }

  // Dispatch according to type of answer; call corresponding `finish_' method.
  boost::apply_visitor( detail::AnswerDispatcher(*this, res.first), answer.data );

  state_queue_t &queue
    = state_queue( res.first.source() );

  if( queue.empty() )
    BOOST_THROW_EXCEPTION( AssertionError() );

  queue.pop();

  return true;
}

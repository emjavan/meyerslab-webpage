/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "types.hpp"
#include <istream>


std::istream &
operator>>( std::istream &in, LogLevel &result ) {
  std::string str;
  in >> str;

#define DICON_LOG_LEVEL_STR_(STR, VAL) if( str == #STR ) do { result = LOG_##VAL; } while( false )
  /**/ DICON_LOG_LEVEL_STR_( debug  , DEBUG   );
  else DICON_LOG_LEVEL_STR_( info   , INFO    );
  else DICON_LOG_LEVEL_STR_( warning, WARNING );
  else DICON_LOG_LEVEL_STR_( error  , ERROR   );
  else DICON_LOG_LEVEL_STR_( failure, FAILURE );
  else in.setstate( std::ios_base::failbit );
#undef DICON_LOG_LEVEL_STR_

  return in;
}

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "manager_proc_impl.hpp"
#include "error.hpp"
#include "log.hpp"


ProcNodeManagerImpl::ProcNodeManagerImpl( boost::mpi::communicator &world )
  : ProcNodeManager(world)
{
}


void
ProcNodeManagerImpl::start_logging( const boost::filesystem::path &logfile, LogLevel min_level ) {
  logfile_.reset( new LogFile(logfile) );
  log_register_sink( logfile_, min_level );
}


void
ProcNodeManagerImpl::init_optimizer( const boost::filesystem::path &optimizer_logfile
                                   , const boost::filesystem::path &simulator_logfile
                                   , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                                   , const std::string &simulator_command, const arguments_t &simulator_arguments
                                   , const boost::optional<boost::filesystem::path> &optimizer_map_file
                                   , const boost::optional<boost::filesystem::path> &optimizer_lib_file
                                   )
{
  reset_all();
  optimizer_.reset( new Optimizer(optimizer_logfile, simulator_logfile,
                                  optimizer_library, optimizer_arguments,
                                  simulator_command, simulator_arguments,
                                  optimizer_map_file, optimizer_lib_file) );
}


void
ProcNodeManagerImpl::init_simulator( const boost::filesystem::path &simulator_logfile
                                   , const std::string &simulator_command, const arguments_t &simulator_arguments
                                   )
{
  reset_all();
  simulator_.reset( new Simulator(simulator_logfile,
                                  simulator_command, simulator_arguments) );
}


void
ProcNodeManagerImpl::init_combined( const boost::filesystem::path &optimizer_logfile
                                  , const boost::filesystem::path &simulator_logfile
                                  , const std::string &optimizer_library, const arguments_t &optimizer_arguments
                                  , const std::string &simulator_command, const arguments_t &simulator_arguments
                                  , const boost::optional<boost::filesystem::path> &optimizer_map_file
                                  , const boost::optional<boost::filesystem::path> &optimizer_lib_file
                                  )
{
  reset_all();
  combined_.reset( new Combined(optimizer_logfile, simulator_logfile,
                                optimizer_library, optimizer_arguments,
                                simulator_command, simulator_arguments,
                                optimizer_map_file, optimizer_lib_file) );
}


boost::optional<policy_t>
ProcNodeManagerImpl::get_policy() {
  if( !optimizer_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  return optimizer_->get_policy();
}


double
ProcNodeManagerImpl::simulate( const policy_t &policy ) {
  if( !simulator_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  return simulator_->simulate( policy );
}


void
ProcNodeManagerImpl::update( const policy_t &policy, double reward ) {
  if( !optimizer_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  optimizer_->update( policy, reward );
}


bool
ProcNodeManagerImpl::step_combined() {
  if( !combined_ )
    BOOST_THROW_EXCEPTION( AssertionError() );

  return combined_->step();
}



namespace detail {

  template< typename T >
  static
  bool
  dump_optimizer( const boost::scoped_ptr<T> &optimizer,
                  const boost::filesystem::path &file, DumpOptimizerMode mode )
  {
    if( optimizer ) {
      switch( mode ) {
      case DUMP_OPTIMIZER_MAP: optimizer->dump_optimizer_map( file ); break;
      case DUMP_OPTIMIZER_LIB: optimizer->dump_optimizer_lib( file ); break;
      }
    }

    return bool(optimizer);
  }


  template< typename T >
  static
  bool
  dump_policies( const boost::scoped_ptr<T> &optimizer,
                 const boost::filesystem::path &file, unsigned count, bool display )
  {
    if( optimizer )
      optimizer->dump_policies( file, count, display );

    return bool(optimizer);
  }

}



void
ProcNodeManagerImpl::dump_optimizer( const boost::filesystem::path &file, DumpOptimizerMode mode ) {
  if(  !detail::dump_optimizer(optimizer_, file, mode)
    && !detail::dump_optimizer(combined_ , file, mode) )
  {
    BOOST_THROW_EXCEPTION( AssertionError() );
  }
}


void
ProcNodeManagerImpl::dump_policies( const boost::filesystem::path &file, unsigned count, bool display ) {
  if(  !detail::dump_policies(optimizer_, file, count, display)
    && !detail::dump_policies(combined_ , file, count, display) )
  {
    BOOST_THROW_EXCEPTION( AssertionError() );
  }
}


bool
ProcNodeManagerImpl::shutdown() {
  log_statistics();

  reset_all( true );

  return true;
}


void
ProcNodeManagerImpl::reset_all( bool logfile ) {
  if( logfile )
    logfile_.reset();

  optimizer_.reset();
  simulator_.reset();
  combined_.reset();
}

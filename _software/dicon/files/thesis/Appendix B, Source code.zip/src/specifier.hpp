#ifndef DICON_SPECIFIER_HPP_
#define DICON_SPECIFIER_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Specifier parser.
 *
 * The  specifier.hpp  file  provides  the  parser  for  argument  and
 * schedule  specifiers  such  as   used  in  the  main  configuration
 * parameters  @c sim_args and  @c opt_orgs,  and @c  checkpoints. The
 * complete      grammar     for     both      argument     specifiers
 * (<code>ArgumentSpecifier</code>)     and     schedule    specifiers
 * (<code>ScheduleSpecifier</code>)  is given in  Extended Backus-Naur
 * Form (EBNF, as per ISO/IEC 14977:1996(E)) as follows.
 *
 * @verbatim
ArgumentSpecifier = Set ;
ScheduleSpecifier = "[" , ( RegularRange | ExpressionRange ) , "]"
                  | Expression , { "," , Expression } ;

Set = Specifier , { "|" , Specifier } ;
Specifier = SpecifierElement , { SpecifierElement } ;
SpecifierElement = "[" , ( RegularRange | ExpressionRange ) , "]"
                 | "{" , Set , "}"
                 | Literal ;

RegularRange = RegularRangeElement , { "|" , RegularRangeElement } ;
RegularRangeElement = Singleton | SimpleRange | ExtendedRange ;

ExpressionRange = Expression , ":" , ( ExpressionSubrange , { ":" , ExpressionSubrange } ) ;
ExpressionSubrange = [ Identifier , "=" ] , RegularRange ;

Singleton = Expression ;
SimpleRange = Expression , ".." , [ Expression ] ;
ExtendedRange = Expression , "," , Expression , ".." , [ Expression ] ;

Expression = Term , { ( "+" | "-" ) , Term } ;
Term = Factor , { ( "*" | "/" ) , Factor } ;
Factor = Group , "^" , Factor
       | [ "+" | "-" ] , Group ;
Group = "(" , Expression , ")"
      | FunctionCall | Identifier | Real ;
FunctionCall = FunctionName , "(" , Expression , ")" ;
Identifier = ( Letter | "_" ) , { Letter | Digit | "_" } ;

Literal = LiteralElement , { LiteralElement } ;
LiteralElement = "'" , SingleQuoted , "'"
               | '"' , DoubleQuoted , '"'
               | RegularCharacter ;
SingleQuoted = ? any character except ' ? ;
DoubleQuoted = ? any character except " ? ;
RegularCharacter = ? any character except ', ", |, [, ], {, } ? ;

Real = [ "+" | "-" ] , Digits , [ "." , Digits ] , [ ( "e" | "E" ) , [ "+" | "-" ] , Digits ] ;
Digits = Digit , { Digit } ;

Digit = "0" | "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" ;
Letter = ? any character either in range "a" to "z", or "A" to "Z" ? ;
FunctionName = "sqrt"  | "round"  | "trunc" | "floor" | "ceil"  | "abs"
             | "log"   | "log2"   | "log10" | "exp"   | "exp2"  | "exp10"
             | "cos"   | "sin"    | "tan"   | "acos"  | "asin"  | "atan"
             | "cosh"  | "sinh"   | "tanh"  | "acosh" | "asinh" | "atanh"
             | "erf"   | "erfc"   | "j0"    | "j1"    | "y0"    | "y1"
             | "gamma" | "lgamma" | "log1p" | "expm1" ;
@endverbatim
 *
 * The    following    are    examples   for    argument    specifiers
 * (<code>ArgumentSpecifier</code>)  with the  sets of  arguments they
 * represent.
 *
 * @verbatim
foo|bar                        ->  {foo, bar}
[1..10]                        ->  {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
[0,0.1..1]                     ->  {0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1}
[1..10|10,20..90]              ->  {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70, 80, 90}
[x^2+y^2:x=1..6:y=2..4]        ->  {5, 10, 17, 8, 13, 20, 13, 18, 25, 20, 25, 32, 29, 34, 41, 40, 45, 52}
--foo=[1..2]|--bar=[3..9]      ->  {--foo=1, --foo=2, --bar=3, --bar=4, --bar=5, --bar=6, --bar=7, --bar=8, --bar=9}
--method={a|b} --value=[1..2]  ->  {--method=a --value=1, --method=a --value=2, --method=b --value=1, --method=b --value=2}
@endverbatim
 *
 * The    following    are    examples   for    schedule    specifiers
 * (<code>ScheduleSpecifier</code>)  with  the  sets of  numbers  they
 * represent.
 *
 * @verbatim
1,4,9,2,6,10   ->  {1, 2, 4, 6, 9, 10}
[2..4|9,7..1]  ->  {1, 2, 3, 4, 5, 7, 9}
[2^(x*2):0..]  ->  {1, 4, 16, 64, 256, ...}
@endverbatim
 *
 * @see http://en.wikipedia.org/wiki/Extended_Backus-Naur_Form
 */
#include "error.hpp"
#include "lazy/set.hpp"
#include "types.hpp"
#include <string>


/// Errinfo storing function name in specifier.
DICON_ERRINFO( specifier_function_name, std::string );
/// Errinfo storing variable name in specifier.
DICON_ERRINFO( specifier_variable_name, std::string );


/// Specifier related error.
struct SpecifierError : virtual Error
{ virtual const char *what() const throw() { return "Specifier related error."; } };

/// Failed to parse specifier.
struct SpecifierParseError : virtual SpecifierError
{ virtual const char *what() const throw() { return "Failed to parse specifier."; } };

/// Failed to parse specifier range.
struct SpecifierRangeError : virtual SpecifierParseError
{ virtual const char *what() const throw() { return "Failed to parse specifier range."; } };

/// Range in specifier has zero step size.
struct SpecifierRangeZeroStepError : virtual SpecifierRangeError
{ virtual const char *what() const throw() { return "Range in specifier has zero step size."; } };

/// Unbounded decreasing range in specifier.
struct SpecifierRangeUnboundedError : virtual SpecifierRangeError
{ virtual const char *what() const throw() { return "Unbounded decreasing range in specifier."; } };

/// Variable not defined in specifier.
struct SpecifierUndefinedVariableError : virtual SpecifierParseError
{ virtual const char *what() const throw() { return "Variable not defined in specifier."; } };

/// Function not defined in specifier.
struct SpecifierUndefinedFunctionError : virtual SpecifierParseError
{ virtual const char *what() const throw() { return "Function not defined in specifier."; } };

/// Variable already defined in specifier.
struct SpecifierVariableRedefinedError : virtual SpecifierParseError
{ virtual const char *what() const throw() { return "Variable already defined in specifier."; } };

/// Too many variables in specifier.
struct SpecifierTooManyVariablesError : virtual SpecifierParseError
{ virtual const char *what() const throw() { return "Too many variables in specifier."; } };

/// Variable not used in specifier.
struct SpecifierUnusedVariableError : virtual SpecifierParseError
{ virtual const char *what() const throw() { return "Variable not used in specifier."; } };

/// Invalid simulation count produced by specifier.
struct SpecifierInvalidSimcountError : virtual SpecifierError
{ virtual const char *what() const throw() { return "Invalid simulation count produced by specifier."; } };


/**
 * @brief Parse argument specifier.
 *
 * Parse the  string given by  @e specifier, representing  an argument
 * specifier.  The complete  grammar for such a specifier  is given in
 * the documentation of the specifier.hpp file.
 *
 * This call  returns a lazy set representing  the arguments specified
 * by the given string.
 *
 * @param specifier String representing argument specifier.
 * @returns Lazy set containing the arguments specified.
 *
 * @throws  SpecifierParseError  or a  derived  class  when the  given
 *   specifier cannot be parsed.
 */
LazySet<std::string>::ptr_t parse_argument_specifier( const std::string &specifier );
/**
 * @brief Parse schedule specifier.
 *
 * Parse  the string given  by @e  specifier, representing  a schedule
 * specifier.  The complete  grammar for such a specifier  is given in
 * the documentation of the specifier.hpp file.
 *
 * This call returns  a lazy set representing the  schedule, i.e., the
 * list of simulation counts, specified by the given string.
 *
 * The elements in the set returned by this function are of type @link
 * ::simcount_t  simcount_t@endlink.  When  an element  in the  set is
 * requested  (LazySet::get()) that  does not  represent  a simulation
 * count,  i.e., it  is either  not a  positive integer  or  cannot be
 * represented  in  the  range   defined  by  the  @link  ::simcount_t
 * simcount_t@endlink      type,     an     exception      of     type
 * SpecifierInvalidSimcountError is thrown.  As the set represented by
 * the given  specifier can be infinite,  this check can  only be done
 * when   the  invalid   element   in  question   has  been   reached.
 * Specifically, this check  cannot be done at the  time the specifier
 * is parsed.
 *
 * @param specifier String representing schedule specifier.
 * @returns Lazy set containing the schedule specified.
 *
 * @throws  SpecifierParseError  or a  derived  class  when the  given
 *   specifier cannot be parsed.
 */
LazySet<simcount_t>::ptr_t parse_schedule_specifier( const std::string &specifier );

#endif //DICON_SPECIFIER_HPP_

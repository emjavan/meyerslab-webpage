/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "config.hpp"
#include <boost/foreach.hpp>
#include <boost/format.hpp>
#include <boost/optional.hpp>
#include <cassert>
#include <fstream>
#include <iostream>
#include <set>
#include <stdexcept>


namespace detail {

  static const char config_whitespace[] = " \n\r\t";

  static const char config_comment[] = ";#";

  static const char config_section_open  = '[';
  static const char config_section_close = ']';

  static const char config_separator = '=';

  static const char config_name[] =
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789"
    "[]-_"
    ;


  static
  std::string
  strip( const std::string &text ) {
    std::string::size_type first;
    if( (first = text.find_first_not_of(config_whitespace)) == std::string::npos ) {
      // Found no non-blank character.
      return std::string();
    }

    std::string::size_type last = text.find_last_not_of(config_whitespace);
    assert( last != std::string::npos );
    assert( first <= last );

    return text.substr( first, last-first+1 );
  }


  static
  bool
  is_blank( const std::string &line ) {
    return line.empty();
  }


  static
  bool
  is_comment( const std::string &line ) {
    return !line.empty() && std::string(config_comment).find(line[0]) != std::string::npos;
  }


  static
  bool
  is_section( const std::string &line, std::string &section ) {
    if( !line.empty() && line[0] == config_section_open && line[line.size()-1] == config_section_close ) {
      section = strip( line.substr(1, line.size()-2) );
      return true;
    }

    return false;
  }


  static
  bool
  is_parameter( const std::string &line, std::string &name, std::string &value ) {
    std::string::size_type pos;
    if( (pos = line.find(config_separator)) != std::string::npos ) {
      name = strip( line.substr(0, pos) );
      value = strip( line.substr(pos+1) );
      return true;
    }

    return false;
  }


  static
  bool
  is_valid_name( const std::string &name ) {
    return name.find_first_not_of(config_name) == std::string::npos;
  }


  static
  bool
  is_valid_section_name( const std::string &section ) {
    return is_valid_name( section );
  }


  static
  bool
  is_valid_parameter_name( const std::string &name ) {
    return is_valid_name( name );
  }

}



void
Configuration::clear() {
  values_.clear();
}


bool
Configuration::has( const std::string &section ) const {
  if( values_.find(section) == values_.end() )
    return false;

  return true;
}


bool
Configuration::has( const std::string &section, const std::string &name ) const {
  values_t::const_iterator it;

  if( (it = values_.find(section)) == values_.end() )
    return false;

  if( it->second.find(name) == it->second.end() )
    return false;

  return true;
}


void
Configuration::import( std::istream &input ) {
  boost::optional<std::string> current_section;

  unsigned lineno;
  std::string line;

  std::map<std::string, std::set<std::string> > parameters;

  try {
    for( lineno = 1; std::getline(input, line); ++lineno ) {
      // Remove leading and trailing whitespace.
      line = detail::strip( line );

      if( detail::is_blank(line) || detail::is_comment(line) ) {
        // Ignore comments and blank lines.
        continue;
      }

      std::string section;
      std::string name, value;

      if( detail::is_section(line, section) ) {
        if( !detail::is_valid_section_name(section) )
          BOOST_THROW_EXCEPTION( ConfigInvalidSectionNameError() << errinfo_config_section(section) );

        if( parameters.find(section) != parameters.end() )
          BOOST_THROW_EXCEPTION( ConfigSectionRedefinedError() << errinfo_config_section(section) );

        // Section "marker".
        parameters[section];

        current_section = section;
      }
      else if( detail::is_parameter(line, name, value) ) {
        if( !current_section )
          BOOST_THROW_EXCEPTION( ConfigLoneParameterError() << errinfo_config_parameter(name) );

        if( !detail::is_valid_parameter_name(name) ) {
          BOOST_THROW_EXCEPTION( ConfigInvalidParameterNameError()
                                 << errinfo_config_section(*current_section) << errinfo_config_parameter(name) );
        }

        std::map<std::string, std::set<std::string> >::iterator it;
        it = parameters.find( *current_section );
        assert( it != parameters.end() );

        if( it->second.find(name) != it->second.end() ) {
          BOOST_THROW_EXCEPTION( ConfigParameterRedefinedError()
                                 << errinfo_config_section(*current_section) << errinfo_config_parameter(name) );
        }

        // Parameter "marker".
        it->second.insert( name );

        put( *current_section, name, value );
      }
      else
        BOOST_THROW_EXCEPTION( ConfigLoneLineError() );
    }
  }
  catch( boost::exception &e ) {
    e << errinfo_config_line(lineno);
    throw;
  }
}


void
Configuration::import( const std::string &filename ) {
  try {
    std::ifstream file( filename.c_str() );
    if( file.fail() )
      BOOST_THROW_EXCEPTION( ConfigImportError() );
    import( file );
  }
  catch( boost::exception &e ) {
    e << errinfo_config_file(filename);
    throw;
  }
}

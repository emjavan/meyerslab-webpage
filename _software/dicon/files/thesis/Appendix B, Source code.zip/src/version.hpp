#ifndef DICON_VERSION_HPP_
#define DICON_VERSION_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief @link ::program_version program_version@endlink variable.
 */
/**
 * @brief Program version.
 *
 * The global @link ::program_version program_version@endlink variable
 * stores  a textual  representation of  the current  program version.
 * Version     identifiers     follow     the    versioning     scheme
 * <em>year</em><code>.</code><em>month</em><code>.</code><em>release</em>,
 * where @e year is the 4-digit year and @e month is the 2-digit month
 * of release,  and @e release is a  non-negative incrementing integer
 * for  situations  where more  than  one  version  of the  system  is
 * released  in  the same  month.   An  exemplary  program version  is
 * <code>2009.12.0</code>.
 */
extern const char program_version[];

#endif //DICON_VERSION_HPP_

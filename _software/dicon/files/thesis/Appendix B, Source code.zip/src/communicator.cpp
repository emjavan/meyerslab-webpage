/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "communicator.hpp"

#include "error.hpp"
#include "file.hpp"
#include <cerrno>
#include <boost/scoped_array.hpp>


namespace detail {

  static
  std::string
  encode_uint32( uint32_t value ) {
    std::string message( 4, char(0) );

    message[0] = char(static_cast<unsigned char>((value >>  0) & 255));
    message[1] = char(static_cast<unsigned char>((value >>  8) & 255));
    message[2] = char(static_cast<unsigned char>((value >> 16) & 255));
    message[3] = char(static_cast<unsigned char>((value >> 24) & 255));

    return message;
  }


  static
  uint32_t
  decode_uint32( const std::string &buffer ) {
    if( buffer.size() != 4 ) {
      BOOST_THROW_EXCEPTION( AssertionError()
                             << errinfo_value<size_t>(buffer.size())
                             << errinfo_expected_value<size_t>(4) );
    }

    return
      (uint32_t(static_cast<unsigned char>(buffer[0])) <<  0) |
      (uint32_t(static_cast<unsigned char>(buffer[1])) <<  8) |
      (uint32_t(static_cast<unsigned char>(buffer[2])) << 16) |
      (uint32_t(static_cast<unsigned char>(buffer[3])) << 24);
  }

}



Communicator::Communicator( int input, int output )
  : input_(input), output_(output)
{
}


Communicator::~Communicator() {
  close( input_ );
  close( output_ );
  // Ignore errors.
}


std::string
Communicator::receive_message() {
  return read( detail::decode_uint32(read(4)) );
}


void
Communicator::send_message( const std::string &message ) {
  write( detail::encode_uint32(message.length()) );
  write( message );
  flush();
}


std::string
Communicator::read( size_t count ) {
  boost::scoped_array<char> buffer( new char[count] );

  size_t done = 0;
  while( done < count ) {
    ssize_t res;
    if( (res = ::read(input_, buffer.get()+done, count-done)) <= 0 ) {
      BOOST_THROW_EXCEPTION( IOReadError() << errinfo_api_function("read")
                             << errinfo_errno(errno) << errinfo_file_descriptor(input_) );
    }

    assert( size_t(res) <= count-done );

    done += size_t(res);
  }

  return std::string( buffer.get(), count );
}


void
Communicator::write( const std::string &buffer ) {
  const size_t count = buffer.size();

  size_t done = 0;
  while( done < count ) {
    ssize_t res;
    if( (res = ::write(output_, buffer.c_str()+done, count-done)) <= 0 ) {
      BOOST_THROW_EXCEPTION( IOWriteError() << errinfo_api_function("write")
                             << errinfo_errno(errno) << errinfo_file_descriptor(output_) );
    }

    assert( size_t(res) <= count-done );

    done += size_t(res);
  }
}


void
Communicator::flush() {
  if( ::fsync(output_) != 0 && errno != EINVAL ) {
    BOOST_THROW_EXCEPTION( IOError() << errinfo_api_function("fsync")
                           << errinfo_errno(errno) << errinfo_file_descriptor(output_) );
  }
}

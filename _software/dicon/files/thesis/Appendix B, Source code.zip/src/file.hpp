#ifndef DICON_FILE_HPP_
#define DICON_FILE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief File class.
 */
#include "error.hpp"
#include <boost/filesystem/path.hpp>
#include <boost/noncopyable.hpp>
#include <boost/version.hpp>
#include <fcntl.h>
#include <string>


#if BOOST_VERSION >= 104000
using boost::errinfo_at_line;
using boost::errinfo_file_name;
#else
DICON_ERRINFO( at_line, int );
DICON_ERRINFO( file_name, std::string );
#endif

/// Errinfo storing the second filename.
DICON_ERRINFO( file_name_2, std::string );
/// Errinfo storing the file flags.
DICON_ERRINFO( file_flags , int         );
/// Errinfo storing the file mode.
DICON_ERRINFO( file_mode  , mode_t      );

/// Errinfo storing the file descriptor.
DICON_ERRINFO( file_descriptor  , int );
/// Errinfo storing the second file descriptor.
DICON_ERRINFO( file_descriptor_2, int );


/// Convert errinfo_file_flags to string.
std::string to_string( const errinfo_file_flags::errinfo_t &file_flags );
/// Convert errinfo_file_mode to string.
std::string to_string( const errinfo_file_mode::errinfo_t &file_mode );


/// %File or file system related error.
struct FileError : virtual IOError
{ virtual const char *what() const throw() { return "File or file system related error."; } };

/// Unix pipeline related error.
struct PipeError : virtual IOError
{ virtual const char *what() const throw() { return "Unix pipeline related error."; } };

/// Directory related error.
struct DirectoryError : virtual IOError
{ virtual const char *what() const throw() { return "Directory related error."; } };

/// %Redirector related error.
struct RedirectorError : virtual IOError
{ virtual const char *what() const throw() { return "Redirector related error."; } };


/// Read failed while operating on file.
struct FileReadError : public virtual IOReadError, public virtual FileError
{ virtual const char *what() const throw() { return "Read failed while operating on file."; } };

/// Write failed while operating on file.
struct FileWriteError : public virtual IOWriteError, public virtual FileError
{ virtual const char *what() const throw() { return "Write failed while operating on file."; } };


/// %File exists.
struct FileExistsError : virtual FileError
{ virtual const char *what() const throw() { return "File exists."; } };

/// Failed to open file.
struct FileOpenError : virtual FileError
{ virtual const char *what() const throw() { return "Failed to open file."; } };

/// Failed to create file.
struct FileCreateError : virtual FileError
{ virtual const char *what() const throw() { return "Failed to create file."; } };

/// Failed to rename file.
struct FileRenameError : virtual FileError
{ virtual const char *what() const throw() { return "Failed to rename file."; } };


/// %File not owned anymore.
struct FileNotOwnedError : virtual FileError
{ virtual const char *what() const throw() { return "File not owned anymore."; } };


/**
 * @brief %File access and file related operations.
 *
 * The File  class provides access  to a Unix  file.  The file  can be
 * opened for reading, writing,  or read/write access, just like using
 * the normal @c  open system call. In fact, the @e  flags and @e mode
 * parameters in the constructor of File are exactly equivalent to the
 * system call's respective parameters.
 *
 * Objects of the File class can be copied (by copy construction or by
 * assignment).   These  copies   share  the   same   underlying  file
 * descriptor. When the  last copy of a File  object is destroyed, the
 * underlying file descriptor is closed.
 *
 * In addition to opening  named files, several static methods provide
 * helper  functionality,   such  as  changing   the  current  working
 * directory,  checking  if a  file  exists,  renaming files,  getting
 * unique or temporary filenames, etc.
 */
class File {
public:
  /// Default file flags used in the constructor.
  static const int default_flags = O_RDONLY;
  /// Default file mode used in the constructor.
  static const mode_t default_mode = (S_IRUSR | S_IWUSR) | (S_IRGRP | S_IWGRP) | (S_IROTH | S_IWOTH);

  /**
   * @brief Open named file.
   *
   * Constructor that  opens the named  file given by @e  filename for
   * reading, writing, or read/write access. The exact mode depends on
   * the parameter  @e flags.  In case  the file is to  be created (@e
   * flags contains  @c O_CREAT), the parameter @e  mode describes the
   * permissions to use in case the file has to be created.
   *
   * If the  file is to be  created (as indicated by  @c O_CREAT), any
   * directories  leading to  the file  specified by  @e  filename are
   * automatically created as well.
   *
   * @param filename Filename.
   * @param flags %File flags (see @c open system call).
   * @param mode %File mode (see @c open system call).
   * @throws FileOpenError when  the file could not be  opened (and @e
   *   flags does not contain @c O_CREAT).
   * @throws FileCreateError  when the file could not  be created (and
   *    @e flags contains @c O_CREAT but not @c O_EXCL).
   * @throws  FileExistsError when  the  file already  exists (and  @e
   *   flags contains both @c O_CREAT and @c O_EXCL flags).
   */
  File( const boost::filesystem::path &filename, int flags = O_RDONLY, mode_t mode = 0 );

public:
  /**
   * @brief Change working directory.
   *
   * Change the current working directory to the directory given by @e
   * dirname.
   *
   * @param dirname Directory name.
   * @throws DirectoryError when the directory could not be changed.
   */
  static void chdir( const boost::filesystem::path &dirname );

public:
  /**
   * @brief Check if file exists.
   *
   * Check if the file or directory given by @e path exists. This call
   * is guaranteed to not throw an exception.
   *
   * @param path %File or directory name.
   * @returns true iff the file or directory exists.
   */
  static bool exists( const boost::filesystem::path &path ) throw();
  /**
   * @brief Rename file.
   *
   * Rename the file or directory given by @e old_path to the new name
   * given by @e new_path. If  neither @e old_path nor @e new_path are
   * directories and the target already exists, it will be overwritten
   * without throwing  an exception.  This  can be used  to atomically
   * replace files in place.
   *
   * @param old_path Old file or directory name.
   * @param new_path New file or directory name.
   * @throws FileRenameError  when the file or directory  could not be
   *   renamed.
   */
  static void rename( const boost::filesystem::path &old_path, const boost::filesystem::path &new_path );

public:
  /// Default file flags used in unique(), unique_name(), unique_temporary().
  static const int default_flags_unique = O_WRONLY | O_APPEND | O_CREAT | O_EXCL;
  /// Default file mode used in unique(), unique_name(), unique_temporary().
  static const mode_t default_mode_unique = default_mode;

  /**
   * @brief Create file with unique name.
   *
   * Create a new  File object representing a file  with a unique name
   * that is not yet in use. If the file given by @e filename does not
   * exist,  it   will  be  used   without  modification.   Otherwise,
   * increasing  suffixes of the  form <code>.[number]</code>  will be
   * added to the filename until an available filename is found (e.g.,
   * if @e filename is <code>file.txt</code> and a file with this name
   * already   exists,   the   function   will   try   the   filenames
   * <code>file.txt.1</code>,  <code>file.txt.2</code>,  etc. until  a
   * free filename is found).
   *
   * As with File(), this  function creates all missing directories in
   * @e filename when a new file is created.
   *
   * @note   @e  flags  should   contain  both   @c  O_CREAT   and  @c
   * O_EXCL. Otherwise, this  function will not be able  to check if a
   * file already exists and might overwrite an existing file or throw
   * an unexpected exception.
   *
   * @param filename Filename, or filename prefix in case file already
   *   exists.
   * @param  flags %File  flags (see  @c  open system  call), with  @c
   *   O_CREAT, @c O_EXCL.
   * @param mode %File mode (see @c open system call).
   * @returns File object representing the newly created file.
   * @throws FileOpenError when  the file could not be  opened (and @e
   *   flags does not contain @c O_CREAT).
   * @throws FileCreateError  when the file could not  be created (and
   *    @e flags contains @c O_CREAT but not @c O_EXCL).
   */
  static File unique( const boost::filesystem::path &filename,
                      int flags = default_flags_unique, mode_t mode = default_mode_unique );

  /**
   * @brief Create unique file and get name.
   *
   * Create a  unique file  and return its  name.  This is  similar to
   * unique()  but directly  returns the  filename instead  of  a File
   * object to the newly created, unique file. This call still creates
   * the file so that future calls will not return the same filename.
   *
   * @see unique().
   *
   * @param filename Filename, or filename prefix in case file already
   *   exists.
   * @param  flags %File  flags (see  @c  open system  call), with  @c
   *   O_CREAT, @c O_EXCL.
   * @param mode %File mode (see @c open system call).
   * @returns File object representing the newly created file.
   * @throws FileOpenError when  the file could not be  opened (and @e
   *   flags does not contain @c O_CREAT).
   * @throws FileCreateError  when the file could not  be created (and
   *    @e flags contains @c O_CREAT but not @c O_EXCL).
   */
  static boost::filesystem::path unique_name( const boost::filesystem::path &filename,
                                              int flags = default_flags_unique, mode_t mode = default_mode_unique );

  /**
   * @brief Create unique temporary file and get name.
   *
   * Create a unique  file and return its name. The  name of the newly
   * created file is  derived from @e filename by  applying a template
   * of the form <code>.[filename]_tmp</code>  to the filename part of
   * @e  filename, i.e., any  leading directories  are kept  the same.
   * Apart from  the filename mangling, this  function behaves exactly
   * as  unique_name(), i.e.,  as long  as @e  flags contains  both @c
   * O_CREAT and @c O_EXCL, a  unique filename is returned, applying a
   * suffix  of   the  form  <code>.[number]</code>   to  the  mangled
   * filename.
   *
   * As the name  suggests this function can be  used to create unique
   * temporary file  names, e.g., when  first writing data to  a file,
   * and then renaming this temporary  file to the final name when all
   * data has been written.
   *
   * @see unique_name().
   *
   * @param  filename  Base  filename  used to  derive  the  temporary
   *   filename.
   * @param  flags %File  flags (see  @c  open system  call), with  @c
   *   O_CREAT, @c O_EXCL.
   * @param mode %File mode (see @c open system call).
   * @returns File object representing the newly created file.
   * @throws FileOpenError when  the file could not be  opened (and @e
   *   flags does not contain @c O_CREAT).
   * @throws FileCreateError  when the file could not  be created (and
   *    @e flags contains @c O_CREAT but not @c O_EXCL).
   */
  static boost::filesystem::path unique_temporary( const boost::filesystem::path &filename,
                                                   int flags = default_flags_unique, mode_t mode = default_mode_unique );

public:
  /**
   * @brief Get file descriptor.
   *
   * Get the  underlying Unix file descriptor to  the file represented
   * by this File  object. This call does not  change ownership to the
   * file descriptor.
   *
   * @see file(bool).
   *
   * @returns File descriptor.
   * @throws FileNotOwnedError  when this File  object does not  own a
   *   file anymore.
   */
  int file() const;
  /**
   * @brief Get file descriptor, possibly taking ownership.
   *
   * Get the  underlying Unix file descriptor to  the file represented
   * by this  File object. If @e  take_ownership is @c  true, then the
   * object (and all copies of  the object) will lose ownership of the
   * file, i.e., the underlying file  will not be closed when the last
   * copy of the object is  destroyed; also, future calls to file() or
   * file(bool) will throw an exception.
   *
   * @param take_ownership  Set to @c  true when caller wants  to take
   *   ownership of file.
   * @returns File descriptor.
   * @throws FileNotOwnedError  when this File  object does not  own a
   *   file anymore.
   */
  int file( bool take_ownership = false );

  /**
   * @brief Get filename.
   *
   * Get  the filename  of  this  object. This  is  equivalent to  the
   * filename originally specified when  creating the object using the
   * constructor,  or  the  filename  finally settled  on  when  using
   * unique().
   *
   * @returns Filename.
   */
  boost::filesystem::path filename() const;

private:
  struct Data
    : boost::noncopyable
  {
    Data( const boost::filesystem::path &filename );
    ~Data();

    int filefd;
    bool owned;
    boost::filesystem::path filename;
  };

  boost::shared_ptr<Data> data_;
};

#endif //DICON_FILE_HPP_

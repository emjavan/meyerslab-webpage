#ifndef DICON_OPTIMIZER_HPP_
#define DICON_OPTIMIZER_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Optimizer class.
 */
#include "library.hpp"
#include "redirect.hpp"
#include "simulator.hpp"
#include <boost/bimap.hpp>


/**
 * @brief %Optimizer library calls.
 *
 * The   optimizer  namespace  contains   type  definitions   for  all
 * %optimizer related calls.  An %optimizer  library to be used by the
 * system must  implement the following  functions and export  them by
 * the following symbol names.
 *
 * - @c initialize(): see @link initialize_t() initialize_t@endlink.
 * - @c get_policy(): see @link get_policy_t() get_policy_t@endlink.
 * - @c update(): see @link update_t() update_t@endlink.
 * - @c policies(): see @link policies_t() policies_t@endlink.
 * - @c dump_state(): see @link dump_state_t() dump_state_t@endlink.
 * - @c get_error(): see @link get_error_t() get_error_t@endlink.
 *
 * Some  of these  functions must  return data  of arbitrary  size (@c
 * get_policy(),  @c  policies())  where  the caller  cannot  know  in
 * advance how  much data  to expect. In  these cases,  the %optimizer
 * library must provide the required memory space and return a pointer
 * to that  data, which is typically  a 0-terminated list  of nodes in
 * the  policy tree.   The  %optimizer wrapper  is  guaranteed not  to
 * modify this  memory, as  indicated by the  @c const  specifier. The
 * same  applies  to  the  @c  children()  callback  exported  by  the
 * %optimizer  wrapper: it  will return  the children  list  through a
 * pointer to memory that is owned by the %optimizer wrapper; in turn,
 * the %optimizer library guarantees not to modify this memory.
 *
 * All functions except @c get_error()  return an @c int return value.
 * This value is 0 if and only if the call was successful.  Errors are
 * indicated by return values other than 0. In this case, the function
 * @c  get_error() can be  used to  get a  textual description  of the
 * actual error.
 *
 * @see Optimizer class, Simulator class.
 */
namespace optimizer {

  /**
   * @brief Policy node.
   *
   * Policy  node  used by  the  %optimizer  library.  The  %optimizer
   * library works  only on @c int  nodes which are  translated by the
   * %optimizer  wrapper  to the  actual  values  as  returned by  the
   * simulator's @c  children() callback.   Lists of policy  nodes (as
   * used  by  @c  get_policy(),   @c  update(),  @c  policies())  are
   * 0-terminated;  regular node values  are positive  integers within
   * the range  of the @c  int type (on  the platform used  to compile
   * both the system and the %optimizer library).
   */
  typedef int node_t;

  extern "C" {
    /**
     * @brief Children callback.
     *
     * Children callback exported  to the %optimizer on initialization
     * (by the means of  @c initialize()).  The %optimizer library can
     * use this callback  during any call to get  the list of children
     * at  any node in  the policy  tree as  defined by  the simulator
     * program  associated  with  the corresponding  Optimizer  object
     * wrapping this %optimizer library.
     *
     * @param  path 0-terminated path  to node  in policy  tree (empty
     *   path for root node).
     * @param children  0-terminated list  of child nodes  returned by
     *   the %optimizer wrapper.
     */
    typedef int (*children_t)( const node_t *path, const node_t **children );


    /**
     * @brief Initialize %optimizer.
     *
     * Initialize the %optimizer with the given arguments and children
     * callback, optionally  restoring an %optimizer  state previously
     * dumped  with  @c  dump_state().   The  %optimizer  command-line
     * argument array  @e argv contains  as first element the  name of
     * the %optimizer library itself,  i.e., @e argc is always greater
     * than or equal to 1.
     *
     * This function is guaranteed to  be called only once, and before
     * any of the other funtions is called.
     *
     * @param argc Number of elements in @e argv array.
     * @param argv %Optimizer command-line arguments.
     * @param children  @c children() callback  provided by %optimizer
     *   wrapper.
     * @param state_file  If not equal to @c  NULL, restore %optimizer
     *   state from this file.
     *
     * @returns 0 iff the call was successful.
     */
    typedef int (*initialize_t)( int argc, const char *const *argv,
                                 children_t children, const char *state_file     );
    /**
     * @brief  Get next policy from %optimizer.
     *
     * Get  the  next  policy  from the  %optimizer.   The  %optimizer
     * returns in @e policy the  pointer to a 0-terminated policy node
     * list indicating the  next policy, or @c NULL  when no policy is
     * available  at the  moment. If  the latter  is indicated,  a new
     * policy must only become available after at least one call to @c
     * update(), using  one of the policies previously  returned by @c
     * get_policy().  Therefore,  when no policies are  pending and @c
     * get_policy() returns no policy, the end of the optimization job
     * has been reached.
     *
     * @param  policy 0-terminated policy  returned by  the %optimizer
     *   library, or @c NULL.
     *
     * @returns 0 iff the call was successful.
     */
    typedef int (*get_policy_t)( const node_t **policy                           );
    /**
     * @brief Update policy's reward value.
     *
     * Update the reward  value of a policy previously  returned by @c
     * get_policy(). The reward value is always between 0 and 1.
     *
     * This function  is guaranteed  to be called  only once  for each
     * policy returned by @c get_policy().
     *
     * @param policy 0-terminated policy.
     * @param reward Policy's reward value.
     *
     * @returns 0 iff the call was successful.
     */
    typedef int (*update_t    )( const node_t *policy, double reward             );
    /**
     * @brief Get list of best policies.
     *
     * Get the  list of  up to  @e count best  policies, based  on the
     * average reward value of each policy.  The %optimizer library is
     * allowed to return less than  the given number of policies (even
     * none).   The  number of  policies  actually  available will  be
     * returned in @e count, and @e policies will contain a list of @e
     * count  consecutive 0-terminated policies,  and @e  rewards will
     * contain a  list of @e  count consecutive average  reward values
     * for each corresponding policy.
     *
     * This function is guaranteed to  be called only when no policies
     * are  pending, i.e.,  after calling  @c update()  once  for each
     * policy returned by @c get_policy().
     *
     * @param count  Maximum number of  policies to return as  well as
     *   actual number of policies returned.
     * @param  policies  List  of  @e count  consecutive  0-terminated
     *   policies returned by the %optimizer library.
     * @param  rewards  List of  @e  count  consecutive reward  values
     *   returned by the %optimizer library.
     *
     * @returns 0 iff the call was successful.
     */
    typedef int (*policies_t  )( unsigned *count,
                                 const node_t **policies, const double **rewards );
    /**
     * @brief Dump internal %optimizer state.
     *
     * Dump  the  %optimizer's  internal  state,  so that  it  can  be
     * completely restored  by a later call to  @c initialize(). There
     * are no restrictions on the file format used.
     *
     * This function is guaranteed to  be called only when no policies
     * are  pending, i.e.,  after calling  @c update()  once  for each
     * policy returned by @c get_policy().
     *
     * @param filename Name of dump file to create.
     *
     * @returns 0 iff the call was successful.
     */
    typedef int (*dump_state_t)( const char *filename                            );

    /**
     * @brief Get description of last error.
     *
     * Get a textual description of the last error.
     *
     * This  function is  guaranteed  to be  called  only right  after
     * another  function  indicated  an  error by  returning  a  value
     * different from 0.
     *
     * @returns Textual description of the last error.
     */
    typedef const char * (*get_error_t)();
  }

}


/// Errinfo storing slave error %message.
DICON_ERRINFO( slave_error, std::string );


/// %Optimizer related error.
struct OptimizerError : virtual Error
{ virtual const char *what() const throw() { return "Optimizer related error."; } };

/// Policy node related error in %optimizer.
struct OptimizerNodeError : virtual OptimizerError
{ virtual const char *what() const throw() { return "Policy node related error in optimizer."; } };

/// Policy node not in %optimizer's translation table.
struct OptimizerUnknownNodeError : virtual OptimizerNodeError
{ virtual const char *what() const throw() { return "Policy node not in optimizer's translation table."; } };

/// Reached node limit in %optimizer's translation table.
struct OptimizerTooManyNodesError : virtual OptimizerNodeError
{ virtual const char *what() const throw() { return "Reached node limit in optimizer's translation table."; } };


/// Calling %optimizer function failed.
struct OptimizerSlaveError : virtual OptimizerError
{ virtual const char *what() const throw() { return "Calling optimizer function failed."; } };

/// Calling %optimizer's initialize() failed.
struct OptimizerInitializeError : virtual OptimizerSlaveError
{ virtual const char *what() const throw() { return "Calling optimizer's initialize() failed."; } };

/// Calling %optimizer's get_policy() failed.
struct OptimizerGetPolicyError : virtual OptimizerSlaveError
{ virtual const char *what() const throw() { return "Calling optimizer's get_policy() failed."; } };

/// Calling %optimizer's update() failed.
struct OptimizerUpdateError : virtual OptimizerSlaveError
{ virtual const char *what() const throw() { return "Calling optimizer's update() failed."; } };

/// Calling %optimizer's policies() failed.
struct OptimizerPoliciesError : virtual OptimizerSlaveError
{ virtual const char *what() const throw() { return "Calling optimizer's policies() failed."; } };

/// Calling %optimizer's dump_state() failed.
struct OptimizerDumpStateError : virtual OptimizerSlaveError
{ virtual const char *what() const throw() { return "Calling optimizer's dump_state() failed."; } };


class Combined;

namespace detail {
  extern "C" int optimizer_children( const optimizer::node_t *, const optimizer::node_t ** );
}

/**
 * @brief %Optimizer wrapper.
 *
 * The  Optimizer  class wraps  an  %optimizer  library.  It  provides
 * translation  between  the policies  returned  by  a simulator's  @c
 * children()  callback to  @c  int values  used  by the  optimization
 * algorithm  defined  in the  wrapped  %optimizer  library.  It  also
 * handles  wrapping and  unwrapping  of  C++ lists  to  C arrays  and
 * provides the necessary memory management.
 *
 * The  %optimizer  library  must  export  symbols  as  shown  in  the
 * description of the optimizer namespace.
 *
 * @note Only a  single Optimizer instance is allowed  to exist at any
 *   time.   If  another  instance  is  created  before  the  previous
 *   instance  is destroyed,  the constructor  of the  second instance
 *   will fail.
 */
class Optimizer
  : boost::noncopyable
{
  friend class Combined;
  friend int detail::optimizer_children( const optimizer::node_t *, const optimizer::node_t ** );

public:
  /**
   * @brief Load %optimizer library and simulator.
   *
   * Constructor  that initializes  the given  %optimizer  library and
   * simulator.  The  simulator is  used exclusively for  querying the
   * policy space through the simulator's @c children() callback. Both
   * %optimizer and  simulator may  have logfiles associated  that are
   * used to record messages written to standard error output (in case
   * of  the  %optimizer, also  standard  output)  by both  %optimizer
   * library and simulator program.
   *
   * If   either  logfile   given  by   @e  optimizer_logfile   or  @e
   * simulator_logfile exits,  it will not be  overwritten. Instead, a
   * new  name  that  does  not  exist will  be  chosen  according  to
   * File::unique().
   *
   * Both %optimizer library arguments and simulator command arguments
   * should contain only the actual arguments, without the name of the
   * library or program as first argument.
   *
   * @param optimizer_logfile  Logfile to record  %optimizer library's
   *   output to standard output/error (or empty path for no logging).
   * @param  simulator_logfile Logfile  to record  simulator program's
   *   output to standard error (or empty path for no logging).
   * @param optimizer_library Path to %optimizer library.
   * @param optimizer_arguments %Optimizer library arguments.
   * @param simulator_command Path to simulator command.
   * @param simulator_arguments %Simulator command arguments.
   * @param optimizer_map_file Path to %optimizer map dump file (empty
   *   if %optimizer map state should not be restored).
   * @param optimizer_lib_file Path to %optimizer lib dump file (empty
   *   if %optimizer lib state should not be restored).
   *
   * @throws  LibraryOpenError when the  %optimizer library  cannot be
   *   opened.
   * @throws  LibrarySymbolError  when not  all  required symbols  are
   *   exported by the %optimizer library.
   * @throws AssertionError  when another Optimizer  instance still
   *   exists.
   * @throws  RedirectorError  when  the  %optimizer  library  logfile
   *   cannot be setup.
   * @throws FileReadError when the %optimizer map dump file cannot be
   *   read.
   * @throws OptimizerInitializeError when initializing the %optimizer
   *   library (@c initialize()) failed.
   */
  Optimizer( const boost::filesystem::path &optimizer_logfile
           , const boost::filesystem::path &simulator_logfile
           , const std::string &optimizer_library, const arguments_t &optimizer_arguments
           , const std::string &simulator_command, const arguments_t &simulator_arguments
           , const boost::optional<boost::filesystem::path> &optimizer_map_file
           , const boost::optional<boost::filesystem::path> &optimizer_lib_file
           );
  /**
   * @brief Free %optimizer library and simulator.
   *
   * Destructor  that  frees  the  %optimizer  library  and  simulator
   * program. This releases all resources and closes the logfiles used
   * for %optimzier and simulator output
   */
  ~Optimizer();

public:
  /**
   * @brief Get next policy.
   *
   * Get the next available policy  from the %optimizer.  If no policy
   * is available right  now, this is indicated by  returning an empty
   * object.
   *
   * @return Next available policy, or  an empty object when no policy
   *   is available (until update() is called at least once).
   *
   * @throws  OptimizerGetPolicyError when getting  a policy  from the
   *   %optimizer library (<code>%get_policy()</code>) failed.
   */
  boost::optional<policy_t> get_policy();
  /**
   * @brief Update policy's reward.
   *
   * Update the reward value of the given policy. The policy must have
   * been  returned  by a  previous  call  to  get_policy(). For  each
   * policy, update() must only be called once.
   *
   * @param policy Policy.
   * @param reward Reward.
   *
   * @throws AssertionError when no  policy is pending or reward value
   *   is less than 0 or greater than 1.
   * @throws   OptimizerUpdateError  when  updating   policy's  reward
   *   (<code>%update()</code>) in the %optimizer library failed.
   */
  void update( const policy_t &policy, double reward );

  /**
   * @brief Dump %optimizer map state.
   *
   * Dump  the  %optimizer's  one-to-one  correspondence  map  between
   * policies returned  by the simulator's @c  children() callback and
   * the @c  int values handed over  to the %optimizer  library.  If a
   * file with the given name  already exists, it will be overwritten.
   * This method must only be called when no policies are pending.
   *
   * @param file Filename of the map dump file.
   *
   * @throws AssertionError when at least one policy is pending.
   * @throws FileWriteError  when writing  to the %optimizer  map dump
   *   file failed.
   */
  void dump_optimizer_map( const boost::filesystem::path &file );
  /**
   * @brief Dump %optimizer lib state.
   *
   * Dump the %optimizer library's internal  state. If a file with the
   * given name already exists, it will be overwritten. This must only
   * be called when no policies are pending.
   *
   * @param file Filename of the lib dump file.
   *
   * @throws AssertionError when at least one policy is pending.
   * @throws  OptimizerDumpStateError   when  dumping  the  %optimizer
   *   library's internal state (<code>%dump_state()</code>) failed.
   *
   */
  void dump_optimizer_lib( const boost::filesystem::path &file );
  /**
   * @brief Dump list of best policies.
   *
   * Dump the list  of up to @e count best policies,  as given by each
   * policy's  average  reward value.   The  %optimizer library  might
   * decide to dump less than  @e count policies (even none). The dump
   * can either by  textual or binary, where binary  output means that
   * policies are  dumped as they  are returned by the  simulator's @c
   * children()  callback, as a  list of  nodes describing  the actual
   * policy  path,  whereas textual  output  uses  the simulator's  @c
   * display() callback  to create a  human-readable representation of
   * each policy.
   *
   * In both  cases the dump file  will contain two  lines per policy,
   * with  the  average  reward  followed  by  a  description  of  the
   * policy. This description is either an escaped version of the text
   * returned  by   the  simulator's  @c  display()   callback,  or  a
   * comma-separated list of  the raw policy nodes as  returned by the
   * simulator's @c children() callback, also escaped.
   *
   * The  escape  method  used  is  similar  to  the  quoted-printable
   * encoding;  see the  description of  the qp_encode()  function for
   * details.
   *
   * An example (binary) policy dump might look like the following.
   *
   * @verbatim
0.960000000000
=80=02K=04.,=80=02K=04.
@endverbatim
   *
   * Here, a single policy was dumped, with an average reward value of
   * 0.96.   The policy  is described  by a  path of  length 2  in the
   * policy  tree,  where  each  path  element is  equivalent  to  the
   * 5-character string given as hexadecimal <code>0x80 0x02 0x4b 0x04
   * 0x2e</code>. It is up to the simulator what this means. A textual
   * dump  of the  same policy  (taken at  the same  %optimizer state)
   * looked like the following.
   *
   * @verbatim
0.960000000000
[4, 4]
@endverbatim
   *
   * Here,  the entire text  <code>[4, 4]</code>  was returned  by the
   * simulator's @c display() callback.  As all the characters in this
   * string are printable, escaping was not necessary.
   *
   * This method must only be called when no policies are pending.
   *
   * @param file Name of dump file to create.
   * @param count Maximum number of policies to dump.
   * @param display @c true iff textual dump output is to be used.
   *
   * @throws AssertionError when at least one policy is pending.
   * @throws  FileWriteError when  writing to  the policies  dump file
   *   failed.
   * @throws OptimizerPoliciesError when  getting the list of policies
   *   from the %optimizer library (<code>%policies()</code>) failed.
   */
  void dump_policies( const boost::filesystem::path &file, unsigned count, bool display );

private:
  void initialize( const std::string &name, const arguments_t &arguments,
                   optimizer::children_t children, const boost::optional<boost::filesystem::path> &state_file );

private:
  void children_c( const optimizer::node_t *path, const optimizer::node_t **children );

  typedef std::vector<std::pair<policy_t, double> > policies_result_type;

  policies_result_type policies( unsigned count );

  template< typename T >
  void load_symbol( T &variable, const std::string &symbol );

  policy_t id_to_name( const optimizer::node_t *list );
  const optimizer::node_t *name_to_id( const policy_t &policy );

private:
  Simulator &simulator();

private:
  DynamicLibrary library_;
  Simulator simulator_;

  typedef unsigned policy_count_t;
  policy_count_t policy_count_;

  boost::scoped_ptr<Redirector> stdout_;
  boost::scoped_ptr<Redirector> stderr_;

  optimizer::initialize_t initialize_;
  optimizer::get_policy_t get_policy_;
  optimizer::update_t     update_;
  optimizer::policies_t   policies_;
  optimizer::dump_state_t dump_state_;
  optimizer::get_error_t  get_error_;

  std::vector<optimizer::node_t> temporary_;

private:
  void load_state( std::istream &in );
  void save_state( std::ostream &out );

  void load_state( const std::string &file );
  void save_state( const std::string &file );

  struct id {};
  struct name {};

  typedef boost::bimap< boost::bimaps::tagged<std::string      , name>
                      , boost::bimaps::tagged<optimizer::node_t, id  >
                      > nodes_t;
  nodes_t nodes_;
};


/**
 * @brief %Combined %optimizer/simulator wrapper.
 *
 * The  Combined  class wraps  both  an  %optimizer  and a  simulator.
 * Similar to the Optimizer  class it provides translation between the
 * policies returned by a simulator's @c children() callback to @c int
 * values used  by the optimization  algorithm defined in  the wrapped
 * %optimizer library.
 *
 * In contrast to the  regular %optimizer and simulator interfaces, it
 * provides only a  single method to take a %step,  i.e., get a policy
 * from  the   embedded  %optimizer,  simulate  it   in  the  embedded
 * simulator, and  update the reward value  accordingly.  In addition,
 * only the regular @c dump_ methods are supported.
 */
class Combined
  : boost::noncopyable
{
public:
  /**
   * @brief Load optimizer library and simulator.
   *
   * Constructor  that initializes  the given  %optimizer  library and
   * simulator.  The  simulator is used  both for querying  the policy
   * space  through the  simulator's @c  children() callback,  and for
   * simulating  policies   through  the  simulator's   @c  simulate()
   * callback.   Both  %optimizer  and  simulator  may  have  logfiles
   * associated that  are used to record messages  written to standard
   * error output (in case of the %optimizer, also standard output) by
   * both %optimizer library and simulator program.
   *
   * If   either  logfile   given  by   @e  optimizer_logfile   or  @e
   * simulator_logfile exits,  it will not be  overwritten. Instead, a
   * new  name  that  does  not  exist will  be  chosen  according  to
   * File::unique().
   *
   * Both %optimizer library arguments and simulator command arguments
   * should contain only the actual arguments, without the name of the
   * library or program as first argument.
   *
   * @param optimizer_logfile  Logfile to record  %optimizer library's
   *   output to standard output/error (or empty path for no logging).
   * @param  simulator_logfile Logfile  to record  simulator program's
   *   output to standard error (or empty path for no logging).
   * @param optimizer_library Path to %optimizer library.
   * @param optimizer_arguments %Optimizer library arguments.
   * @param simulator_command Path to simulator command.
   * @param simulator_arguments %Simulator command arguments.
   * @param optimizer_map_file Path to %optimizer map dump file (empty
   *   if %optimizer map state should not be restored).
   * @param optimizer_lib_file Path to %optimizer lib dump file (empty
   *   if %optimizer lib state should not be restored).
   *
   * @throws  LibraryOpenError when the  %optimizer library  cannot be
   *   opened.
   * @throws  LibrarySymbolError  when not  all  required symbols  are
   *   exported by the %optimizer library.
   * @throws AssertionError  when another Optimizer  instance still
   *   exists.
   * @throws  RedirectorError  when  the  %optimizer  library  logfile
   *   cannot be setup.
   * @throws FileReadError when the %optimizer map dump file cannot be
   *   read.
   * @throws OptimizerInitializeError when initializing the %optimizer
   *   library (@c initialize()) failed.
   */
  Combined( const boost::filesystem::path &optimizer_logfile
          , const boost::filesystem::path &simulator_logfile
          , const std::string &optimizer_library, const arguments_t &optimizer_arguments
          , const std::string &simulator_command, const arguments_t &simulator_arguments
          , const boost::optional<boost::filesystem::path> &optimizer_map_file
          , const boost::optional<boost::filesystem::path> &optimizer_lib_file
          );

public:
  /**
   * @brief Dump %optimizer map state.
   *
   * @see Optimizer::dump_optimizer_map().
   */
  void dump_optimizer_map( const boost::filesystem::path &file );
  /**
   * @brief Dump %optimizer lib state.
   *
   * @see Optimizer::dump_optimizer_lib().
   */
  void dump_optimizer_lib( const boost::filesystem::path &file );
  /**
   * @brief Dump list of best policies.
   *
   * @see Optimizer::dump_policies().
   */
  void dump_policies( const boost::filesystem::path &file, unsigned count, bool display );

public:
  /**
   * @brief Take step in node.
   *
   * Take another step in the combined %optimizer/simulator node. This
   * will  try to  get  a  new policy  from  the embedded  %optimizer,
   * simulate it  using the embedded simulator, and  update the return
   * value  at the  %optimizer  accordingly.  This  method returns  @c
   * false if and only if no policy is available from the %optimizer.
   *
   * @returns @c true iff a next method was available.
   *
   * @throws  OptimizerGetPolicyError when getting  a policy  from the
   *   %optimizer library (<code>%get_policy()</code>) failed.
   * @throws  SimulatorSimulateError  when  simulating the  policy  in
   *   simulator (<code>%simulate()</code>) failed.
   * @throws  SimulatorInvalidRewardError when  the  reward value  was
   *   less than 0 or greater than 1.
   * @throws   OptimizerUpdateError  when  updating   policy's  reward
   *   (<code>%update()</code>) in the %optimizer library failed.
   */
  bool step();

private:
  Optimizer optimizer_;
};

#endif //DICON_OPTIMIZER_HPP_

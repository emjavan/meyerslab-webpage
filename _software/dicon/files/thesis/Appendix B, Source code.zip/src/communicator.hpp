#ifndef DICON_COMMUNICATOR_HPP_
#define DICON_COMMUNICATOR_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Communicator class.
 */
#include <boost/noncopyable.hpp>
#include <string>


/**
 * @brief Message-based communication.
 *
 * The  Communicator  class  provides a  %message-based  communication
 * channel.   This channel  can be  created on  top of  arbitrary file
 * descriptors,  e.g.,  standard  input   and  output,  files  in  the
 * filesystem,  network sockets,  etc.   Each %message  sent over  the
 * communication channel is encoded by  first giving the length of the
 * %message, followed  by the %message  itself. The length  is encoded
 * using little-endian encoding of  a 32-bit unsigned integer within 4
 * bytes.  The  %message is  sent as-is, using  exactly the  number of
 * bytes  given by  the  encoded %message  length.   For example,  the
 * %message  <code>Hello,  World!</code>   (13  characters)  would  be
 * transmitted as follows.
 *
 * @verbatim
|  0x0d 0x00 0x00 0x00  |  0x48 0x65 0x6c 0x6c 0x6f 0x2c 0x20 0x57 0x6f 0x72 0x6c 0x64 0x21  |
|    13    0    0    0  |    72  101  108  108  111   44   32   87  111  114  108  100   33  |
|                   13  |   'H'  'e'  'l'  'l'  'o'  ','  ' '  'W'  'o'  'r'  'l'  'd'  '!'  |
@endverbatim
 *
 * As the  length of  each %message is  given explicitly, there  is no
 * need  for  any special  separator  character.  Therefore,  multiple
 * messages are  sent immediately one  after the other, with  no extra
 * padding in-between.
 */
class Communicator
  : boost::noncopyable
{
public:
  /**
   * @brief Create communicator on top of pair of file descriptors.
   *
   * Constructor that creates a  new communicator with the given input
   * and output file descriptors. The communicator will read from file
   * descriptor @e input and write to file descriptor @e output. After
   * creation, the  communicator owns the file  descriptors and closes
   * them when shutting down.
   *
   * @param input Input file descriptor.
   * @param output Output file descriptor.
   */
  Communicator( int input, int output );
  /**
   * @brief Shutdown communicator.
   *
   * Destructor that  shuts down  the communicator.  This  also closes
   * all associated file descriptors.
   */
  ~Communicator();

public:
  /**
   * @brief Receive %message.
   *
   * Receive the  next %message  from the communication  channel. This
   * call blocks until an entire %message is received.
   *
   * @return Received %message.
   * @throws IOReadError when not enough data could be read.
   */
  std::string receive_message();
  /**
   * @brief Send %message.
   *
   * Send a  %message to the  communication channel. This  call blocks
   * until the  entire %message given  by @e %message is  sent.  After
   * sending the %message this call also flushes the associated output
   * file descriptor.
   *
   * @param message Message to be sent.
   * @throws IOWriteError when not all data could be written.
   */
  void send_message( const std::string &message );

private:
  std::string read( size_t count );
  void write( const std::string &buffer );
  void flush();

private:
  int input_;
  int output_;
};

#endif //DICON_COMMUNICATOR_HPP_

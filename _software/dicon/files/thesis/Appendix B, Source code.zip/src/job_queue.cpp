/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "job_queue.hpp"
#include "specifier.hpp"
#include "config.hpp"
#include "lazy/set/combine.hpp"
#include "lazy/set/empty.hpp"
#include "lazy/set/singleton.hpp"
#include "message.hpp"
#include <boost/foreach.hpp>
#include <boost/format.hpp>
#include <cmath>


namespace detail {

  static const size_t      default_max_jobs         = 1000000;

  static const std::string default_job_dir_mask     = "job-%u";
  static const std::string default_arg_dir_mask     = "argument-%05u";

  static const std::string default_job_logfile      = "job.log";
  static const LogLevel    default_job_log_level    = LOG_INFO;
  static const std::string default_checkpoint_file  = "checkpoint.xml";
  static const std::string default_opt_logfile_mask = "log/optimizer-node_%04u.log";
  static const std::string default_sim_logfile_mask = "log/simulator-node_%04u.log";

  static const std::string default_optimizer_map_file_mask  = "dump/%012u-optmap.bin";
  static const std::string default_optimizer_lib_file_mask  = "dump/%012u-optlib.bin";
  static const std::string default_policy_bin_dumpfile_mask = "dump/%012u-policy.bin";
  static const std::string default_policy_txt_dumpfile_mask = "dump/%012u-policy.txt";

  static const unsigned    default_policy_count      = 10;
  static const std::string default_policy_bin_result = "result-policy.bin";
  static const std::string default_policy_txt_result = "result-policy.txt";

  static const simcount_t  default_max_sims         = 0;
  static const unsigned    default_max_nodes        = 0;
  static const unsigned    default_job_backlog      = 1;
  static const unsigned    default_node_backlog     = 1;

  static const unsigned    default_checkpoint_secs  = 14400;  // 4 hours
  static const unsigned    default_checkpoint_sims  = 0;


  template< typename C, typename T = typename C::value_type >
  struct PushBack {
    typedef C result_type;

    result_type
    operator()( C x, const T &y ) const {
      x.push_back( y );
      return x;
    }
  };


  template< typename T1, typename T2 >
  struct MakePair {
    typedef typename std::pair<T1, T2> result_type;

    result_type
    operator()( const T1 &x, const T2 &y ) const {
      return std::make_pair<T1, T2>( x, y );
    }
  };


  static
  LazySet<arguments_t>::ptr_t
  create_argument_set( const Configuration &configuration,
                       const std::string &section, const std::string &parameter_mask )
  {
    LazySet<arguments_t>::ptr_t args
      = lazy_singleton( arguments_t() );

    std::string parameter;
    for( unsigned parameter_id = 1
       ; parameter = (boost::format(parameter_mask)
                      % parameter_id).str()
       , configuration.has( section, parameter )
       ; ++parameter_id
       )
    {
      try {
        const std::string &argument = configuration.get<std::string>( section, parameter );

        args = lazy_combine( args, parse_argument_specifier(argument), detail::PushBack<arguments_t>() );
      }
      catch( boost::exception &e ) {
        e << errinfo_config_parameter(parameter);
        throw;
      }
    }

    return args;
  }


  static
  LazySet<simcount_t>::ptr_t
  create_checkpoints( const Configuration &configuration,
                      const std::string &section, const std::string &parameter )
  {
    try {
      const std::string &checkpoints = configuration.get<std::string>( section, parameter, std::string() );

      if( checkpoints.empty() )
        return lazy_empty<simcount_t>();
      else
        return parse_schedule_specifier(checkpoints);
    }
    catch( boost::exception &e ) {
      e << errinfo_config_parameter(parameter);
      throw;
    }
  }

}



JobQueue::JobQueue( const Configuration &configuration )
  : job_count_(0), jobs_done_(0)
{
  size_t max_jobs = configuration.get<size_t>( "global", "max_jobs", detail::default_max_jobs );

  job_dir_mask_     = configuration.get<std::string>( "global", "job_dir"      , detail::default_job_dir_mask     );
  arg_dir_mask_     = configuration.get<std::string>( "global", "arg_dir"      , detail::default_arg_dir_mask     );
  job_logfile_      = configuration.get<std::string>( "global", "job_logfile"  , detail::default_job_logfile      );
  job_log_level_    = configuration.get<LogLevel   >( "global", "job_log_level", detail::default_job_log_level    );
  checkpoint_file_  = configuration.get<std::string>( "global", "checkpoint"   , detail::default_checkpoint_file  );
  opt_logfile_mask_ = configuration.get<std::string>( "global", "opt_logfile"  , detail::default_opt_logfile_mask );
  sim_logfile_mask_ = configuration.get<std::string>( "global", "sim_logfile"  , detail::default_sim_logfile_mask );

  optimizer_map_file_mask_  = configuration.get<std::string>( "global", "optimizer_map_file",
                                                              detail::default_optimizer_map_file_mask  );
  optimizer_lib_file_mask_  = configuration.get<std::string>( "global", "optimizer_lib_file",
                                                              detail::default_optimizer_lib_file_mask  );
  policy_bin_dumpfile_mask_ = configuration.get<std::string>( "global", "policy_bin_dumpfile",
                                                              detail::default_policy_bin_dumpfile_mask );
  policy_txt_dumpfile_mask_ = configuration.get<std::string>( "global", "policy_txt_dumpfile",
                                                              detail::default_policy_txt_dumpfile_mask );

  policy_count_      = configuration.get<unsigned   >( "global", "policy_count"     , detail::default_policy_count      );
  policy_bin_result_ = configuration.get<std::string>( "global", "policy_bin_result", detail::default_policy_bin_result );
  policy_txt_result_ = configuration.get<std::string>( "global", "policy_txt_result", detail::default_policy_txt_result );

  std::string section;
  for( unsigned section_id = 1
     ; section = (boost::format("job-%u") % section_id).str()
     , configuration.has( section )
     ; ++section_id
     )
  {
    try {
      Job::ptr_t base_job( new Job() );

      base_job->job_set_id        = section_id;
      base_job->arg_set_id        = 0;

      base_job->max_sims          = configuration.get<simcount_t >( section, "max_sims"       , detail::default_max_sims        );
      base_job->max_nodes         = configuration.get<unsigned   >( section, "max_nodes"      , detail::default_max_nodes       );
      base_job->job_backlog       = configuration.get<unsigned   >( section, "job_backlog"    , detail::default_job_backlog     );
      base_job->node_backlog      = configuration.get<unsigned   >( section, "node_backlog"   , detail::default_node_backlog    );

      base_job->checkpoint_secs   = configuration.get<unsigned   >( section, "checkpoint_secs", detail::default_checkpoint_secs );
      base_job->checkpoint_sims   = configuration.get<unsigned   >( section, "checkpoint_sims", detail::default_checkpoint_sims );

      base_job->checkpoints.reset( detail::create_checkpoints(configuration, section, "checkpoints").release() );

      base_job->optimizer_library = configuration.get<std::string>( section, "optimizer" );
      base_job->simulator_command = configuration.get<std::string>( section, "simulator" );

      LazySet<arguments_t>::ptr_t opt_args
        = detail::create_argument_set( configuration, section, "opt_args[%u]" );
      LazySet<arguments_t>::ptr_t sim_args
        = detail::create_argument_set( configuration, section, "sim_args[%u]" );

      assert( opt_args.get() );
      assert( sim_args.get() );

      argument_set_t::ptr_t argument_set
        = lazy_combine( opt_args, sim_args, detail::MakePair<arguments_t, arguments_t>() );

      size_t job_count = 0;

      // Make sure number of jobs does not exceed limit.
      for( argument_set->reset(); argument_set->has(); argument_set->inc(), ++job_count ) {
        if( (job_count_ + job_count) >= max_jobs )
          BOOST_THROW_EXCEPTION( JobQueueTooManyJobsError() << errinfo_max_value<size_t>(max_jobs) );
      }

      if( job_count == 0 )
        BOOST_THROW_EXCEPTION( JobQueueNotEnoughJobsError() << errinfo_min_value<size_t>(1) );

      JobTemplate job_tmpl;

      argument_set->reset();
      job_tmpl.base_job = base_job;
      job_tmpl.argument_set.reset( argument_set.release() );

      job_count_ += job_count;
      jobs_.push( job_tmpl );
    }
    catch( boost::exception &e ) {
      e << errinfo_config_section(section);
      throw;
    }
  }
}


void
JobQueue::pop() {
  if( jobs_.empty() )
    BOOST_THROW_EXCEPTION( AssertionError() );

  jobs_.front().argument_set->inc();

  if( !jobs_.front().argument_set->has() ) {
    // Go to next job/ argument set.
    jobs_.pop();
  }

  front_job_.reset();

  ++jobs_done_;
}


bool
JobQueue::empty() const {
  bool res = jobs_.empty();
  assert( bool(jobs_done_ == job_count_) == res );
  return res;
}


Job::ptr_t
JobQueue::front() const {
  if( jobs_.empty() )
    BOOST_THROW_EXCEPTION( AssertionError() );

  if( !front_job_ ) {
    // Increment the job's argument set id.
    ++(jobs_.front().base_job->arg_set_id);

    Job::ptr_t job( new Job(*jobs_.front().base_job) );

    const argument_set_t::value_t &arguments
      = jobs_.front().argument_set->get();

    job->id               = job_id_t( jobs_done_+1 );

    assert( job->checkpoints );
    // Call an explicit clone() on checkpoint lazy set to break sharing.
    job->checkpoints.reset( job->checkpoints->clone().release() );
    job->checkpoints->reset();

    job->job_directory    = job_dir(job->job_set_id) / arg_dir(job->arg_set_id);

    job->job_logfile      = job_logfile_;
    job->job_log_level    = job_log_level_;
    job->checkpoint_file  = checkpoint_file_;

    job->opt_logfile_mask = opt_logfile_mask_;
    job->sim_logfile_mask = sim_logfile_mask_;

    job->optimizer_map_file_mask  = optimizer_map_file_mask_;
    job->optimizer_lib_file_mask  = optimizer_lib_file_mask_;
    job->policy_bin_dumpfile_mask = policy_bin_dumpfile_mask_;
    job->policy_txt_dumpfile_mask = policy_txt_dumpfile_mask_;

    job->policy_count      = policy_count_;
    job->policy_bin_result = policy_bin_result_;
    job->policy_txt_result = policy_txt_result_;

    job->optimizer_arguments = arguments.first;
    job->simulator_arguments = arguments.second;

    front_job_ = job;
  }

  return front_job_;
}


size_t
JobQueue::total_jobs() const {
  return job_count_;
}


size_t
JobQueue::total_done() const {
  return jobs_done_;
}


boost::filesystem::path
JobQueue::job_dir( size_t job_set_id ) const {
  return (boost::format(job_dir_mask_) % job_set_id).str();
}


boost::filesystem::path
JobQueue::arg_dir( size_t arg_set_id ) const {
  return (boost::format(arg_dir_mask_) % arg_set_id).str();
}

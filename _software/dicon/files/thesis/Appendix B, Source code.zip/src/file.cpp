/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "file.hpp"
#include <boost/filesystem/convenience.hpp>
#include <boost/format.hpp>
#include <cerrno>
#include <cstdio>
#include <sstream>


std::string
to_string( const errinfo_file_flags::errinfo_t &file_flags ) {
  int flags = file_flags.value();
  std::stringstream str;

  str << flags
      << ", ";

  std::ios_base::fmtflags ioflags = str.flags( std::ios_base::oct );
  str << '0'
      << flags;
  str.flags( ioflags );
  str << ", ";

  bool first = true;

#define DICON_CHECK_FILE_FLAGS_(X, FORCE)               \
  if( (X != 0 || FORCE) && (flags & X) == X ) do {      \
    if( !first ) str << '|'; else first = false;        \
    str << #X; flags ^= X;                              \
    } while( false )                                    \
      /**/

  /**/ DICON_CHECK_FILE_FLAGS_( O_RDWR  , true );
  else DICON_CHECK_FILE_FLAGS_( O_WRONLY, true );
  else DICON_CHECK_FILE_FLAGS_( O_RDONLY, true );

  DICON_CHECK_FILE_FLAGS_( O_CREAT , false );
  DICON_CHECK_FILE_FLAGS_( O_EXCL  , false );
  DICON_CHECK_FILE_FLAGS_( O_NOCTTY, false );
  DICON_CHECK_FILE_FLAGS_( O_TRUNC , false );

  DICON_CHECK_FILE_FLAGS_( O_APPEND   , false );
  DICON_CHECK_FILE_FLAGS_( O_ASYNC    , false );
  DICON_CHECK_FILE_FLAGS_( O_DIRECTORY, false );
  DICON_CHECK_FILE_FLAGS_( O_LARGEFILE, false );
  DICON_CHECK_FILE_FLAGS_( O_NOFOLLOW , false );
  DICON_CHECK_FILE_FLAGS_( O_NONBLOCK , false );
  DICON_CHECK_FILE_FLAGS_( O_NDELAY   , false );
  DICON_CHECK_FILE_FLAGS_( O_SYNC     , false );

#undef DICON_CHECK_FILE_FLAGS_

  if( flags != 0 ) {
    if( !first )
      str << '|';

    std::ios_base::fmtflags ioflags = str.flags( std::ios_base::oct );
    str << '0'
        << flags;
    str.flags( ioflags );
  }

  return str.str();
}


std::string
to_string( const errinfo_file_mode::errinfo_t &file_mode ) {
  std::stringstream str;

  str << file_mode.value()
      << ", ";

  std::ios_base::fmtflags ioflags = str.flags( std::ios_base::oct );
  str << '0'
      << file_mode.value();
  str.flags( ioflags );

  return str.str();
}


File::Data::Data( const boost::filesystem::path &filename )
  : filefd(-1), owned(true), filename(filename)
{
}


File::Data::~Data() {
  if( owned && filefd != -1 ) {
    close( filefd );
    filefd = -1;
  }
}


File::File( const boost::filesystem::path &filename, int flags, mode_t mode )
  : data_(new Data(filename))
{
  std::string file_string = filename.file_string();

  if( (flags & O_CREAT) == 0 ) {
    // Open file (without mode parameter).

    if( (data_->filefd = ::open(file_string.c_str(), flags)) == -1 ) {
      BOOST_THROW_EXCEPTION( FileOpenError() << errinfo_api_function("open")
                             << errinfo_errno(errno) << errinfo_file_name(file_string) << errinfo_file_flags(flags) );
    }
  }
  else {
    // Optionally create file (with mode parameter).

    boost::filesystem::create_directories( filename.parent_path() );

    if( (data_->filefd = ::open(file_string.c_str(), flags, mode)) == -1 ) {
      if( (flags & O_EXCL) != 0 && errno == EEXIST ) {
        BOOST_THROW_EXCEPTION( FileExistsError() << errinfo_api_function("open")
                               << errinfo_errno(errno) << errinfo_file_name(file_string)
                               << errinfo_file_flags(flags) << errinfo_file_mode(mode) );
      }
      else {
        BOOST_THROW_EXCEPTION( FileCreateError() << errinfo_api_function("open")
                               << errinfo_errno(errno) << errinfo_file_name(file_string)
                               << errinfo_file_flags(flags) << errinfo_file_mode(mode) );
      }
    }
  }
}


void
File::chdir( const boost::filesystem::path &dirname ) {
  const std::string &directory = dirname.file_string();

  if( ::chdir(directory.c_str()) != 0 ) {
    BOOST_THROW_EXCEPTION( DirectoryError() << errinfo_errno(errno)
                           << errinfo_api_function("chdir") << errinfo_file_name(directory) );
  }
}


bool
File::exists( const boost::filesystem::path &path ) throw() {
  // The Boost implementation bfs::exists throws exceptions, e.g.,
  // when the filename is invalid (disk drive or directory doesn't
  // exist etc.). But we don't want any exceptions to be thrown.

  struct stat buffer;

  return stat(path.file_string().c_str(), &buffer) == 0;
}


void
File::rename( const boost::filesystem::path &old_path, const boost::filesystem::path &new_path ) {
#if 0
  // In contrast to Boost documentation, this (as of version 1.40.0)
  // throws an exception in case `new_path' exists. For this reason,
  // using bfs::rename is not possible at the moment (exception must
  // not be thrown, but `new_path' must be overwritten in-place).

  boost::filesystem::rename( tmp_file, file );
#else
  if( ::rename(old_path.file_string().c_str(), new_path.file_string().c_str()) != 0 ) {
    BOOST_THROW_EXCEPTION( FileRenameError() << errinfo_api_function("rename") << errinfo_errno(errno)
                           << errinfo_file_name(old_path.file_string()) << errinfo_file_name_2(new_path.file_string()) );
  }
#endif
}


File
File::unique( const boost::filesystem::path &filename, int flags, mode_t mode ) {
  for( unsigned i = 0;; ++i ) {
    boost::filesystem::path name
      = i ? filename.parent_path() / (boost::format("%s.%u") % filename.filename() % i).str() : filename;

    try {
      return File( name, flags, mode );
    }
    catch( FileExistsError & ) {
      // Try next name.
      continue;
    }
  }
}


boost::filesystem::path
File::unique_name( const boost::filesystem::path &filename, int flags, mode_t mode ) {
  return unique( filename, flags, mode ).filename();
}


boost::filesystem::path
File::unique_temporary( const boost::filesystem::path &filename, int flags, mode_t mode ) {
  return unique_name( filename.parent_path() / (boost::format(".%s_tmp") % filename.filename()).str(), flags, mode );
}


int
File::file() const {
  if( !data_->owned ) {
    BOOST_THROW_EXCEPTION( FileNotOwnedError()
                           << errinfo_file_descriptor(data_->filefd) );
  }

  return data_->filefd;
}


int
File::file( bool take_ownership ) {
  if( !data_->owned ) {
    BOOST_THROW_EXCEPTION( FileNotOwnedError()
                           << errinfo_file_descriptor(data_->filefd) );
  }

  if( take_ownership )
    data_->owned = false;

  return data_->filefd;
}


boost::filesystem::path
File::filename() const {
  return data_->filename;
}

#ifndef DICON_CONFIG_HPP_
#define DICON_CONFIG_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief Configuration class.
 */
#include "error.hpp"
#include <map>
#include <string>


/// Errinfo storing the config filename.
DICON_ERRINFO( config_file     , std::string );
/// Errinfo storing the line number in the config file.
DICON_ERRINFO( config_line     , int         );
/// Errinfo storing the section name in the config file.
DICON_ERRINFO( config_section  , std::string );
/// Errinfo storing the parameter name in the config file.
DICON_ERRINFO( config_parameter, std::string );
/// Errinfo storing the parameter value in the config file.
DICON_ERRINFO( config_value    , std::string );


/// Config file related error.
struct ConfigError : virtual Error
{ virtual const char *what() const throw() { return "Config file related error."; } };

/// Config file has invalid format.
struct ConfigFormatError : virtual ConfigError
{ virtual const char *what() const throw() { return "Config file has invalid format."; } };

/// Config parameter has invalid format.
struct ConfigInvalidParameterError : virtual ConfigError
{ virtual const char *what() const throw() { return "Config parameter has invalid format."; } };


/// Config item not found.
struct ConfigNotFoundError : virtual ConfigError
{ virtual const char *what() const throw() { return "Config item not found."; } };

/// Config section not found in file.
struct ConfigSectionNotFoundError : virtual ConfigNotFoundError
{ virtual const char *what() const throw() { return "Config section not found in file."; } };

/// Config parameter not found in section.
struct ConfigParameterNotFoundError : virtual ConfigNotFoundError
{ virtual const char *what() const throw() { return "Config parameter not found in section."; } };


/// Config item has invalid name.
struct ConfigInvalidNameError : virtual ConfigFormatError
{ virtual const char *what() const throw() { return "Config item has invalid name."; } };

/// Config section has invalid name.
struct ConfigInvalidSectionNameError : virtual ConfigInvalidNameError
{ virtual const char *what() const throw() { return "Config section has invalid name."; } };

/// Config parameter has invalid name.
struct ConfigInvalidParameterNameError : virtual ConfigInvalidNameError
{ virtual const char *what() const throw() { return "Config parameter has invalid name."; } };


/// Config item already defined.
struct ConfigRedefinedError : virtual ConfigFormatError
{ virtual const char *what() const throw() { return "Config item already defined."; } };

/// Config section already defined in file.
struct ConfigSectionRedefinedError : virtual ConfigRedefinedError
{ virtual const char *what() const throw() { return "Config section already defined in file."; } };

/// Config parameter already defined in section.
struct ConfigParameterRedefinedError : virtual ConfigRedefinedError
{ virtual const char *what() const throw() { return "Config parameter already defined in section."; } };


/// Unexpected config item.
struct ConfigLoneError : virtual ConfigFormatError
{ virtual const char *what() const throw() { return "Unexpected config item."; } };

/// Unexpected line format in config file.
struct ConfigLoneLineError : virtual ConfigLoneError
{ virtual const char *what() const throw() { return "Unexpected line format in config file."; } };

/// Unexpected parameter definition in config file.
struct ConfigLoneParameterError : virtual ConfigLoneError
{ virtual const char *what() const throw() { return "Unexpected parameter definition in config file."; } };


/// Config file could not be imported.
struct ConfigImportError : public virtual ConfigError, public virtual IOError
{ virtual const char *what() const throw() { return "Config file could not be imported."; } };


/**
 * @brief Name-value based configuration.
 *
 * The Configuration  class provides access  to configuration settings
 * based on name-value pairs  arranged in sections. Configurations can
 * be read from configuration files in the INI file format.
 */
class Configuration {
public:
  /**
   * @brief Check if section exists.
   *
   * Check  if  the  section  given   by  @e  section  exists  in  the
   * configuration. A section  is said to exist if and  only if it has
   * at least one parameter set.
   *
   * @param section Section name.
   * @returns @c true iff the section exists.
   */
  bool has( const std::string &section ) const;
  /**
   * @brief Check if parameter exists in section.
   *
   * Check if  the parameter  given by @e  name exists in  the section
   * given by @e section. A parameter in a section is said to exist if
   * and only if it is set.
   *
   * @param section Section name.
   * @param name Parameter name within the section.
   * @returns @c true iff the parameter exists in the section.
   */
  bool has( const std::string &section, const std::string &name ) const;

  /**
   * @brief Get value of parameter from section.
   *
   * Get the  value of the parameter  given by @e name  in the section
   * given by  @e section.   If this parameter  is not set,  this call
   * fails. The value is converted to  the type given by @e T using @c
   * boost::lexical_cast<>.
   *
   * @tparam T Value type.
   * @param section Section name.
   * @param name Parameter name within the section.
   * @returns Value of the parameter.
   * @throws  ConfigSectionNotFoundError  when  the section  does  not
   *   exist.
   * @throws ConfigParameterNotFoundError when  the section exists but
   *   the parameter does not exist in the section.
   * @throws ConfigInvalidParameterError when  the parameter exists in
   *   the section but  its value could not be  converted to the given
   *   type.
   */
  template< typename T >
  T get( const std::string &section, const std::string &name ) const;
  /**
   * @brief Get value of parameter from section with fallback.
   *
   * Get the  value of the parameter  given by @e name  in the section
   * given by  @e section.   If this parameter  is not set,  the value
   * given by @e fallback is  returned.  The value is converted to the
   * type given by @e T using @c boost::lexical_cast<>.
   *
   * @tparam T Value type.
   * @param section Section name.
   * @param name Parameter name within the section.
   * @param fallback Fallback value  to return when parameter does not
   *   exist.
   * @returns Value of the parameter.
   * @throws ConfigInvalidParameterError when  the parameter exists in
   *   the section but  its value could not be  converted to the given
   *   type.
   */
  template< typename T >
  T get( const std::string &section, const std::string &name, const T &fallback ) const;

public:
  /**
   * @brief Put value of parameter in section.
   *
   * Put the value given by @e value in the parameter given by @e name
   * in the section given by @e  section. This call fails if the value
   * of  type given  by @e  T  can not  be converted  to the  internal
   * storage type using @c boost::lexical_cast<>.
   *
   * @tparam T Value type.
   * @param section Section name.
   * @param name Parameter name within the section.
   * @param value New value of the parameter.
   * @throws  ConfigInvalidParameterError when  the value  can  not be
   *   converted to the internal storage type.
   */
  template< typename T >
  void put( const std::string &section, const std::string &name, const T &value );

public:
  /**
   * @brief Clear configuration.
   *
   * Clear  the configuration.  This removes  all parameters,  so that
   * after this call returns no section and no parameter exists within
   * the configuration.
   */
  void clear();
  /**
   * @brief Import configuration from stream.
   *
   * Import  a configuration  in the  INI file  format from  the given
   * stream.    This  merges  the   current  configuration   with  the
   * configuration read  from the stream, so that  parameters from the
   * stream   replace   parameters   already   existing   within   the
   * configuration.
   *
   * @param input Input stream.
   * @throws  ConfigInvalidSectionNameError  when  an invalid  section
   *   name was found.
   * @throws ConfigInvalidParameterNameError when an invalid parameter
   *   name was found.
   * @throws  ConfigSectionRedefinedError when  a section  was defined
   *   more than once within the INI file.
   * @throws   ConfigParameterRedefinedError  when  a   parameter  was
   *   defined more than  once within the same section  within the INI
   *   file.
   * @throws  ConfigLoneParameterError when  a  parameter was  defined
   *   without a section.
   * @throws ConfigLoneLineError  when a line that  is neither section
   *   nor parameter definition was found.
   */
  void import( std::istream &input );
  /**
   * @brief Import configuration from file.
   *
   * Import  a configuration  in the  INI file  format from  the given
   * file.    This   merges  the   current   configuration  with   the
   * configuration read  from the stream, so that  parameters from the
   * stream   replace   parameters   already   existing   within   the
   * configuration.
   *
   * @param filename Input filename.
   * @throws  ConfigInvalidSectionNameError  when  an invalid  section
   *   name was found.
   * @throws ConfigInvalidParameterNameError when an invalid parameter
   *   name was found.
   * @throws  ConfigSectionRedefinedError when  a section  was defined
   *   more than once within the INI file.
   * @throws   ConfigParameterRedefinedError  when  a   parameter  was
   *   defined more than  once within the same section  within the INI
   *   file.
   * @throws  ConfigLoneParameterError when  a  parameter was  defined
   *   without a section.
   * @throws ConfigLoneLineError  when a line that  is neither section
   *   nor parameter definition was found.
   * @throws  ConfigImportError when an  error occurred  while reading
   *   the input file.
   */
  void import( const std::string &filename );

private:
  template< typename T >
  T get_( const std::string &section, const std::string &name, const T *fallback ) const;

private:
  typedef std::map< std::string
                  , std::map<std::string, std::string>
                  > values_t;
  values_t values_;
};


#include "config.ipp"

#endif //DICON_CONFIG_HPP_

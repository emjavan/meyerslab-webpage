#ifndef DICON_LAZY_VALUE_CONSTANT_HPP_
#define DICON_LAZY_VALUE_CONSTANT_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyConstant class.
 */
#include "../value.hpp"


/**
 * @brief Lazy constant value.
 *
 * The LazyConstant  class implements a constant lazy  value. Thus, it
 * does not  depend an any variables  and will always  evaluate to the
 * same value.
 *
 * @tparam T Lazy value's type.
 */
template< typename T >
class LazyConstant
  : public LazyValue<T>
{
public:
  /**
   * @brief Create lazy constant value.
   *
   * Constructor  that creates  the lazy  value that  is  constant and
   * always evaluates to the value given by @e value.
   *
   * @param value Constant lazy value.
   */
  LazyConstant( const T &value );

public:
  virtual typename LazyValue<T>::references_t references() const;

public:
  virtual T operator()( const typename LazyValue<T>::variables_t &variables ) const;

private:
  T value_;
};


/**
 * @brief Create lazy constant value.
 *
 * Create lazy constant value as described in the documentation of the
 * LazyConstant class. This templated  helper function returns a smart
 * pointer to the newly created lazy value.
 *
 * @param value Constant lazy value.
 * @returns Pointer to new lazy value.
 */
template< typename T >
typename LazyValue<T>::ptr_t lazy_constant( const T &value );


#include "constant.ipp"

#endif //DICON_LAZY_VALUE_CONSTANT_HPP_

#ifndef DICON_LAZY_VALUE_UNARY_HPP_
#define DICON_LAZY_VALUE_UNARY_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyUnaryOp class.
 */
#include "../value.hpp"
#include <boost/noncopyable.hpp>


/**
 * @brief Lazy unary operator.
 *
 * The LazyUnaryOp  class implements the  lazy application of  a unary
 * functor to a lazy value.
 *
 * The functor  of type  @e Op must  be compatible with  the following
 * function type signature: <code>T(const T &)</code>.
 *
 * @tparam Op Functor to apply.
 * @tparam T Lazy value's type.
 */
template< typename Op, typename T = typename Op::result_type >
class LazyUnaryOp
  : boost::noncopyable, public LazyValue<T>
{
public:
  /**
   * @brief Create lazy unary operator.
   *
   * Constructor  that  creates  the  lazy  value  that  is  the  lazy
   * application of the unary functor given by @e op to the lazy value
   * given  by @e  x.  The  resulting lazy  value will  depend  on all
   * variables the original lazy value depends on.
   *
   * In order to  fulfill the lazy value interface,  the functor @e op
   * must return the  same value each time it is  called with the same
   * argument.
   *
   * @param x Original lazy value.
   * @param op Functor to apply lazily.
   */
  LazyUnaryOp( typename LazyValue<T>::ptr_t &x, const Op &op = Op() );

public:
  virtual typename LazyValue<T>::references_t references() const;

public:
  virtual T operator()( const typename LazyValue<T>::variables_t &variables ) const;

private:
  const typename LazyValue<T>::ptr_t x_;
  Op op_;
};


/**
 * @brief Create lazy unary operator.
 *
 * Create lazy unary operator as described in the documentation of the
 * LazyUnaryOp class.  This templated helper function  returns a smart
 * pointer to the newly created lazy value.
 *
 * @param x Original lazy value.
 * @param op Functor to apply lazily.
 * @returns Pointer to new lazy value.
 */
template< typename Op, typename T >
typename detail::LazyValuePtr<T>::ptr_t lazy_unary_op( T x, const Op &op );


#include "unary.ipp"

#endif //DICON_LAZY_VALUE_UNARY_HPP_

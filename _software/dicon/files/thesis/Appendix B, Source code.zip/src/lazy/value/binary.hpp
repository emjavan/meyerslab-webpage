#ifndef DICON_LAZY_VALUE_BINARY_HPP_
#define DICON_LAZY_VALUE_BINARY_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyBinaryOp class.
 */
#include "../value.hpp"
#include <boost/noncopyable.hpp>


/**
 * @brief Lazy binary operator.
 *
 * The  LazyBinaryOp  implements  the  lazy application  of  a  binary
 * functor to two lazy values.
 *
 * The functor  of type  @e Op must  be compatible with  the following
 * function type signature: <code>T(const T &, const T &)</code>.
 *
 * @tparam Op Functor to apply.
 * @tparam T Lazy value's type.
 */
template< typename Op, typename T = typename Op::result_type >
class LazyBinaryOp
  : boost::noncopyable, public LazyValue<T>
{
public:
  /**
   * @brief Create lazy binary operator.
   *
   * Constructor  that  creates  the  lazy  value  that  is  the  lazy
   * application of the binary functor given  by @e op to the two lazy
   * values given  by @e  a and  @e b. The  resulting lazy  value will
   * depend on all variables the original lazy values depend on.
   *
   * In order to  fulfill the lazy value interface,  the functor @e op
   * must return the  same value each time it is  called with the same
   * arguments.
   *
   * @param a First lazy value.
   * @param b Second lazy value.
   * @param op Functor to apply lazily.
   */
  LazyBinaryOp( typename LazyValue<T>::ptr_t &a, typename LazyValue<T>::ptr_t &b, const Op &op = Op() );

public:
  virtual typename LazyValue<T>::references_t references() const;

public:
  virtual T operator()( const typename LazyValue<T>::variables_t &variables ) const;

private:
  const typename LazyValue<T>::ptr_t a_;
  const typename LazyValue<T>::ptr_t b_;
  Op op_;
};


/**
 * @brief Create lazy binary operator.
 *
 * Create lazy  binary operator as  described in the  documentation of
 * the LazyBinaryOp  class. This  templated helper function  returns a
 * smart pointer to the newly created lazy value.
 *
 * @param a First lazy value.
 * @param b Second lazy value.
 * @param op Functor to apply lazily.
 * @returns Pointer to new lazy value.
 */
template< typename Op, typename T >
typename detail::LazyValuePtr<T>::ptr_t lazy_binary_op( T a, T b, const Op &op );


#include "binary.ipp"

#endif //DICON_LAZY_VALUE_BINARY_HPP_

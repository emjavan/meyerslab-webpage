#ifndef DICON_LAZY_SET_EMPTY_HPP_
#define DICON_LAZY_SET_EMPTY_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyEmpty class.
 */
#include "../set.hpp"


/**
 * @brief Lazy empty set.
 *
 * The LazyEmpty  class implements an  empty lazy set.  Thus,  it does
 * not  contain  any  elements,  and  calling get()  or  inc()  always
 * fails. It  can be  useful as a  starting point for  building bigger
 * lazy sets using LazyCombine, LazyConcat, or LazyUnion.
 *
 * @note Though this empty lazy  set does not contain any elements, it
 *   must still have a value type associated. This is required both in
 *   order to  satisfy the LazySet  interface (which requires  a value
 *   type) and to  make the helper functions described  in the LazySet
 *   interface easier to use.
 *
 * @tparam T Value type of this set.
 */
template< typename T >
class LazyEmpty
  : public LazySet<T>
{
public:
  /**
   * @brief Create lazy empty set.
   *
   * Constructor that creates  the lazy set that does  not contain any
   * elements. The resulting set is  empty, and calling get() or inc()
   * always fails, while has() always returns @c false.
   */
  LazyEmpty();

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();
};


/**
 * @brief Create lazy empty set.
 *
 * Create  lazy empty  set as  described in  the documentation  of the
 * LazyEmpty  class. This  templated helper  function returns  a smart
 * pointer to the newly created set.
 *
 * @returns Pointer to new lazy set.
 */
template< typename T >
typename LazySet<T>::ptr_t lazy_empty();


#include "empty.ipp"

#endif //DICON_LAZY_SET_EMPTY_HPP_

#ifndef DICON_LAZY_SET_CONTAINER_HPP_
#define DICON_LAZY_SET_CONTAINER_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyContainer class.
 */
#include "../set.hpp"


/**
 * @brief Lazy container set.
 *
 * The LazyContainer  class implements the lazy set  equivalent of the
 * given container. Thus, it returns  all the elements of the original
 * container, in  the order the  container returns them. The  lazy set
 * stores the elements  it contains in an internal  container the type
 * of  which can  be specified  by the  template argument  @e  C.  The
 * container class  must fulfill  either the sequence  requirements or
 * the associative container requirements specified by the standard.
 *
 * @tparam C Container type used.
 * @tparam T Value type of this set.
 */
template< typename C
        , typename T = typename C::value_type
        >
class LazyContainer
  : public LazySet<T>
{
public:
  /**
   * @brief Create lazy set of container.
   *
   * Constructor that  creates the lazy set that  contains exactly the
   * elements  of  the given  container,  in  the  same order  as  the
   * container returns  them. The internal  container of the  lazy set
   * will  be   copy-constructed  from  the  container   given  by  @e
   * container.
   *
   * @param container Original container.
   */
  LazyContainer( const C &container );

  /**
   * @brief Create lazy set of container.
   *
   * Constructor that  creates the lazy set that  contains exactly the
   * elements  of the  given container  range, in  the order  they are
   * given in the range.  The  internal container of the lazy set will
   * be constructed from this range, i.e., the original container from
   * which  this  range  was  obtained  can be  destroyed  after  this
   * constructor returns.
   *
   * @param begin Iterator to first element.
   * @param end Iterator past last element.
   */
  template< typename InputIterator >
  LazyContainer( InputIterator begin, InputIterator end );

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();

private:
  const C container_;
  typename C::const_iterator position_;
};


/**
 * @brief Create lazy container set.
 *
 * Create lazy container set as  described in the documentation of the
 * LazyContainer class. This templated helper function returns a smart
 * pointer to the newly created set.
 *
 * @param container Original container.
 * @returns Pointer to new lazy set.
 */
template< typename C >
typename LazySet<typename C::value_type>::ptr_t lazy_container( const C &container );

/**
 * @brief Create lazy container set.
 *
 * Create lazy container set as  described in the documentation of the
 * LazyContainer class. This templated helper function returns a smart
 * pointer to the newly created set.
 *
 * @param begin Iterator to first element.
 * @param end Iterator past last element.
 * @returns Pointer to new lazy set.
 */
template< typename C, typename InputIterator >
typename LazySet<typename C::value_type>::ptr_t lazy_container( InputIterator begin, InputIterator end );


#include "container.ipp"

#endif //DICON_LAZY_SET_CONTAINER_HPP_

#ifndef DICON_LAZY_SET_CONCAT_HPP_
#define DICON_LAZY_SET_CONCAT_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazyConcat class.
 */
#include "../set.hpp"
#include <boost/noncopyable.hpp>


/**
 * @brief Concatenate lazy sets.
 *
 * The LazyConcat class implements the concatenation of two lazy sets.
 * Thus, it represents  the lazy set that first  contains all elements
 * of the first set, followed by all elements of the second set.
 *
 * @tparam T Value type of this and both original sets.
 */
template< typename T >
class LazyConcat
  : boost::noncopyable, public LazySet<T>
{
public:
  /**
   * @brief Create lazy concatenation set.
   *
   * Constructor that  creates the lazy set that  is the concatenation
   * of the two lazy  sets given by @e a and @e  b.  The resulting set
   * first contains all elements of  @e a, followed by all elements of
   * @e b.
   *
   * The resulting set will be infinite if and only if at least one of
   * the two sets @e a and @e b is infinite.
   *
   * @param a First set.
   * @param b Second set.
   */
  LazyConcat( typename LazySet<T>::ptr_t &a, typename LazySet<T>::ptr_t &b );

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();

private:
  const typename LazySet<T>::ptr_t a_;
  const typename LazySet<T>::ptr_t b_;
};


/**
 * @brief Create lazy concatenation set.
 *
 * Create lazy concatenation set  as described in the documentation of
 * the  LazyConcat class.   This templated  helper function  returns a
 * smart pointer to the newly created set.
 *
 * @param a First set.
 * @param b Second set.
 * @returns Pointer to new lazy set.
 */
template< typename T >
typename detail::LazySetPtr<T>::ptr_t lazy_concat( T a, T b );


#include "concat.ipp"

#endif //DICON_LAZY_SET_CONCAT_HPP_

#ifndef DICON_LAZY_SET_SINGLETON_HPP_
#define DICON_LAZY_SET_SINGLETON_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

/**
 * @file
 * @brief LazySingleton class.
 */
#include "../set.hpp"


/**
 * @brief Lazy singleton set.
 *
 * The  LazySingleton  class implements  the  lazy  set that  contains
 * exactly  one   element,  given  on  construction.    The  lazy  set
 * implementation  keeps a  copy of  the value  given  on construction
 * after the constructor returns.
 *
 * @tparam T Value type of this set.
 */
template< typename T >
class LazySingleton
  : public LazySet<T>
{
public:
  /**
   * @brief Create lazy singleton set.
   *
   * Constructor  that creates  the lazy  set that  contains  only the
   * single element given by @e value.
   *
   * @param value Only element in lazy set.
   */
  LazySingleton( const T &value );

public:
  virtual typename LazySet<T>::ptr_t clone() const;

public:
  virtual void reset();

public:
  virtual bool has() const;
  virtual T get() const;
  virtual void inc();

private:
  const T value_;
  bool done_;
};


/**
 * @brief Create lazy singleton set.
 *
 * Create lazy singleton set as  described in the documentation of the
 * LazySingleton class. This templated helper function returns a smart
 * pointer to the newly created set.
 *
 * @param value Only element in lazy set.
 * @returns Pointer to new lazy set.
 */
template< typename T >
typename LazySet<T>::ptr_t lazy_singleton( const T &value );


#include "singleton.ipp"

#endif //DICON_LAZY_SET_SINGLETON_HPP_

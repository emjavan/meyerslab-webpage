/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "log.hpp"
#include "file.hpp"
#include <boost/foreach.hpp>
#include <boost/format.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/version.hpp>
#include <boost/weak_ptr.hpp>
#include <iostream>
#include <vector>


namespace detail {

  class LogManager
    : boost::noncopyable
  {
  public:
    void register_sink( const boost::shared_ptr<LogSink> &sink, LogLevel min_level, job_id_t job_id );
    void remove_sink( const boost::shared_ptr<LogSink> &sink );

  public:
    void log( const std::string &message, LogLevel level, job_id_t job_id );

  private:
    struct SinkData {
      boost::weak_ptr<LogSink> sink;
      LogLevel min_level;
      job_id_t job_id;

      void swap( SinkData &other );
    };

    std::vector<SinkData> sinks_;
  };

}



namespace detail {

  static
  std::string
  with_job( const std::string &message, job_id_t job_id ) {
    assert( job_id > 0 );
    return (boost::format("[Job #%u] %s") % job_id % message).str();
  }

}



namespace detail {

  void
  LogManager::SinkData::swap( SinkData &other ) {
    sink.swap( other.sink );
    std::swap( min_level, other.min_level );
    std::swap( job_id, other.job_id );
  }


  void
  LogManager::register_sink( const boost::shared_ptr<LogSink> &sink, LogLevel min_level, job_id_t job_id ) {
    SinkData data;

    data.sink = sink;
    data.min_level = min_level;
    data.job_id = job_id;

    sinks_.push_back( data );
  }


  void
  LogManager::remove_sink( const boost::shared_ptr<LogSink> &sink ) {
    size_t i = 0;

    while( i < sinks_.size() ) {
      const SinkData &data = sinks_[i++];
      boost::shared_ptr<LogSink> entry = data.sink.lock();

      if( !entry || entry == sink ) {
        // Remove the sink, then continue.
        sinks_[--i].swap( sinks_.back() );
        sinks_.pop_back();
        continue;
      }
    }
  }


  void
  LogManager::log( const std::string &message, LogLevel level, job_id_t job_id ) {
    boost::exception_ptr error;

    size_t i = 0;
    while( i < sinks_.size() ) {
      const SinkData &data = sinks_[i++];
      boost::shared_ptr<LogSink> sink = data.sink.lock();

      if( !sink ) {
        // Remove the sink, then continue.
        sinks_[--i].swap( sinks_.back() );
        sinks_.pop_back();
        continue;
      }

      bool job_matches = data.job_id == 0 || data.job_id == job_id;

      if( !(job_matches && level >= data.min_level) ) {
        // Do not log to this sink.
        continue;
      }

      try {
        if( job_id == 0 || data.job_id != 0 )
          sink->log( message, level );
        else
          sink->log( with_job(message, job_id), level );
      }
      catch( ... ) {
        if( !error ) {
          // Keep 1st exception to be thrown.
          error = boost::current_exception();

          // Remove the sink, then continue.
          sinks_[--i].swap( sinks_.back() );
          sinks_.pop_back();
          continue;
        }
      }
    }

    if( error )
      boost::rethrow_exception( error );
  }

}



namespace detail {

  static const int stderr_clone = dup( STDERR_FILENO );
  static const char time_format[] = "%b %d %H:%M:%S";
  static LogManager log_manager;


  static
  std::string
  level_str( LogLevel level ) {
    switch( level ) {
    case LOG_DEBUG:   return "debug";
    case LOG_INFO:    return "info";
    case LOG_WARNING: return "warning";
    case LOG_ERROR:   return "error";
    case LOG_FAILURE: return "failure";
    }

    BOOST_THROW_EXCEPTION( AssertionError() << errinfo_value<LogLevel>(level) );
  }


  static
  std::string
  time_str() {
    time_t current;
    if( (current = time(NULL)) == time_t(-1) )
      BOOST_THROW_EXCEPTION( TimeError() << errinfo_api_function("time") << errinfo_errno(errno) );

    struct tm tm_time;
    if( localtime_r(&current, &tm_time) == NULL )
      BOOST_THROW_EXCEPTION( TimeError() << errinfo_api_function("localtime_r") << errinfo_value<time_t>(current) );

    static const size_t max_length = 128;

    char result[ max_length ];
    size_t length = strftime( result, max_length, time_format, &tm_time );

    return std::string( result, length );
  }


  static
  std::vector<std::string>
  log_to_lines( const std::string &message, LogLevel level ) {
    static const char line_separators[] = "\n\r";
    static const char whitespace_chars[] = " \t";

    std::vector<std::string> lines;

    std::string prefix = (boost::format("%s %s") % time_str() % level_str(level)).str();

    size_t p = 0, np;
    do {
      np = message.find_first_of( line_separators, p );
      const std::string &line = message.substr( p, np != std::string::npos ? np - p : np );

      if( line.find_first_not_of(whitespace_chars) != std::string::npos )
        lines.push_back( prefix + (lines.empty() ? ": " : "|   ") + line );

      p = message.find_first_not_of( line_separators, np );
    } while( p != std::string::npos );

    return lines;
  }


  static
  void
  log_write( int fd, const std::string &line, bool flush = true ) throw() {
    try {
      if( fd < 0 ) {
        // Ignore.
        return;
      }

      size_t done = 0;
      while( done < line.length() ) {
        ssize_t res;
        if( (res = ::write(fd, line.c_str()+done, line.length()-done)) <= 0 ) {
          // Ignore.
          return;
        }

        assert( size_t(res) <= line.length()-done );

        done += size_t(res);
      }

      if( flush )
        ::fsync( fd );
    }
    catch( ... ) {
      // Ignore.
    }
  }


  static
  void
  log_message( const std::string &message, LogLevel level, job_id_t job_id ) throw() {
    try {
      boost::exception_ptr error;

      // Output message on sinks as appropriate.

      try {
        log_manager.log( message, level, job_id );
      }
      catch( ... ) {
        error = boost::current_exception();
      }

      // In addition, output errors to stderr output.

      if( level >= LOG_ERROR ) {
        try {
          const std::string &msg = job_id == 0 ? message : with_job( message, job_id );
          BOOST_FOREACH( const std::string &line, log_to_lines(msg, level) ) {
            log_write( stderr_clone, line+'\n' );
          }
        }
        catch( ... ) {
          // Ignore.
        }
      }

      // If message output on sink failed, print error.

      if( error ) {
        try {
          std::string msg = "Failed to write message to log.\n";
#if BOOST_VERSION >= 104000
          msg += boost::diagnostic_information( error );
#elif BOOST_VERSION >= 103900
          try {
            boost::rethrow_exception( error );
          }
          catch( ... ) {
            msg += boost::current_exception_diagnostic_information();
          }
#else
          try {
            boost::rethrow_exception( error );
          }
          catch( boost::exception &e ) {
            msg += boost::diagnostic_information( e );
          }
          catch( ... ) {
            msg += "<unknown exception>\n";
          }
#endif
          BOOST_FOREACH( const std::string &line, log_to_lines(msg, LOG_ERROR) ) {
            log_write( stderr_clone, line+'\n' );
          }
        }
        catch( ... ) {
          // Ignore.
        }
      }
    }
    catch( ... ) {
      // Ignore.
    }
  }

}


LogFile::LogFile( const boost::filesystem::path &file )
  : log_filename_(File::unique_name(file).file_string()),
    output_(log_filename_.c_str())
{
}


LogFile::~LogFile() {
  try {
    log( "Closing logfile.", LOG_INFO );
    output_.close();
  }
  catch( ... ) {
    // Ignore.
  }
}


void
LogFile::log( const std::string &message, LogLevel level ) {
  BOOST_FOREACH( const std::string &line, detail::log_to_lines(message, level) ) {
    output_ << line << '\n';
  }

  output_ << std::flush;

  if( output_.fail() )
    BOOST_THROW_EXCEPTION( LogWriteError() << errinfo_file_name(log_filename_) );
}


void
log_register_sink( const boost::shared_ptr<LogSink> &sink, LogLevel min_level, job_id_t job_id ) {
  detail::log_manager.register_sink( sink, min_level, job_id );
}


void
log_remove_sink( const boost::shared_ptr<LogSink> &sink ) {
  detail::log_manager.remove_sink( sink );
}


#define DICON_DEFINE_LOGS_( NAME, LEVEL )                               \
  void log_##NAME( const std::string &message,                          \
                   job_id_t job_id ) throw()                            \
  {                                                                     \
    detail::log_message( message, LOG_##LEVEL, job_id );                \
  }                                                                     \
                                                                        \
  void log_##NAME( job_id_t job_id,                                     \
                   const std::string &message ) throw()                 \
  {                                                                     \
    assert( job_id != 0 );                                              \
    log_##NAME( message, job_id );                                      \
  }                                                                     \
  /**/

DICON_DEFINE_LOGS_( debug  , DEBUG   )
DICON_DEFINE_LOGS_( info   , INFO    )
DICON_DEFINE_LOGS_( warning, WARNING )
DICON_DEFINE_LOGS_( error  , ERROR   )
DICON_DEFINE_LOGS_( failure, FAILURE )

#undef DICON_DEFINE_LOGS_

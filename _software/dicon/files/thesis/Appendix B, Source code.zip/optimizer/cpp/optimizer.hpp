#ifndef DICON_CPP_OPTIMIZER_HPP_
#define DICON_CPP_OPTIMIZER_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include <boost/noncopyable.hpp>
#include <boost/optional.hpp>
#include <stdexcept>
#include <string>
#include <vector>


namespace optimizer {

  typedef int node_t;
  typedef std::vector<node_t> policy_t;
  typedef std::vector<std::string> arguments_t;

  extern "C" typedef int (*children_t)( const node_t *path, const node_t **children );

}


extern "C" {

  int initialize( int argc, const char *const *argv,
                  optimizer::children_t children, const char *state_file     );
  int get_policy( const optimizer::node_t **policy                           );
  int update    ( const optimizer::node_t *policy, double reward             );
  int policies  ( unsigned *count,
                  const optimizer::node_t **policies, const double **rewards );
  int dump_state( const char *filename                                       );

  const char *get_error();

}


class OptimizerError
  : public std::runtime_error
{
public:
  OptimizerError( const std::string &what );
};


class Optimizer
  : boost::noncopyable
{
public:
  virtual ~Optimizer() {}

protected:
  std::vector<optimizer::node_t> children( const std::vector<optimizer::node_t> &path );

protected:
  typedef std::vector<std::pair<optimizer::policy_t, double> > policies_result_type;

  virtual boost::optional<optimizer::policy_t> get_policy() = 0;
  virtual void update( const optimizer::policy_t &policy, double reward ) = 0;
  virtual policies_result_type policies( unsigned count ) = 0;
  virtual void dump_state( const std::string &filename ) = 0;

private:
  friend int get_policy( const optimizer::node_t **                  );
  friend int update    ( const optimizer::node_t *, double           );
  friend int policies  ( unsigned *,
                         const optimizer::node_t **, const double ** );
  friend int dump_state( const char *                                );

  void get_policy_c( const optimizer::node_t **policy                           );
  void update_c    ( const optimizer::node_t *policy, double reward             );
  void policies_c  ( unsigned *count,
                     const optimizer::node_t **policies, const double **rewards );
  void dump_state_c( const char *filename                                       );

private:
  optimizer::policy_t c_to_cpp( const optimizer::node_t *list );
  const optimizer::node_t *cpp_to_c( const optimizer::policy_t &policy, bool keep = false );

private:
  std::vector<optimizer::node_t> temporary_;
  std::vector<double> tmp_rewards_;
};


extern
Optimizer *
create_optimizer( const std::string &name,
                  const optimizer::arguments_t &arguments,
                  const boost::optional<std::string> &state_file );

#define CREATE_OPTIMIZER( CLASSNAME )                                   \
  Optimizer *create_optimizer( const std::string &name,                 \
                               const optimizer::arguments_t &arguments, \
                               const boost::optional<std::string> &state_file ) \
  {                                                                     \
    return new CLASSNAME ( name, arguments, state_file );               \
  }                                                                     \
  /**/

#endif //DICON_CPP_OPTIMIZER_HPP_

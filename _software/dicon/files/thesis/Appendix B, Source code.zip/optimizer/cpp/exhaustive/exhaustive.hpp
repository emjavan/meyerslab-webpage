#ifndef DICON_CPP_EXHAUSTIVE_EXHAUSTIVE_HPP_
#define DICON_CPP_EXHAUSTIVE_EXHAUSTIVE_HPP_

/*--- [Distribution] -----------------------------------------------
 * This file is part of the Disease Control System DiCon.
 *
 * Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
 * Designed and developed with the guidance of Nedialko B. Dimitrov
 * and Lauren Ancel Meyers at the University of Texas at Austin.
 *
 * DiCon is free software: you  can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * DiCon  is distributed in  the hope  that it  will be  useful, but
 * WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
 *----------------------------------------------------------------*/

#include "../optimizer.hpp"
#include <boost/serialization/map.hpp>
#include <boost/serialization/vector.hpp>


class ExhaustiveSearch
  : public Optimizer
{
public:
  ExhaustiveSearch( const std::string &name,
                    const optimizer::arguments_t &arguments,
                    const boost::optional<std::string> &state_file );

protected:
  virtual boost::optional<optimizer::policy_t> get_policy();
  virtual void update( const optimizer::policy_t &policy, double reward );
  virtual policies_result_type policies( unsigned count );
  virtual void dump_state( const std::string &filename );

private:
  void load_state( std::istream &in );
  void save_state( std::ostream &out );

private:
  typedef std::multimap<double, optimizer::policy_t> best_policies_t;

  struct Data {
    size_t max_best_policies;
    best_policies_t best_policies;
    std::vector<optimizer::policy_t> queue;
  };

  Data data;
};


namespace boost {
  namespace serialization {

    template< class Archive >
    void serialize( Archive &ar, ExhaustiveSearch::Data &data, const unsigned int version );

  }
}


#include "exhaustive.ipp"

#endif //DICON_CPP_EXHAUSTIVE_EXHAUSTIVE_HPP_

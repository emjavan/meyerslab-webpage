#!/usr/bin/env python

#--- [Distribution] -----------------------------------------------
# This file is part of the Disease Control System DiCon.
#
# Copyright (C) 2009  Sebastian Goll, University of Texas at Austin
# Designed and developed with the guidance of Nedialko B. Dimitrov
# and Lauren Ancel Meyers at the University of Texas at Austin.
#
# DiCon is free software: you  can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# DiCon  is distributed in  the hope  that it  will be  useful, but
# WITHOUT  ANY  WARRANTY;  without  even the  implied  warranty  of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with DiCon.  If not, see <http://www.gnu.org/licenses/>.
#------------------------------------------------------------------

import sys
import signal
import pickle
import traceback
import simulator_pb2
from StringIO import StringIO
from communicator import Communicator


class HangUp( Exception ):
    pass


def hup_handler( signum, frame ):
    raise HangUp


class Simulator( Communicator ):
    def __init__( self ):
        Communicator.__init__( self, sys.stdin, sys.stdout )
        signal.signal( signal.SIGHUP, hup_handler )


    def read_question( self ):
        message = self.read_message()

        question = simulator_pb2.Question()
        question.ParseFromString( message )

        return question


    def new_answer( self ):
        answer = simulator_pb2.Answer()
        answer.failed = False
        return answer


    def write_answer( self, answer ):
        self.write_message( answer.SerializeToString() )


    def pickle( self, obj ):
        buffer = StringIO()

        try:
            pickle.dump( obj, buffer, pickle.HIGHEST_PROTOCOL )
            return buffer.getvalue()
        finally:
            buffer.close()


    def unpickle( self, str ):
        buffer = StringIO( str )

        try:
            return pickle.load( buffer )
        finally:
            buffer.close()


    def process( self ):
        answer = self.new_answer()
        question = self.read_question()

        try:
            if question.type == simulator_pb2.SIMULATE:
                policy = []
                for node in question.q_simulate.node:
                    policy.append( self.unpickle(node) )

                answer.a_simulate.reward = self.simulate( policy )

            elif question.type == simulator_pb2.CHILDREN:
                path = []
                for node in question.q_children.node:
                    path.append( self.unpickle(node) )

                for child in self.children( path ):
                    answer.a_children.node.append( self.pickle(child) )

            elif question.type == simulator_pb2.DISPLAY:
                policy = []
                for node in question.q_display.node:
                    policy.append( self.unpickle(node) )

                answer.a_display.display = self.display( policy )

            else:
                raise IOError, "Got unknown message type."

        except:
            answer.failed = True
            (type, value, tb) = sys.exc_info()
            answer.a_failure.what = "".join( traceback.format_exception(type, value, tb) )

        self.write_answer( answer )


    def main( self ):
        try:
            while True: self.process()
        except HangUp:
            pass


    def children( self, path ):
        raise NotImplementedError


    def simulate( self, policy ):
        raise NotImplementedError


    def display( self, policy ):
        raise NotImplementedError
